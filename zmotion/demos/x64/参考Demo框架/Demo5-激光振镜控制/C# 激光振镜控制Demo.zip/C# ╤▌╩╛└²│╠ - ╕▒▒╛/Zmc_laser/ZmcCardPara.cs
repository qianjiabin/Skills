﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zmotion_Laser;
using System.Windows.Forms;
using cszmcaux;

namespace Zmc_laser
{
    class ZmcCardPara
    {
        // 激光器类型, 
        public enum ZMC_LASER_TYPE
        {
            FIBER_408 = 0,
            YLR_408 = 1,
            YAG_408 = 2,
            FIBER_504 = 3,
            FIBER_408V2 = 4,
            LASER_408V2 = 5,
        };

        public static string G_MarkCardIpAdrr = "192.168.1.11";
        public static IntPtr G_CardHandle;

        public static int m_nLaserType = 0;

        public static int m_nEnableIO = 47;
        public static int m_nLaserIO = 8;
        public static int m_nRedIO = 48;
        public static int m_nAout = 3;
        public static int m_nAoutVal = 255;
        public static int m_nPwmIo = 9;
        public static int m_nPwmFreq = 40000;
        public static float m_fPwmDuty = 0.5f; 
        public static float m_nStartDelay = 0;
        public static float m_nLastDelay = 0;
        public static float m_nCorDelay = 0;
        public static float m_nJumpDelay = 0;

        public static int m_nPower = 30;

        public static float m_dEmpSpeed = 3000;
        public static float m_dMarkSpeed = 1000;
        public static float m_dSetSpeed = 1000;

        public static int m_nMinPower = 30;
        public static int m_nMaxPower = 40;

        public static int[] m_AxisList = new int[2] { 4, 5 };     //振镜轴列表


        public static string TeachFilePath = System.Environment.CurrentDirectory + "\\TeachFile";          //示教文件路径
        public static string TeachName = "TeachFile.txt";                                                //示教文件名称
        // 图形类型 
        public enum ZMC_MARK_TYPE
        {
            ZMC_MARK_POINT = 0,
            ZMC_MARK_LINE = 1,
            ZMC_MARK_ARC = 2,
            ZMC_MARK_CIRCLE = 3,
            ZMC_MARK_RECT = 4,
            ZMC_MARK_WORD = 10,
            ZMC_MARK_BARCODE = 11,
            ZMC_MARK_DXF = 12,
            ZMC_MARK_BMP = 13,
        };

        //图形编辑数据变量定义
        public struct Struct_Graph
        {
            public int iType ; 				//类型 0-9 多段线类型  10-19 文本、条码、矢量图、位图...
            public float fStartx ;
            public float fStarty ;
            public float fEndx ;
            public float fEndy ;
            public float fAngle1 ;
            public float fAngle2;

            public bool If_Fill ;		//是否填充
	        public bool If_Spiral ;		//是否曲线异化

	        public string GraphStr;		//字体字符串      
            public string GraphStr1;	//字符内容
	        public int nBitMode ;		//字体类型位类型
	        public float fAccuracy;		//拆分精度
        }

        public static float[] m_GraphRange = new float[4];                             //图形范围大小，用于边框预览 Left,botton,Width,Height
        public static List<Struct_Graph> m_GraphData = new List<Struct_Graph>();      //数据

        public static int m_TotalLine = 0;             //总行数
        public static int m_CurEditLine = 0;           //当前编辑行
        public static int m_CurEditAype = 4;           //当前编辑类型

        //CAD相关变量
        public static ZmcLaser.Struct_ZCad_Array[] ZCad_ArrayInfo;
        public static long ZCad_ArrayLen = 0;

        //填充参数
        public static ZmcLaser.Struct_ZLaser_Fill m_FillPara;

        //螺旋线异化相关
        public static double m_SpiralRadio = 0.5;
        public static double m_SpiralDist = 0.5;
        public static double m_SpiralAccuracy = 0.05;


        
        //轴参数数据变量定义
        public struct Struct_AxisPara
        {
            public int atype;		//轴类型
            public float units;     
            public float lspeed;
            public float speed;
            public float accel;
            public float decel;
            public float sramp;
            public int MotorDir;
            public int EncoderDir;
            public  float fsLimit;
            public float rsLimit;
            public int fwdIn;
            public int revIn;
            public int almIn;
            public int datumIn;
            public int HomeMode;
            public float HomeMoveSp;
            public float HomeLowSp;
            public float HomeOffpos;

            public float dpos;
            public float mpos;
            public float vpSpeed;
            public float mspeed;
            public int idle;
            public int status;
        }
        public static Struct_AxisPara[] m_AxisPara = new Struct_AxisPara[8];


        //联动参数定义
        public struct struct_LinkagePara
        {
            public bool bEnable;
            public bool bDivision_Enable;
            public int nMotorAxisX;
            public int nMotorAxisY;
            public float fMotorAcc;
            public float fMotorDec;
            public float fMotorMaxSp;
            public float fMotorZsmooth;
            public float fMotorXLimit;
            public float fMotorYLimit;

            public float fXDelayTime;
            public float fYDelayTime;

		   public int nScanAxisX;
           public int nScanAxisY;
           public float fScanXLimit;
           public float fScanYLimit;
           public float fXyAngle;

        }
        public static struct_LinkagePara m_LinkAgePara = new struct_LinkagePara();


        //读取轴参数到变量
        public static void Read_AxisPara()
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                return;
            }

            int rtn = 0;
            float []fAxisPara = new float[8];

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Atype", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].atype = (int)fAxisPara[iAxis];
            }


            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Units", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].units = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "lspeed", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].lspeed = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "speed", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].speed = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "accel", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].accel = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "decel", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].decel = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "sramp", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].lspeed = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Invert_Step", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].MotorDir = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Fs_Limit", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].fsLimit = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Rs_Limit", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].rsLimit = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "fwd_In", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].fwdIn = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Rev_In", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].revIn = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Alm_In", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].almIn = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "Datum_In", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].datumIn = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "creep", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].HomeLowSp = (int)fAxisPara[iAxis];
            }

            rtn = zmcaux.ZAux_Direct_GetAllAxisPara(G_CardHandle, "DATUM_OFFSET", 8, fAxisPara);
            if (CheckError(rtn, "ZAux_Direct_GetAllAxisPara")) return;
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                ZmcCardPara.m_AxisPara[iAxis].HomeOffpos = (int)fAxisPara[iAxis];
            }

        }

        //设置轴参数
        public static void Set_AxisPara()
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                return;
            }

            int rtn = 0;
            for (int iAxis = 0; iAxis < 4; iAxis++)
            {
                rtn = zmcaux.ZAux_Direct_SetAtype(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].atype);
                if (CheckError(rtn, "ZAux_Direct_SetAtype")) return;

                rtn = zmcaux.ZAux_Direct_SetUnits(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].units);
                if (CheckError(rtn, "ZAux_Direct_SetUnits")) return;

                rtn = zmcaux.ZAux_Direct_SetLspeed(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].lspeed);
                if (CheckError(rtn, "ZAux_Direct_SetLspeed")) return;

                rtn = zmcaux.ZAux_Direct_SetSpeed(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].speed);
                if (CheckError(rtn, "ZAux_Direct_SetSpeed")) return;

                rtn = zmcaux.ZAux_Direct_SetAccel(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].accel);
                if (CheckError(rtn, "ZAux_Direct_SetAccel")) return;

                rtn = zmcaux.ZAux_Direct_SetDecel(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].decel);
                if (CheckError(rtn, "ZAux_Direct_SetDecel")) return;

                rtn = zmcaux.ZAux_Direct_SetSramp(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].sramp);
                if (CheckError(rtn, "ZAux_Direct_SetSramp")) return;

                rtn = zmcaux.ZAux_Direct_SetInvertStep(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].MotorDir);
                if (CheckError(rtn, "ZAux_Direct_SetInvertStep")) return;
                if(ZmcCardPara.m_AxisPara[iAxis].EncoderDir == 0)
                {
                    rtn = zmcaux.ZAux_Direct_EncoderRatio(G_CardHandle, iAxis, 1, 1);
                }
                else
                {
                    rtn = zmcaux.ZAux_Direct_EncoderRatio(G_CardHandle, iAxis, -1, 1);
                }
                if (CheckError(rtn, "ZAux_Direct_EncoderRatio")) return;

                rtn = zmcaux.ZAux_Direct_SetFsLimit(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].fsLimit);
                if (CheckError(rtn, "ZAux_Direct_SetFsLimit")) return;

                rtn = zmcaux.ZAux_Direct_SetRsLimit(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].rsLimit);
                if (CheckError(rtn, "ZAux_Direct_SetAccel")) return;

                rtn = zmcaux.ZAux_Direct_SetFwdIn(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].fwdIn);
                if (CheckError(rtn, "ZAux_Direct_SetFwdIn")) return;

                rtn = zmcaux.ZAux_Direct_SetRevIn(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].revIn);
                if (CheckError(rtn, "ZAux_Direct_SetRevIn")) return;

                rtn = zmcaux.ZAux_Direct_SetAlmIn(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].almIn);
                if (CheckError(rtn, "ZAux_Direct_SetAlmIn")) return;

                rtn = zmcaux.ZAux_Direct_SetDatumIn(G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].datumIn);
                if (CheckError(rtn, "ZAux_Direct_SetDatumIn")) return;

                //反转特殊常开IO,ZMC系列控制器OFF时限位，原点有效，常开IO需要反转ON
                if (m_AxisPara[iAxis].fwdIn >= 0)
                {
                    rtn = zmcaux.ZAux_Direct_SetInvertIn(G_CardHandle, m_AxisPara[iAxis].fwdIn, 1);
                    if (CheckError(rtn, "ZAux_Direct_SetInvertIn")) return;
                }

                if (m_AxisPara[iAxis].revIn >= 0)
                {
                    rtn = zmcaux.ZAux_Direct_SetInvertIn(G_CardHandle, m_AxisPara[iAxis].revIn, 1);
                    if (CheckError(rtn, "ZAux_Direct_SetInvertIn")) return;
                }

                if (m_AxisPara[iAxis].datumIn >= 0)
                {
                    rtn = zmcaux.ZAux_Direct_SetInvertIn(G_CardHandle, m_AxisPara[iAxis].datumIn, 1);
                    if (CheckError(rtn, "ZAux_Direct_SetInvertIn")) return;
                }
            }

        }

        //错误返回
        public static bool CheckError(int ErrorCode, string CmdString)
        {
            if (0 != ErrorCode)
            {
                MessageBox.Show(CmdString + "ErrorCode:" + ErrorCode);
                return true;
            }
            return false;
        }

        //振镜相关变量定义
       public struct Struct_ScanAxisPara
        {
            public int atype;       //轴类型
            public int AxisX;       
            public int AxisY;		
            public float units;
            public float lspeed;
            public float speed;
            public float accel;
            public float decel;
            public float sramp;
            public int m_ScanXyChange;
            public float fsLimit;
            public float rsLimit;

            public float dpos;
            public float mpos;
            public float vpSpeed;
            public float mspeed;
            public int idle;
            public int status;

            public string SscanCorrectFile;
        }
        public static Struct_ScanAxisPara[] m_ScanAxisPara = new Struct_ScanAxisPara[2];

        public static int m_ScanId = 0;	                        //当前振镜组
        //public static int[] m_ScanAxisList = new int[2] { 4, 5 };		//振镜轴列表
        //public static int m_ScanXyChange = 0;		                //振镜轴是否XY交换
        public static void Sel_ScanAxis()
        {
            if (ZmcCardPara.m_ScanId == 0)
            {
                if (ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].m_ScanXyChange == 0)
                {
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX = 4;
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY = 5;
                }
                else
                {
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX = 5;
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY = 4;
                }

            }
            else
            {
                if (ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].m_ScanXyChange == 0)
                {
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX = 6;
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY = 7;
                }
                else
                {
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX = 7;
                    ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY = 6;
                }
            }
        }
	
    }
}
