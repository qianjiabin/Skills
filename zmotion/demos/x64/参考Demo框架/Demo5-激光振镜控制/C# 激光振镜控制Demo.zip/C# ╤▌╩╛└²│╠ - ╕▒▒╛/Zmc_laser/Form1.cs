﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using cszmcaux;
using Zmotion_Laser;

namespace Zmc_laser
{
    public partial class Form1 : Form
    {

        // 激光器类型, 
        public enum ZMC_LASER_TYPE
        {
            FIBER_408 = 0,
            YLR_408 = 1,
            YAG_408 = 2,
            FIBER_504 = 3,
        };

        public IntPtr G_CardHandle;

        public int m_nLaserType = 0;

        public int m_nEnableIO = 47;
        public int m_nLaserIO = 8;
        public int m_nRedIO = 48;
        public int m_nAout = 3;
        public int m_nAoutVal = 128;
        public int m_nPwmIo = 9;
        public int m_nPwmFreq = 40000;
        public float m_nStartDelay = 0;
        public float m_nLastDelay = 0;
        public float m_nCorDelay = 0;

        public float m_dEmpSpeed = 3000;
        public float m_dWorkSpeed = 1000;
        public float m_dSetSpeed = 1000;

        public int[] m_AxisList = new int[2] { 4, 5 };     //振镜轴列表

        public Form1()
        {
            InitializeComponent();
        }

        //连接控制器
        private void btn_Connet_Click(object sender, EventArgs e)
        {
            int iret = 0;
            string Adrr = IPADDRESS.Text;
            if ((int)G_CardHandle == 0)
            {
                iret = zmcaux.ZAux_OpenEth(Adrr, out G_CardHandle);
            }

            if (G_CardHandle != (IntPtr)0)
            {

                this.Text = Adrr + "控制器已连接";
                Axis_Init();
            }
            else
            {
                this.Text = "未连接";
                MessageBox.Show("连接失败");
            }
        }

        //断开控制器
        private void btn_Close_Click(object sender, EventArgs e)
        {
            if (G_CardHandle != (IntPtr)0)
            {
                zmcaux.ZAux_Close(G_CardHandle);
                G_CardHandle = (IntPtr)0;
            }

            this.Text = "未连接";
        }

        //下拉搜索IP
        private void IPADDRESS_DropDown(object sender, EventArgs e)
        {
            int i, num;
            string[] sArray;
            StringBuilder buffer = new StringBuilder(10240);
            string buff = new string('0', 10240);
            zmcaux.ZAux_SearchEthlist(buffer, 10230, 200);
            buff = "" + buffer;
            sArray = buff.Split(' ');
            num = buff.Split(' ').Length;

            IPADDRESS.Items.Clear();

            IPADDRESS.Items.Insert(0, "192.168.0.11");
            for (i = 0; i < num - 1; i++)
            {
                IPADDRESS.Items.Insert(i + 1, sArray[i].ToString());
            }
        }

        //初始化轴参数
        private void Axis_Init()
        {
            int Iret = 0;

            Iret = zmcaux.ZAux_Direct_SetAtype(G_CardHandle, m_AxisList[0], 21);      //设置振镜轴类型
            Iret = zmcaux.ZAux_Direct_SetAtype(G_CardHandle, m_AxisList[1], 21);

            Iret = zmcaux.ZAux_Direct_SetUnits(G_CardHandle, m_AxisList[0], 500);      //设置脉冲当量,与校正工具校正时当量设置一致
            Iret = zmcaux.ZAux_Direct_SetUnits(G_CardHandle, m_AxisList[1], 500);

            Iret = zmcaux.ZAux_Direct_SetCornerMode(G_CardHandle, m_AxisList[0], 2);      //设置拐角减速,设置成功后MOVESCAN运动指令拐角时通过拐角角度及ZSMOOTH控制拐角延时
            Iret = zmcaux.ZAux_Direct_SetCornerMode(G_CardHandle, m_AxisList[1], 2);
        }


        //红光
        private void BTN_RED_Click(object sender, EventArgs e)
        {
            UInt32 iOpStatus = 0;
            int iret = zmcaux.ZAux_Direct_GetOp(G_CardHandle, m_nRedIO, ref iOpStatus);

            iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nRedIO, (uint)(iOpStatus == 1 ? 0 : 1));
            if (iOpStatus == 0)
            {
                iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nRedIO, 1);
                BTN_RED.Text = "红光(开)";
            }
            else
            {
                iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nRedIO, 0);
                BTN_RED.Text = "红光(关)";
            }
        }

        //激光
        private void BTN_LASER_Click(object sender, EventArgs e)
        {
            UInt32 iOpStatus = 0;
            int iret = zmcaux.ZAux_Direct_GetOp(G_CardHandle, m_nEnableIO, ref iOpStatus);

            if (iOpStatus == 0)
            {
                iret = zmcaux.ZAux_Direct_SetDA(G_CardHandle, m_nAout, m_nAoutVal);				//设置能量
                iret = zmcaux.ZAux_Direct_SetPwmDuty(G_CardHandle, m_nPwmIo, (float)0.5);		//设置PWM
                iret = zmcaux.ZAux_Direct_SetPwmFreq(G_CardHandle, m_nPwmIo, m_nPwmFreq);		//设置PWM

                iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nEnableIO, 1);				//开光
                Thread.Sleep(10);
                iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nLaserIO, 1);
                BTN_LASER.Text = "激光(开)";
            }
            else
            {
                iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nLaserIO, 0);				//关光
                Thread.Sleep(10);
                iret = zmcaux.ZAux_Direct_SetOp(G_CardHandle, m_nEnableIO, 0);
                BTN_LASER.Text = "激光(关)";
            }
        }

        //下拉切换激光器类型
        private void CCBOX_LASER_DropDownClosed(object sender, EventArgs e)
        {
            m_nLaserType = CCBOX_LASER.SelectedIndex;
            if (m_nLaserType == (int)ZMC_LASER_TYPE.FIBER_408)									//408 FIBER转换板参数设置
            {
                int iresult = zmcaux.ZAux_SetExioType(G_CardHandle,0);

                m_nEnableIO = 47;
                m_nLaserIO = 8;
                m_nRedIO = 48;
                m_nAout = 3;
                m_nPwmIo = 9;
            }
            else if (m_nLaserType == (int)ZMC_LASER_TYPE.YLR_408)
            {
                int iresult = zmcaux.ZAux_SetExioType(G_CardHandle, -1);
                m_nEnableIO = 31;
                m_nLaserIO = 8;
                m_nRedIO = 32;
                m_nAout = 2;
                m_nPwmIo = 9;
            }
            else if (m_nLaserType == (int)ZMC_LASER_TYPE.YAG_408)									//408 YAG转换板参数设置
            {
                int iresult = zmcaux.ZAux_SetExioType(G_CardHandle, 1);

                m_nEnableIO = 47;
                m_nLaserIO = 8;
                m_nRedIO = 48;
                m_nAout = 3;
                m_nPwmIo = 9;
            }
            else if (m_nLaserType == (int)ZMC_LASER_TYPE.FIBER_504)									//504
            {
                int iresult = zmcaux.ZAux_SetExioType(G_CardHandle, -1);
                m_nEnableIO = 5;
                m_nLaserIO = 6;
                m_nRedIO = 28;
                m_nAout = 2;
                m_nPwmIo = 7;
            }

            TEXT_IO_ENABLE.Text = m_nEnableIO.ToString();
            TEXT_IO_LASER.Text = m_nLaserIO.ToString();
            TEXT_IO__RED.Text = m_nRedIO.ToString();
            TEXT_AIO_POWER.Text = m_nAout.ToString();
            TEXT_IO_PWM.Text = m_nPwmIo.ToString();
        }



    }
}
