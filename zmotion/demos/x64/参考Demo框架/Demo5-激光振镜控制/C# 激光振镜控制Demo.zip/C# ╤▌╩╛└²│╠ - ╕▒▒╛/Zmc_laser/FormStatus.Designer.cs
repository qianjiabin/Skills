﻿namespace Zmc_laser
{
    partial class FormStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Tab_Status = new System.Windows.Forms.TabControl();
            this.tabPage_LocalIO = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Btn_LocalOut19 = new System.Windows.Forms.Button();
            this.Btn_LocalOut18 = new System.Windows.Forms.Button();
            this.Btn_LocalOut17 = new System.Windows.Forms.Button();
            this.Btn_LocalOut16 = new System.Windows.Forms.Button();
            this.Btn_LocalOut15 = new System.Windows.Forms.Button();
            this.Btn_LocalOut14 = new System.Windows.Forms.Button();
            this.Btn_LocalOut13 = new System.Windows.Forms.Button();
            this.Btn_LocalOut12 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.Btn_LocalOut11 = new System.Windows.Forms.Button();
            this.Btn_LocalOut10 = new System.Windows.Forms.Button();
            this.Btn_LocalOut9 = new System.Windows.Forms.Button();
            this.Btn_LocalOut8 = new System.Windows.Forms.Button();
            this.Btn_LocalOut7 = new System.Windows.Forms.Button();
            this.Btn_LocalOut6 = new System.Windows.Forms.Button();
            this.Btn_LocalOut5 = new System.Windows.Forms.Button();
            this.Btn_LocalOut4 = new System.Windows.Forms.Button();
            this.Btn_LocalOut3 = new System.Windows.Forms.Button();
            this.Btn_LocalOut2 = new System.Windows.Forms.Button();
            this.Btn_LocalOut1 = new System.Windows.Forms.Button();
            this.Btn_LocalOut0 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LocalIn23 = new System.Windows.Forms.Label();
            this.LocalIn22 = new System.Windows.Forms.Label();
            this.LocalIn21 = new System.Windows.Forms.Label();
            this.LocalIn20 = new System.Windows.Forms.Label();
            this.LocalIn19 = new System.Windows.Forms.Label();
            this.LocalIn18 = new System.Windows.Forms.Label();
            this.LocalIn17 = new System.Windows.Forms.Label();
            this.LocalIn16 = new System.Windows.Forms.Label();
            this.LocalIn15 = new System.Windows.Forms.Label();
            this.LocalIn14 = new System.Windows.Forms.Label();
            this.LocalIn13 = new System.Windows.Forms.Label();
            this.LocalIn12 = new System.Windows.Forms.Label();
            this.LocalIn11 = new System.Windows.Forms.Label();
            this.LocalIn10 = new System.Windows.Forms.Label();
            this.LocalIn9 = new System.Windows.Forms.Label();
            this.LocalIn8 = new System.Windows.Forms.Label();
            this.LocalIn7 = new System.Windows.Forms.Label();
            this.LocalIn6 = new System.Windows.Forms.Label();
            this.LocalIn5 = new System.Windows.Forms.Label();
            this.LocalIn4 = new System.Windows.Forms.Label();
            this.LocalIn3 = new System.Windows.Forms.Label();
            this.LocalIn2 = new System.Windows.Forms.Label();
            this.LocalIn1 = new System.Windows.Forms.Label();
            this.LocalIn0 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.tabPage_LaserIo = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Btn_LaserOut7 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.Btn_LaserOut6 = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.Btn_LaserOut5 = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.Btn_LaserOut4 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.Btn_LaserOut3 = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.Btn_LaserOut2 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.Btn_LaserOut1 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.Btn_LaserOut0 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.LaserIn5 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.LaserIn4 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.LaserIn3 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.LaserIn2 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.LaserIn1 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.LaserIn0 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.tabPage_FiberIo = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Btn_ExioOut13 = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.Btn_ExioOut12 = new System.Windows.Forms.Button();
            this.label69 = new System.Windows.Forms.Label();
            this.Btn_ExioOut11 = new System.Windows.Forms.Button();
            this.label70 = new System.Windows.Forms.Label();
            this.Btn_ExioOut10 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.Btn_ExioOut9 = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.Btn_ExioOut8 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.Btn_ExioOut7 = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.Btn_ExioOut6 = new System.Windows.Forms.Button();
            this.label54 = new System.Windows.Forms.Label();
            this.Btn_ExioOut5 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.Btn_ExioOut4 = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.Btn_ExioOut3 = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.Btn_ExioOut2 = new System.Windows.Forms.Button();
            this.label58 = new System.Windows.Forms.Label();
            this.Btn_ExioOut1 = new System.Windows.Forms.Button();
            this.label59 = new System.Windows.Forms.Label();
            this.Btn_ExioOut0 = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.ExioIn2 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.ExioIn1 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.ExioIn0 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Tab_Status.SuspendLayout();
            this.tabPage_LocalIO.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage_LaserIo.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage_FiberIo.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tab_Status
            // 
            this.Tab_Status.Controls.Add(this.tabPage_LocalIO);
            this.Tab_Status.Controls.Add(this.tabPage_LaserIo);
            this.Tab_Status.Controls.Add(this.tabPage_FiberIo);
            this.Tab_Status.Location = new System.Drawing.Point(1, 2);
            this.Tab_Status.Name = "Tab_Status";
            this.Tab_Status.SelectedIndex = 0;
            this.Tab_Status.Size = new System.Drawing.Size(804, 644);
            this.Tab_Status.TabIndex = 0;
            this.Tab_Status.Selected += new System.Windows.Forms.TabControlEventHandler(this.Tab_Status_Selected);
            // 
            // tabPage_LocalIO
            // 
            this.tabPage_LocalIO.Controls.Add(this.groupBox2);
            this.tabPage_LocalIO.Controls.Add(this.groupBox1);
            this.tabPage_LocalIO.Location = new System.Drawing.Point(4, 22);
            this.tabPage_LocalIO.Name = "tabPage_LocalIO";
            this.tabPage_LocalIO.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_LocalIO.Size = new System.Drawing.Size(796, 618);
            this.tabPage_LocalIO.TabIndex = 0;
            this.tabPage_LocalIO.Text = "本地IO";
            this.tabPage_LocalIO.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Location = new System.Drawing.Point(3, 275);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(789, 342);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "输出口";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Btn_LocalOut19);
            this.panel2.Controls.Add(this.Btn_LocalOut18);
            this.panel2.Controls.Add(this.Btn_LocalOut17);
            this.panel2.Controls.Add(this.Btn_LocalOut16);
            this.panel2.Controls.Add(this.Btn_LocalOut15);
            this.panel2.Controls.Add(this.Btn_LocalOut14);
            this.panel2.Controls.Add(this.Btn_LocalOut13);
            this.panel2.Controls.Add(this.Btn_LocalOut12);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.label38);
            this.panel2.Controls.Add(this.Btn_LocalOut11);
            this.panel2.Controls.Add(this.Btn_LocalOut10);
            this.panel2.Controls.Add(this.Btn_LocalOut9);
            this.panel2.Controls.Add(this.Btn_LocalOut8);
            this.panel2.Controls.Add(this.Btn_LocalOut7);
            this.panel2.Controls.Add(this.Btn_LocalOut6);
            this.panel2.Controls.Add(this.Btn_LocalOut5);
            this.panel2.Controls.Add(this.Btn_LocalOut4);
            this.panel2.Controls.Add(this.Btn_LocalOut3);
            this.panel2.Controls.Add(this.Btn_LocalOut2);
            this.panel2.Controls.Add(this.Btn_LocalOut1);
            this.panel2.Controls.Add(this.Btn_LocalOut0);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Location = new System.Drawing.Point(3, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(754, 255);
            this.panel2.TabIndex = 133;
            // 
            // Btn_LocalOut19
            // 
            this.Btn_LocalOut19.Location = new System.Drawing.Point(446, 142);
            this.Btn_LocalOut19.Name = "Btn_LocalOut19";
            this.Btn_LocalOut19.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut19.TabIndex = 132;
            this.Btn_LocalOut19.UseVisualStyleBackColor = true;
            this.Btn_LocalOut19.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut18
            // 
            this.Btn_LocalOut18.Location = new System.Drawing.Point(383, 142);
            this.Btn_LocalOut18.Name = "Btn_LocalOut18";
            this.Btn_LocalOut18.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut18.TabIndex = 131;
            this.Btn_LocalOut18.UseVisualStyleBackColor = true;
            this.Btn_LocalOut18.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut17
            // 
            this.Btn_LocalOut17.Location = new System.Drawing.Point(320, 142);
            this.Btn_LocalOut17.Name = "Btn_LocalOut17";
            this.Btn_LocalOut17.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut17.TabIndex = 130;
            this.Btn_LocalOut17.UseVisualStyleBackColor = true;
            this.Btn_LocalOut17.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut16
            // 
            this.Btn_LocalOut16.Location = new System.Drawing.Point(257, 142);
            this.Btn_LocalOut16.Name = "Btn_LocalOut16";
            this.Btn_LocalOut16.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut16.TabIndex = 129;
            this.Btn_LocalOut16.UseVisualStyleBackColor = true;
            this.Btn_LocalOut16.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut15
            // 
            this.Btn_LocalOut15.Location = new System.Drawing.Point(194, 142);
            this.Btn_LocalOut15.Name = "Btn_LocalOut15";
            this.Btn_LocalOut15.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut15.TabIndex = 128;
            this.Btn_LocalOut15.UseVisualStyleBackColor = true;
            this.Btn_LocalOut15.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut14
            // 
            this.Btn_LocalOut14.Location = new System.Drawing.Point(131, 142);
            this.Btn_LocalOut14.Name = "Btn_LocalOut14";
            this.Btn_LocalOut14.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut14.TabIndex = 127;
            this.Btn_LocalOut14.UseVisualStyleBackColor = true;
            this.Btn_LocalOut14.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut13
            // 
            this.Btn_LocalOut13.Location = new System.Drawing.Point(68, 142);
            this.Btn_LocalOut13.Name = "Btn_LocalOut13";
            this.Btn_LocalOut13.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut13.TabIndex = 126;
            this.Btn_LocalOut13.UseVisualStyleBackColor = true;
            this.Btn_LocalOut13.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut12
            // 
            this.Btn_LocalOut12.Location = new System.Drawing.Point(5, 142);
            this.Btn_LocalOut12.Name = "Btn_LocalOut12";
            this.Btn_LocalOut12.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut12.TabIndex = 125;
            this.Btn_LocalOut12.UseVisualStyleBackColor = true;
            this.Btn_LocalOut12.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(448, 113);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 12);
            this.label31.TabIndex = 124;
            this.label31.Text = "OUT19";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(196, 113);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 12);
            this.label32.TabIndex = 120;
            this.label32.Text = "OUT15";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(133, 113);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 12);
            this.label33.TabIndex = 119;
            this.label33.Text = "OUT14";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(259, 113);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(35, 12);
            this.label34.TabIndex = 121;
            this.label34.Text = "OUT16";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(70, 113);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(35, 12);
            this.label35.TabIndex = 118;
            this.label35.Text = "OUT13";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(385, 113);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(35, 12);
            this.label36.TabIndex = 123;
            this.label36.Text = "OUT18";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(322, 113);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 12);
            this.label37.TabIndex = 122;
            this.label37.Text = "OUT17";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(7, 113);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(35, 12);
            this.label38.TabIndex = 117;
            this.label38.Text = "OUT12";
            // 
            // Btn_LocalOut11
            // 
            this.Btn_LocalOut11.Location = new System.Drawing.Point(698, 41);
            this.Btn_LocalOut11.Name = "Btn_LocalOut11";
            this.Btn_LocalOut11.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut11.TabIndex = 116;
            this.Btn_LocalOut11.UseVisualStyleBackColor = true;
            this.Btn_LocalOut11.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut10
            // 
            this.Btn_LocalOut10.Location = new System.Drawing.Point(635, 41);
            this.Btn_LocalOut10.Name = "Btn_LocalOut10";
            this.Btn_LocalOut10.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut10.TabIndex = 115;
            this.Btn_LocalOut10.UseVisualStyleBackColor = true;
            this.Btn_LocalOut10.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut9
            // 
            this.Btn_LocalOut9.Location = new System.Drawing.Point(572, 41);
            this.Btn_LocalOut9.Name = "Btn_LocalOut9";
            this.Btn_LocalOut9.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut9.TabIndex = 114;
            this.Btn_LocalOut9.UseVisualStyleBackColor = true;
            this.Btn_LocalOut9.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut8
            // 
            this.Btn_LocalOut8.Location = new System.Drawing.Point(509, 41);
            this.Btn_LocalOut8.Name = "Btn_LocalOut8";
            this.Btn_LocalOut8.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut8.TabIndex = 113;
            this.Btn_LocalOut8.UseVisualStyleBackColor = true;
            this.Btn_LocalOut8.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut7
            // 
            this.Btn_LocalOut7.Location = new System.Drawing.Point(446, 41);
            this.Btn_LocalOut7.Name = "Btn_LocalOut7";
            this.Btn_LocalOut7.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut7.TabIndex = 112;
            this.Btn_LocalOut7.UseVisualStyleBackColor = true;
            this.Btn_LocalOut7.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut6
            // 
            this.Btn_LocalOut6.Location = new System.Drawing.Point(383, 41);
            this.Btn_LocalOut6.Name = "Btn_LocalOut6";
            this.Btn_LocalOut6.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut6.TabIndex = 111;
            this.Btn_LocalOut6.UseVisualStyleBackColor = true;
            this.Btn_LocalOut6.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut5
            // 
            this.Btn_LocalOut5.Location = new System.Drawing.Point(320, 41);
            this.Btn_LocalOut5.Name = "Btn_LocalOut5";
            this.Btn_LocalOut5.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut5.TabIndex = 110;
            this.Btn_LocalOut5.UseVisualStyleBackColor = true;
            this.Btn_LocalOut5.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut4
            // 
            this.Btn_LocalOut4.Location = new System.Drawing.Point(257, 41);
            this.Btn_LocalOut4.Name = "Btn_LocalOut4";
            this.Btn_LocalOut4.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut4.TabIndex = 109;
            this.Btn_LocalOut4.UseVisualStyleBackColor = true;
            this.Btn_LocalOut4.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut3
            // 
            this.Btn_LocalOut3.Location = new System.Drawing.Point(194, 41);
            this.Btn_LocalOut3.Name = "Btn_LocalOut3";
            this.Btn_LocalOut3.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut3.TabIndex = 108;
            this.Btn_LocalOut3.UseVisualStyleBackColor = true;
            this.Btn_LocalOut3.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut2
            // 
            this.Btn_LocalOut2.Location = new System.Drawing.Point(131, 41);
            this.Btn_LocalOut2.Name = "Btn_LocalOut2";
            this.Btn_LocalOut2.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut2.TabIndex = 107;
            this.Btn_LocalOut2.UseVisualStyleBackColor = true;
            this.Btn_LocalOut2.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut1
            // 
            this.Btn_LocalOut1.Location = new System.Drawing.Point(68, 41);
            this.Btn_LocalOut1.Name = "Btn_LocalOut1";
            this.Btn_LocalOut1.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut1.TabIndex = 106;
            this.Btn_LocalOut1.UseVisualStyleBackColor = true;
            this.Btn_LocalOut1.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // Btn_LocalOut0
            // 
            this.Btn_LocalOut0.Location = new System.Drawing.Point(5, 41);
            this.Btn_LocalOut0.Name = "Btn_LocalOut0";
            this.Btn_LocalOut0.Size = new System.Drawing.Size(40, 40);
            this.Btn_LocalOut0.TabIndex = 105;
            this.Btn_LocalOut0.UseVisualStyleBackColor = true;
            this.Btn_LocalOut0.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(448, 12);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 100;
            this.label19.Text = "OUT7";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(574, 12);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 102;
            this.label22.Text = "OUT9";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(511, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 101;
            this.label20.Text = "OUT8";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(196, 12);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 12);
            this.label30.TabIndex = 96;
            this.label30.Text = "OUT3";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(706, 12);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 12);
            this.label21.TabIndex = 104;
            this.label21.Text = "OUT11";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(133, 12);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 95;
            this.label29.Text = "OUT2";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(259, 12);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 12);
            this.label28.TabIndex = 97;
            this.label28.Text = "OUT4";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(637, 12);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 12);
            this.label23.TabIndex = 103;
            this.label23.Text = "OUT10";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(70, 12);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 12);
            this.label27.TabIndex = 94;
            this.label27.Text = "OUT1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(385, 12);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 99;
            this.label24.Text = "OUT6";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(322, 12);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 98;
            this.label26.Text = "OUT5";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 93;
            this.label25.Text = "OUT0";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Location = new System.Drawing.Point(0, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(793, 254);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "输入口";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LocalIn23);
            this.panel1.Controls.Add(this.LocalIn22);
            this.panel1.Controls.Add(this.LocalIn21);
            this.panel1.Controls.Add(this.LocalIn20);
            this.panel1.Controls.Add(this.LocalIn19);
            this.panel1.Controls.Add(this.LocalIn18);
            this.panel1.Controls.Add(this.LocalIn17);
            this.panel1.Controls.Add(this.LocalIn16);
            this.panel1.Controls.Add(this.LocalIn15);
            this.panel1.Controls.Add(this.LocalIn14);
            this.panel1.Controls.Add(this.LocalIn13);
            this.panel1.Controls.Add(this.LocalIn12);
            this.panel1.Controls.Add(this.LocalIn11);
            this.panel1.Controls.Add(this.LocalIn10);
            this.panel1.Controls.Add(this.LocalIn9);
            this.panel1.Controls.Add(this.LocalIn8);
            this.panel1.Controls.Add(this.LocalIn7);
            this.panel1.Controls.Add(this.LocalIn6);
            this.panel1.Controls.Add(this.LocalIn5);
            this.panel1.Controls.Add(this.LocalIn4);
            this.panel1.Controls.Add(this.LocalIn3);
            this.panel1.Controls.Add(this.LocalIn2);
            this.panel1.Controls.Add(this.LocalIn1);
            this.panel1.Controls.Add(this.LocalIn0);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label63);
            this.panel1.Controls.Add(this.label64);
            this.panel1.Controls.Add(this.label62);
            this.panel1.Controls.Add(this.label65);
            this.panel1.Controls.Add(this.label61);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Location = new System.Drawing.Point(13, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(766, 226);
            this.panel1.TabIndex = 93;
            // 
            // LocalIn23
            // 
            this.LocalIn23.Location = new System.Drawing.Point(693, 149);
            this.LocalIn23.Name = "LocalIn23";
            this.LocalIn23.Size = new System.Drawing.Size(40, 40);
            this.LocalIn23.TabIndex = 92;
            this.LocalIn23.Text = "off";
            this.LocalIn23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn22
            // 
            this.LocalIn22.Location = new System.Drawing.Point(630, 149);
            this.LocalIn22.Name = "LocalIn22";
            this.LocalIn22.Size = new System.Drawing.Size(40, 40);
            this.LocalIn22.TabIndex = 91;
            this.LocalIn22.Text = "off";
            this.LocalIn22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn21
            // 
            this.LocalIn21.Location = new System.Drawing.Point(567, 149);
            this.LocalIn21.Name = "LocalIn21";
            this.LocalIn21.Size = new System.Drawing.Size(40, 40);
            this.LocalIn21.TabIndex = 90;
            this.LocalIn21.Text = "off";
            this.LocalIn21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn20
            // 
            this.LocalIn20.Location = new System.Drawing.Point(504, 149);
            this.LocalIn20.Name = "LocalIn20";
            this.LocalIn20.Size = new System.Drawing.Size(40, 40);
            this.LocalIn20.TabIndex = 89;
            this.LocalIn20.Text = "off";
            this.LocalIn20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn19
            // 
            this.LocalIn19.Location = new System.Drawing.Point(441, 149);
            this.LocalIn19.Name = "LocalIn19";
            this.LocalIn19.Size = new System.Drawing.Size(40, 40);
            this.LocalIn19.TabIndex = 88;
            this.LocalIn19.Text = "off";
            this.LocalIn19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn18
            // 
            this.LocalIn18.Location = new System.Drawing.Point(378, 149);
            this.LocalIn18.Name = "LocalIn18";
            this.LocalIn18.Size = new System.Drawing.Size(40, 40);
            this.LocalIn18.TabIndex = 87;
            this.LocalIn18.Text = "off";
            this.LocalIn18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn17
            // 
            this.LocalIn17.Location = new System.Drawing.Point(315, 149);
            this.LocalIn17.Name = "LocalIn17";
            this.LocalIn17.Size = new System.Drawing.Size(40, 40);
            this.LocalIn17.TabIndex = 86;
            this.LocalIn17.Text = "off";
            this.LocalIn17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn16
            // 
            this.LocalIn16.Location = new System.Drawing.Point(252, 149);
            this.LocalIn16.Name = "LocalIn16";
            this.LocalIn16.Size = new System.Drawing.Size(40, 40);
            this.LocalIn16.TabIndex = 85;
            this.LocalIn16.Text = "off";
            this.LocalIn16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn15
            // 
            this.LocalIn15.Location = new System.Drawing.Point(189, 149);
            this.LocalIn15.Name = "LocalIn15";
            this.LocalIn15.Size = new System.Drawing.Size(40, 40);
            this.LocalIn15.TabIndex = 84;
            this.LocalIn15.Text = "off";
            this.LocalIn15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn14
            // 
            this.LocalIn14.Location = new System.Drawing.Point(126, 149);
            this.LocalIn14.Name = "LocalIn14";
            this.LocalIn14.Size = new System.Drawing.Size(40, 40);
            this.LocalIn14.TabIndex = 83;
            this.LocalIn14.Text = "off";
            this.LocalIn14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn13
            // 
            this.LocalIn13.Location = new System.Drawing.Point(63, 149);
            this.LocalIn13.Name = "LocalIn13";
            this.LocalIn13.Size = new System.Drawing.Size(40, 40);
            this.LocalIn13.TabIndex = 82;
            this.LocalIn13.Text = "off";
            this.LocalIn13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn12
            // 
            this.LocalIn12.Location = new System.Drawing.Point(5, 149);
            this.LocalIn12.Name = "LocalIn12";
            this.LocalIn12.Size = new System.Drawing.Size(40, 40);
            this.LocalIn12.TabIndex = 81;
            this.LocalIn12.Text = "off";
            this.LocalIn12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn11
            // 
            this.LocalIn11.Location = new System.Drawing.Point(693, 37);
            this.LocalIn11.Name = "LocalIn11";
            this.LocalIn11.Size = new System.Drawing.Size(40, 40);
            this.LocalIn11.TabIndex = 80;
            this.LocalIn11.Text = "off";
            this.LocalIn11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn10
            // 
            this.LocalIn10.Location = new System.Drawing.Point(630, 37);
            this.LocalIn10.Name = "LocalIn10";
            this.LocalIn10.Size = new System.Drawing.Size(40, 40);
            this.LocalIn10.TabIndex = 79;
            this.LocalIn10.Text = "off";
            this.LocalIn10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn9
            // 
            this.LocalIn9.Location = new System.Drawing.Point(567, 37);
            this.LocalIn9.Name = "LocalIn9";
            this.LocalIn9.Size = new System.Drawing.Size(40, 40);
            this.LocalIn9.TabIndex = 78;
            this.LocalIn9.Text = "off";
            this.LocalIn9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn8
            // 
            this.LocalIn8.Location = new System.Drawing.Point(504, 37);
            this.LocalIn8.Name = "LocalIn8";
            this.LocalIn8.Size = new System.Drawing.Size(40, 40);
            this.LocalIn8.TabIndex = 77;
            this.LocalIn8.Text = "off";
            this.LocalIn8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn7
            // 
            this.LocalIn7.Location = new System.Drawing.Point(441, 37);
            this.LocalIn7.Name = "LocalIn7";
            this.LocalIn7.Size = new System.Drawing.Size(40, 40);
            this.LocalIn7.TabIndex = 76;
            this.LocalIn7.Text = "off";
            this.LocalIn7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn6
            // 
            this.LocalIn6.Location = new System.Drawing.Point(378, 37);
            this.LocalIn6.Name = "LocalIn6";
            this.LocalIn6.Size = new System.Drawing.Size(40, 40);
            this.LocalIn6.TabIndex = 75;
            this.LocalIn6.Text = "off";
            this.LocalIn6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn5
            // 
            this.LocalIn5.Location = new System.Drawing.Point(315, 37);
            this.LocalIn5.Name = "LocalIn5";
            this.LocalIn5.Size = new System.Drawing.Size(40, 40);
            this.LocalIn5.TabIndex = 74;
            this.LocalIn5.Text = "off";
            this.LocalIn5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn4
            // 
            this.LocalIn4.Location = new System.Drawing.Point(252, 37);
            this.LocalIn4.Name = "LocalIn4";
            this.LocalIn4.Size = new System.Drawing.Size(40, 40);
            this.LocalIn4.TabIndex = 73;
            this.LocalIn4.Text = "off";
            this.LocalIn4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn3
            // 
            this.LocalIn3.Location = new System.Drawing.Point(189, 37);
            this.LocalIn3.Name = "LocalIn3";
            this.LocalIn3.Size = new System.Drawing.Size(40, 40);
            this.LocalIn3.TabIndex = 72;
            this.LocalIn3.Text = "off";
            this.LocalIn3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn2
            // 
            this.LocalIn2.Location = new System.Drawing.Point(126, 37);
            this.LocalIn2.Name = "LocalIn2";
            this.LocalIn2.Size = new System.Drawing.Size(40, 40);
            this.LocalIn2.TabIndex = 71;
            this.LocalIn2.Text = "off";
            this.LocalIn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn1
            // 
            this.LocalIn1.Location = new System.Drawing.Point(63, 37);
            this.LocalIn1.Name = "LocalIn1";
            this.LocalIn1.Size = new System.Drawing.Size(40, 40);
            this.LocalIn1.TabIndex = 70;
            this.LocalIn1.Text = "off";
            this.LocalIn1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LocalIn0
            // 
            this.LocalIn0.Location = new System.Drawing.Point(5, 37);
            this.LocalIn0.Name = "LocalIn0";
            this.LocalIn0.Size = new System.Drawing.Size(40, 40);
            this.LocalIn0.TabIndex = 69;
            this.LocalIn0.Text = "off";
            this.LocalIn0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(447, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 64;
            this.label2.Text = "in19";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(510, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 65;
            this.label4.Text = "in20";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(705, 109);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 68;
            this.label9.Text = "in23";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(573, 109);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 66;
            this.label10.Text = "in21";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(636, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 67;
            this.label11.Text = "in22";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(384, 109);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 63;
            this.label12.Text = "in18";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 109);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 57;
            this.label13.Text = "in12";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(321, 109);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 62;
            this.label14.Text = "in17";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(69, 109);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 58;
            this.label15.Text = "in13";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(258, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 61;
            this.label16.Text = "in16";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(132, 109);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 59;
            this.label17.Text = "in14";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(195, 109);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 60;
            this.label18.Text = "in15";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(447, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 12);
            this.label3.TabIndex = 52;
            this.label3.Text = "in7";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(510, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 53;
            this.label5.Text = "in8";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(705, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 56;
            this.label6.Text = "in11";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(573, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 12);
            this.label7.TabIndex = 54;
            this.label7.Text = "in9";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(636, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 55;
            this.label8.Text = "in10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(384, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 12);
            this.label1.TabIndex = 51;
            this.label1.Text = "in6";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(6, 5);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(23, 12);
            this.label63.TabIndex = 44;
            this.label63.Text = "in0";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(321, 5);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(23, 12);
            this.label64.TabIndex = 50;
            this.label64.Text = "in5";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(69, 5);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(23, 12);
            this.label62.TabIndex = 46;
            this.label62.Text = "in1";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(258, 5);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(23, 12);
            this.label65.TabIndex = 49;
            this.label65.Text = "in4";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(132, 5);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(23, 12);
            this.label61.TabIndex = 47;
            this.label61.Text = "in2";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(195, 5);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(23, 12);
            this.label60.TabIndex = 48;
            this.label60.Text = "in3";
            // 
            // tabPage_LaserIo
            // 
            this.tabPage_LaserIo.Controls.Add(this.groupBox4);
            this.tabPage_LaserIo.Controls.Add(this.groupBox3);
            this.tabPage_LaserIo.Location = new System.Drawing.Point(4, 22);
            this.tabPage_LaserIo.Name = "tabPage_LaserIo";
            this.tabPage_LaserIo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_LaserIo.Size = new System.Drawing.Size(796, 618);
            this.tabPage_LaserIo.TabIndex = 1;
            this.tabPage_LaserIo.Text = "Laser接口IO";
            this.tabPage_LaserIo.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Location = new System.Drawing.Point(242, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(234, 599);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "输出口";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.Btn_LaserOut7);
            this.panel4.Controls.Add(this.label52);
            this.panel4.Controls.Add(this.Btn_LaserOut6);
            this.panel4.Controls.Add(this.label51);
            this.panel4.Controls.Add(this.Btn_LaserOut5);
            this.panel4.Controls.Add(this.label49);
            this.panel4.Controls.Add(this.Btn_LaserOut4);
            this.panel4.Controls.Add(this.label47);
            this.panel4.Controls.Add(this.Btn_LaserOut3);
            this.panel4.Controls.Add(this.label45);
            this.panel4.Controls.Add(this.Btn_LaserOut2);
            this.panel4.Controls.Add(this.label43);
            this.panel4.Controls.Add(this.Btn_LaserOut1);
            this.panel4.Controls.Add(this.label41);
            this.panel4.Controls.Add(this.Btn_LaserOut0);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Location = new System.Drawing.Point(6, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(222, 573);
            this.panel4.TabIndex = 1;
            // 
            // Btn_LaserOut7
            // 
            this.Btn_LaserOut7.Location = new System.Drawing.Point(122, 384);
            this.Btn_LaserOut7.Name = "Btn_LaserOut7";
            this.Btn_LaserOut7.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut7.TabIndex = 121;
            this.Btn_LaserOut7.UseVisualStyleBackColor = true;
            this.Btn_LaserOut7.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(19, 398);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(47, 12);
            this.label52.TabIndex = 120;
            this.label52.Text = "PWM输出";
            // 
            // Btn_LaserOut6
            // 
            this.Btn_LaserOut6.Location = new System.Drawing.Point(122, 332);
            this.Btn_LaserOut6.Name = "Btn_LaserOut6";
            this.Btn_LaserOut6.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut6.TabIndex = 119;
            this.Btn_LaserOut6.UseVisualStyleBackColor = true;
            this.Btn_LaserOut6.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(19, 346);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(77, 12);
            this.label51.TabIndex = 118;
            this.label51.Text = "调制开光信号";
            // 
            // Btn_LaserOut5
            // 
            this.Btn_LaserOut5.Location = new System.Drawing.Point(122, 280);
            this.Btn_LaserOut5.Name = "Btn_LaserOut5";
            this.Btn_LaserOut5.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut5.TabIndex = 117;
            this.Btn_LaserOut5.UseVisualStyleBackColor = true;
            this.Btn_LaserOut5.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(19, 294);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(35, 12);
            this.label49.TabIndex = 116;
            this.label49.Text = "OUT33";
            // 
            // Btn_LaserOut4
            // 
            this.Btn_LaserOut4.Location = new System.Drawing.Point(122, 228);
            this.Btn_LaserOut4.Name = "Btn_LaserOut4";
            this.Btn_LaserOut4.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut4.TabIndex = 115;
            this.Btn_LaserOut4.UseVisualStyleBackColor = true;
            this.Btn_LaserOut4.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(19, 242);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(77, 12);
            this.label47.TabIndex = 114;
            this.label47.Text = "红光控制输出";
            // 
            // Btn_LaserOut3
            // 
            this.Btn_LaserOut3.Location = new System.Drawing.Point(122, 176);
            this.Btn_LaserOut3.Name = "Btn_LaserOut3";
            this.Btn_LaserOut3.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut3.TabIndex = 113;
            this.Btn_LaserOut3.UseVisualStyleBackColor = true;
            this.Btn_LaserOut3.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(19, 190);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(89, 12);
            this.label45.TabIndex = 112;
            this.label45.Text = "激光器使能输出";
            // 
            // Btn_LaserOut2
            // 
            this.Btn_LaserOut2.Location = new System.Drawing.Point(122, 124);
            this.Btn_LaserOut2.Name = "Btn_LaserOut2";
            this.Btn_LaserOut2.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut2.TabIndex = 111;
            this.Btn_LaserOut2.UseVisualStyleBackColor = true;
            this.Btn_LaserOut2.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(19, 138);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(89, 12);
            this.label43.TabIndex = 110;
            this.label43.Text = "激光器复位输出";
            // 
            // Btn_LaserOut1
            // 
            this.Btn_LaserOut1.Location = new System.Drawing.Point(122, 72);
            this.Btn_LaserOut1.Name = "Btn_LaserOut1";
            this.Btn_LaserOut1.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut1.TabIndex = 109;
            this.Btn_LaserOut1.UseVisualStyleBackColor = true;
            this.Btn_LaserOut1.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(19, 86);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(77, 12);
            this.label41.TabIndex = 108;
            this.label41.Text = "程序开始输出";
            // 
            // Btn_LaserOut0
            // 
            this.Btn_LaserOut0.Location = new System.Drawing.Point(122, 20);
            this.Btn_LaserOut0.Name = "Btn_LaserOut0";
            this.Btn_LaserOut0.Size = new System.Drawing.Size(40, 40);
            this.Btn_LaserOut0.TabIndex = 107;
            this.Btn_LaserOut0.UseVisualStyleBackColor = true;
            this.Btn_LaserOut0.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(19, 34);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(77, 12);
            this.label39.TabIndex = 106;
            this.label39.Text = "激光请求输出";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel3);
            this.groupBox3.Location = new System.Drawing.Point(2, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(234, 599);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "输入口";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.LaserIn5);
            this.panel3.Controls.Add(this.label50);
            this.panel3.Controls.Add(this.LaserIn4);
            this.panel3.Controls.Add(this.label48);
            this.panel3.Controls.Add(this.LaserIn3);
            this.panel3.Controls.Add(this.label46);
            this.panel3.Controls.Add(this.LaserIn2);
            this.panel3.Controls.Add(this.label44);
            this.panel3.Controls.Add(this.LaserIn1);
            this.panel3.Controls.Add(this.label42);
            this.panel3.Controls.Add(this.LaserIn0);
            this.panel3.Controls.Add(this.label40);
            this.panel3.Location = new System.Drawing.Point(6, 20);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(222, 573);
            this.panel3.TabIndex = 0;
            // 
            // LaserIn5
            // 
            this.LaserIn5.Location = new System.Drawing.Point(124, 294);
            this.LaserIn5.Name = "LaserIn5";
            this.LaserIn5.Size = new System.Drawing.Size(40, 40);
            this.LaserIn5.TabIndex = 81;
            this.LaserIn5.Text = "off";
            this.LaserIn5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(20, 308);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(89, 12);
            this.label50.TabIndex = 80;
            this.label50.Text = "主电源启动输入";
            // 
            // LaserIn4
            // 
            this.LaserIn4.Location = new System.Drawing.Point(124, 239);
            this.LaserIn4.Name = "LaserIn4";
            this.LaserIn4.Size = new System.Drawing.Size(40, 40);
            this.LaserIn4.TabIndex = 79;
            this.LaserIn4.Text = "off";
            this.LaserIn4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(20, 253);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(77, 12);
            this.label48.TabIndex = 78;
            this.label48.Text = "上电状态输入";
            // 
            // LaserIn3
            // 
            this.LaserIn3.Location = new System.Drawing.Point(124, 184);
            this.LaserIn3.Name = "LaserIn3";
            this.LaserIn3.Size = new System.Drawing.Size(40, 40);
            this.LaserIn3.TabIndex = 77;
            this.LaserIn3.Text = "off";
            this.LaserIn3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(20, 198);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(77, 12);
            this.label46.TabIndex = 76;
            this.label46.Text = "待机状态输入";
            // 
            // LaserIn2
            // 
            this.LaserIn2.Location = new System.Drawing.Point(124, 129);
            this.LaserIn2.Name = "LaserIn2";
            this.LaserIn2.Size = new System.Drawing.Size(40, 40);
            this.LaserIn2.TabIndex = 75;
            this.LaserIn2.Text = "off";
            this.LaserIn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(20, 143);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(77, 12);
            this.label44.TabIndex = 74;
            this.label44.Text = "就绪状态输入";
            // 
            // LaserIn1
            // 
            this.LaserIn1.Location = new System.Drawing.Point(124, 74);
            this.LaserIn1.Name = "LaserIn1";
            this.LaserIn1.Size = new System.Drawing.Size(40, 40);
            this.LaserIn1.TabIndex = 73;
            this.LaserIn1.Text = "off";
            this.LaserIn1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(20, 88);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(77, 12);
            this.label42.TabIndex = 72;
            this.label42.Text = "激光发射输入";
            // 
            // LaserIn0
            // 
            this.LaserIn0.Location = new System.Drawing.Point(124, 19);
            this.LaserIn0.Name = "LaserIn0";
            this.LaserIn0.Size = new System.Drawing.Size(40, 40);
            this.LaserIn0.TabIndex = 71;
            this.LaserIn0.Text = "off";
            this.LaserIn0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(20, 33);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(89, 12);
            this.label40.TabIndex = 70;
            this.label40.Text = "激光器报警输入";
            // 
            // tabPage_FiberIo
            // 
            this.tabPage_FiberIo.Controls.Add(this.groupBox5);
            this.tabPage_FiberIo.Controls.Add(this.groupBox6);
            this.tabPage_FiberIo.Location = new System.Drawing.Point(4, 22);
            this.tabPage_FiberIo.Name = "tabPage_FiberIo";
            this.tabPage_FiberIo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_FiberIo.Size = new System.Drawing.Size(796, 618);
            this.tabPage_FiberIo.TabIndex = 2;
            this.tabPage_FiberIo.Text = "EXIO接口IO";
            this.tabPage_FiberIo.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.panel6);
            this.groupBox5.Location = new System.Drawing.Point(247, 8);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(378, 599);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "输出口";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.Btn_ExioOut13);
            this.panel6.Controls.Add(this.label68);
            this.panel6.Controls.Add(this.Btn_ExioOut12);
            this.panel6.Controls.Add(this.label69);
            this.panel6.Controls.Add(this.Btn_ExioOut11);
            this.panel6.Controls.Add(this.label70);
            this.panel6.Controls.Add(this.Btn_ExioOut10);
            this.panel6.Controls.Add(this.label71);
            this.panel6.Controls.Add(this.Btn_ExioOut9);
            this.panel6.Controls.Add(this.label72);
            this.panel6.Controls.Add(this.Btn_ExioOut8);
            this.panel6.Controls.Add(this.label67);
            this.panel6.Controls.Add(this.Btn_ExioOut7);
            this.panel6.Controls.Add(this.label53);
            this.panel6.Controls.Add(this.Btn_ExioOut6);
            this.panel6.Controls.Add(this.label54);
            this.panel6.Controls.Add(this.Btn_ExioOut5);
            this.panel6.Controls.Add(this.label55);
            this.panel6.Controls.Add(this.Btn_ExioOut4);
            this.panel6.Controls.Add(this.label56);
            this.panel6.Controls.Add(this.Btn_ExioOut3);
            this.panel6.Controls.Add(this.label57);
            this.panel6.Controls.Add(this.Btn_ExioOut2);
            this.panel6.Controls.Add(this.label58);
            this.panel6.Controls.Add(this.Btn_ExioOut1);
            this.panel6.Controls.Add(this.label59);
            this.panel6.Controls.Add(this.Btn_ExioOut0);
            this.panel6.Controls.Add(this.label66);
            this.panel6.Location = new System.Drawing.Point(6, 19);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(366, 573);
            this.panel6.TabIndex = 1;
            // 
            // Btn_ExioOut13
            // 
            this.Btn_ExioOut13.Location = new System.Drawing.Point(302, 232);
            this.Btn_ExioOut13.Name = "Btn_ExioOut13";
            this.Btn_ExioOut13.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut13.TabIndex = 133;
            this.Btn_ExioOut13.UseVisualStyleBackColor = true;
            this.Btn_ExioOut13.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(192, 246);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(53, 12);
            this.label68.TabIndex = 132;
            this.label68.Text = "急停信号";
            // 
            // Btn_ExioOut12
            // 
            this.Btn_ExioOut12.Location = new System.Drawing.Point(302, 179);
            this.Btn_ExioOut12.Name = "Btn_ExioOut12";
            this.Btn_ExioOut12.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut12.TabIndex = 131;
            this.Btn_ExioOut12.UseVisualStyleBackColor = true;
            this.Btn_ExioOut12.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(192, 193);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(53, 12);
            this.label69.TabIndex = 130;
            this.label69.Text = "红光信号";
            // 
            // Btn_ExioOut11
            // 
            this.Btn_ExioOut11.Location = new System.Drawing.Point(302, 126);
            this.Btn_ExioOut11.Name = "Btn_ExioOut11";
            this.Btn_ExioOut11.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut11.TabIndex = 129;
            this.Btn_ExioOut11.UseVisualStyleBackColor = true;
            this.Btn_ExioOut11.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(192, 140);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(77, 12);
            this.label70.TabIndex = 128;
            this.label70.Text = "激光频率信号";
            // 
            // Btn_ExioOut10
            // 
            this.Btn_ExioOut10.Location = new System.Drawing.Point(302, 73);
            this.Btn_ExioOut10.Name = "Btn_ExioOut10";
            this.Btn_ExioOut10.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut10.TabIndex = 127;
            this.Btn_ExioOut10.UseVisualStyleBackColor = true;
            this.Btn_ExioOut10.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(192, 87);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(89, 12);
            this.label71.TabIndex = 126;
            this.label71.Text = "激光器调制信号";
            // 
            // Btn_ExioOut9
            // 
            this.Btn_ExioOut9.Location = new System.Drawing.Point(302, 20);
            this.Btn_ExioOut9.Name = "Btn_ExioOut9";
            this.Btn_ExioOut9.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut9.TabIndex = 125;
            this.Btn_ExioOut9.UseVisualStyleBackColor = true;
            this.Btn_ExioOut9.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(192, 34);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(101, 12);
            this.label72.TabIndex = 124;
            this.label72.Text = "主振荡器开关信号";
            // 
            // Btn_ExioOut8
            // 
            this.Btn_ExioOut8.Location = new System.Drawing.Point(106, 444);
            this.Btn_ExioOut8.Name = "Btn_ExioOut8";
            this.Btn_ExioOut8.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut8.TabIndex = 123;
            this.Btn_ExioOut8.UseVisualStyleBackColor = true;
            this.Btn_ExioOut8.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(10, 458);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(53, 12);
            this.label67.TabIndex = 122;
            this.label67.Text = "功率锁存";
            // 
            // Btn_ExioOut7
            // 
            this.Btn_ExioOut7.Location = new System.Drawing.Point(106, 391);
            this.Btn_ExioOut7.Name = "Btn_ExioOut7";
            this.Btn_ExioOut7.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut7.TabIndex = 121;
            this.Btn_ExioOut7.UseVisualStyleBackColor = true;
            this.Btn_ExioOut7.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(10, 405);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(77, 12);
            this.label53.TabIndex = 120;
            this.label53.Text = "功率设定位D7";
            // 
            // Btn_ExioOut6
            // 
            this.Btn_ExioOut6.Location = new System.Drawing.Point(106, 338);
            this.Btn_ExioOut6.Name = "Btn_ExioOut6";
            this.Btn_ExioOut6.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut6.TabIndex = 119;
            this.Btn_ExioOut6.UseVisualStyleBackColor = true;
            this.Btn_ExioOut6.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(10, 352);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(77, 12);
            this.label54.TabIndex = 118;
            this.label54.Text = "功率设定位D6";
            // 
            // Btn_ExioOut5
            // 
            this.Btn_ExioOut5.Location = new System.Drawing.Point(106, 285);
            this.Btn_ExioOut5.Name = "Btn_ExioOut5";
            this.Btn_ExioOut5.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut5.TabIndex = 117;
            this.Btn_ExioOut5.UseVisualStyleBackColor = true;
            this.Btn_ExioOut5.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(10, 299);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(77, 12);
            this.label55.TabIndex = 116;
            this.label55.Text = "功率设定位D5";
            // 
            // Btn_ExioOut4
            // 
            this.Btn_ExioOut4.Location = new System.Drawing.Point(106, 232);
            this.Btn_ExioOut4.Name = "Btn_ExioOut4";
            this.Btn_ExioOut4.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut4.TabIndex = 115;
            this.Btn_ExioOut4.UseVisualStyleBackColor = true;
            this.Btn_ExioOut4.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(10, 246);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(77, 12);
            this.label56.TabIndex = 114;
            this.label56.Text = "功率设定位D4";
            // 
            // Btn_ExioOut3
            // 
            this.Btn_ExioOut3.Location = new System.Drawing.Point(106, 179);
            this.Btn_ExioOut3.Name = "Btn_ExioOut3";
            this.Btn_ExioOut3.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut3.TabIndex = 113;
            this.Btn_ExioOut3.UseVisualStyleBackColor = true;
            this.Btn_ExioOut3.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(10, 193);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(77, 12);
            this.label57.TabIndex = 112;
            this.label57.Text = "功率设定位D3";
            // 
            // Btn_ExioOut2
            // 
            this.Btn_ExioOut2.Location = new System.Drawing.Point(106, 126);
            this.Btn_ExioOut2.Name = "Btn_ExioOut2";
            this.Btn_ExioOut2.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut2.TabIndex = 111;
            this.Btn_ExioOut2.UseVisualStyleBackColor = true;
            this.Btn_ExioOut2.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(10, 140);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(77, 12);
            this.label58.TabIndex = 110;
            this.label58.Text = "功率设定位D2";
            // 
            // Btn_ExioOut1
            // 
            this.Btn_ExioOut1.Location = new System.Drawing.Point(106, 73);
            this.Btn_ExioOut1.Name = "Btn_ExioOut1";
            this.Btn_ExioOut1.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut1.TabIndex = 109;
            this.Btn_ExioOut1.UseVisualStyleBackColor = true;
            this.Btn_ExioOut1.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(10, 87);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(77, 12);
            this.label59.TabIndex = 108;
            this.label59.Text = "功率设定位D1";
            // 
            // Btn_ExioOut0
            // 
            this.Btn_ExioOut0.Location = new System.Drawing.Point(106, 20);
            this.Btn_ExioOut0.Name = "Btn_ExioOut0";
            this.Btn_ExioOut0.Size = new System.Drawing.Size(40, 40);
            this.Btn_ExioOut0.TabIndex = 107;
            this.Btn_ExioOut0.UseVisualStyleBackColor = true;
            this.Btn_ExioOut0.Click += new System.EventHandler(this.Btn_OutClick);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(10, 34);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(77, 12);
            this.label66.TabIndex = 106;
            this.label66.Text = "功率设定位D0";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.panel5);
            this.groupBox6.Location = new System.Drawing.Point(7, 8);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(234, 599);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "输入口";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.ExioIn2);
            this.panel5.Controls.Add(this.label74);
            this.panel5.Controls.Add(this.ExioIn1);
            this.panel5.Controls.Add(this.label76);
            this.panel5.Controls.Add(this.ExioIn0);
            this.panel5.Controls.Add(this.label78);
            this.panel5.Location = new System.Drawing.Point(6, 20);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(222, 573);
            this.panel5.TabIndex = 0;
            // 
            // ExioIn2
            // 
            this.ExioIn2.Location = new System.Drawing.Point(124, 129);
            this.ExioIn2.Name = "ExioIn2";
            this.ExioIn2.Size = new System.Drawing.Size(40, 40);
            this.ExioIn2.TabIndex = 75;
            this.ExioIn2.Text = "off";
            this.ExioIn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(20, 143);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(29, 12);
            this.label74.TabIndex = 74;
            this.label74.Text = "STA2";
            // 
            // ExioIn1
            // 
            this.ExioIn1.Location = new System.Drawing.Point(124, 74);
            this.ExioIn1.Name = "ExioIn1";
            this.ExioIn1.Size = new System.Drawing.Size(40, 40);
            this.ExioIn1.TabIndex = 73;
            this.ExioIn1.Text = "off";
            this.ExioIn1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(20, 88);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(29, 12);
            this.label76.TabIndex = 72;
            this.label76.Text = "STA1";
            // 
            // ExioIn0
            // 
            this.ExioIn0.Location = new System.Drawing.Point(124, 19);
            this.ExioIn0.Name = "ExioIn0";
            this.ExioIn0.Size = new System.Drawing.Size(40, 40);
            this.ExioIn0.TabIndex = 71;
            this.ExioIn0.Text = "off";
            this.ExioIn0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(20, 33);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(29, 12);
            this.label78.TabIndex = 70;
            this.label78.Text = "STA0";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // FormStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 641);
            this.Controls.Add(this.Tab_Status);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormStatus";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "状态监控";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormStatus_FormClosed);
            this.Load += new System.EventHandler(this.FormStatus_Load);
            this.Tab_Status.ResumeLayout(false);
            this.tabPage_LocalIO.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage_LaserIo.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage_FiberIo.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Tab_Status;
        private System.Windows.Forms.TabPage tabPage_LocalIO;
        private System.Windows.Forms.TabPage tabPage_LaserIo;
        private System.Windows.Forms.TabPage tabPage_FiberIo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_LocalOut19;
        private System.Windows.Forms.Button Btn_LocalOut18;
        private System.Windows.Forms.Button Btn_LocalOut17;
        private System.Windows.Forms.Button Btn_LocalOut16;
        private System.Windows.Forms.Button Btn_LocalOut15;
        private System.Windows.Forms.Button Btn_LocalOut14;
        private System.Windows.Forms.Button Btn_LocalOut13;
        private System.Windows.Forms.Button Btn_LocalOut12;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button Btn_LocalOut11;
        private System.Windows.Forms.Button Btn_LocalOut10;
        private System.Windows.Forms.Button Btn_LocalOut9;
        private System.Windows.Forms.Button Btn_LocalOut8;
        private System.Windows.Forms.Button Btn_LocalOut7;
        private System.Windows.Forms.Button Btn_LocalOut6;
        private System.Windows.Forms.Button Btn_LocalOut5;
        private System.Windows.Forms.Button Btn_LocalOut4;
        private System.Windows.Forms.Button Btn_LocalOut3;
        private System.Windows.Forms.Button Btn_LocalOut2;
        private System.Windows.Forms.Button Btn_LocalOut1;
        private System.Windows.Forms.Button Btn_LocalOut0;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LocalIn23;
        private System.Windows.Forms.Label LocalIn22;
        private System.Windows.Forms.Label LocalIn21;
        private System.Windows.Forms.Label LocalIn20;
        private System.Windows.Forms.Label LocalIn19;
        private System.Windows.Forms.Label LocalIn18;
        private System.Windows.Forms.Label LocalIn17;
        private System.Windows.Forms.Label LocalIn16;
        private System.Windows.Forms.Label LocalIn15;
        private System.Windows.Forms.Label LocalIn14;
        private System.Windows.Forms.Label LocalIn13;
        private System.Windows.Forms.Label LocalIn12;
        private System.Windows.Forms.Label LocalIn11;
        private System.Windows.Forms.Label LocalIn10;
        private System.Windows.Forms.Label LocalIn9;
        private System.Windows.Forms.Label LocalIn8;
        private System.Windows.Forms.Label LocalIn7;
        private System.Windows.Forms.Label LocalIn6;
        private System.Windows.Forms.Label LocalIn5;
        private System.Windows.Forms.Label LocalIn4;
        private System.Windows.Forms.Label LocalIn3;
        private System.Windows.Forms.Label LocalIn2;
        private System.Windows.Forms.Label LocalIn1;
        private System.Windows.Forms.Label LocalIn0;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label LaserIn5;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label LaserIn4;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label LaserIn3;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label LaserIn2;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label LaserIn1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label LaserIn0;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button Btn_LaserOut7;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button Btn_LaserOut6;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button Btn_LaserOut5;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button Btn_LaserOut4;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button Btn_LaserOut3;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button Btn_LaserOut2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button Btn_LaserOut1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button Btn_LaserOut0;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button Btn_ExioOut13;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Button Btn_ExioOut12;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Button Btn_ExioOut11;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button Btn_ExioOut10;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Button Btn_ExioOut9;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button Btn_ExioOut8;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button Btn_ExioOut7;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button Btn_ExioOut6;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Button Btn_ExioOut5;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button Btn_ExioOut4;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button Btn_ExioOut3;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Button Btn_ExioOut2;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button Btn_ExioOut1;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button Btn_ExioOut0;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label ExioIn2;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label ExioIn1;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label ExioIn0;
        private System.Windows.Forms.Label label78;
    }
}