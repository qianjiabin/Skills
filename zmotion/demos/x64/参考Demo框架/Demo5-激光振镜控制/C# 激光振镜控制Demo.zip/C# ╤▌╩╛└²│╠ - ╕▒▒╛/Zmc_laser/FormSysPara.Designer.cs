﻿namespace Zmc_laser
{
    partial class FormSysPara
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabSysPara = new System.Windows.Forms.TabControl();
            this.tabPage_LaserSet = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Ccbox_LaserType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Text_Io_Pwm = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Text_Aout_Range = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Text_Aio_Port = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Text_Io__Red = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Text_Io_Laser = new System.Windows.Forms.TextBox();
            this.Text_Io_Enable = new System.Windows.Forms.TextBox();
            this.Btn_Laser = new System.Windows.Forms.Button();
            this.Btn_Red = new System.Windows.Forms.Button();
            this.tabPage_AxisPara = new System.Windows.Forms.TabPage();
            this.AxisParaList = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Btn_Set = new System.Windows.Forms.Button();
            this.Btn_Scan = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_AxisEnable = new System.Windows.Forms.Button();
            this.Btn_AxisStop = new System.Windows.Forms.Button();
            this.Btn_AxisHome = new System.Windows.Forms.Button();
            this.Btn_AxisFwd = new System.Windows.Forms.Button();
            this.Btn_AxisRev = new System.Windows.Forms.Button();
            this.Text_Dist = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Check_MoveMode = new System.Windows.Forms.CheckBox();
            this.cBoxAxisList = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage_ScanPara = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Btn_ScanCorrect = new System.Windows.Forms.Button();
            this.Btn_CorrectFile = new System.Windows.Forms.Button();
            this.Text_CorrnetFileName = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Btn_ScanStop = new System.Windows.Forms.Button();
            this.Btn_ScanHome = new System.Windows.Forms.Button();
            this.Btn_ScanFwd = new System.Windows.Forms.Button();
            this.Btn_ScanRev = new System.Windows.Forms.Button();
            this.Text_ScanStep = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Check_ModeSCan = new System.Windows.Forms.CheckBox();
            this.RadioLaser = new System.Windows.Forms.RadioButton();
            this.RadioRed = new System.Windows.Forms.RadioButton();
            this.CBoxScanAxis = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Btn_ScanSet = new System.Windows.Forms.Button();
            this.Text_ScanSpeed = new System.Windows.Forms.TextBox();
            this.Text_ScanUnits = new System.Windows.Forms.TextBox();
            this.Check_XyChange = new System.Windows.Forms.CheckBox();
            this.CBoxScanID = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage_FlyPara = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Text_Linkage_Division = new System.Windows.Forms.CheckBox();
            this.Text_Linkage_Enable = new System.Windows.Forms.CheckBox();
            this.label35 = new System.Windows.Forms.Label();
            this.Text_Linkage_Angle = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.Text_Linkage_LimitY = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.Text_Linkage_LimitX = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Text_Linkage_YDelay = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.Text_Linkage_XDelay = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.Text_Linkage_MLlimtY = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.Text_Linkage_MLlimtX = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Text_Linkage_Zsmooth = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Text_Linkage_MaxSp = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.Text_Linkage_Dec = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.Text_Linkage_Acc = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.Text_Linkage_AxisY = new System.Windows.Forms.TextBox();
            this.Text_Linkage_AxisX = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabSysPara.SuspendLayout();
            this.tabPage_LaserSet.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage_AxisPara.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AxisParaList)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabPage_ScanPara.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage_FlyPara.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabSysPara
            // 
            this.tabSysPara.Controls.Add(this.tabPage_LaserSet);
            this.tabSysPara.Controls.Add(this.tabPage_AxisPara);
            this.tabSysPara.Controls.Add(this.tabPage_ScanPara);
            this.tabSysPara.Controls.Add(this.tabPage_FlyPara);
            this.tabSysPara.Location = new System.Drawing.Point(0, 1);
            this.tabSysPara.Name = "tabSysPara";
            this.tabSysPara.SelectedIndex = 0;
            this.tabSysPara.Size = new System.Drawing.Size(786, 646);
            this.tabSysPara.TabIndex = 0;
            this.tabSysPara.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabSysPara_Selected);
            // 
            // tabPage_LaserSet
            // 
            this.tabPage_LaserSet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_LaserSet.Controls.Add(this.groupBox1);
            this.tabPage_LaserSet.Controls.Add(this.Btn_Laser);
            this.tabPage_LaserSet.Controls.Add(this.Btn_Red);
            this.tabPage_LaserSet.Location = new System.Drawing.Point(4, 22);
            this.tabPage_LaserSet.Name = "tabPage_LaserSet";
            this.tabPage_LaserSet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_LaserSet.Size = new System.Drawing.Size(778, 620);
            this.tabPage_LaserSet.TabIndex = 0;
            this.tabPage_LaserSet.Text = "激光器参数";
            this.tabPage_LaserSet.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Ccbox_LaserType);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Text_Io_Pwm);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Text_Aout_Range);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Text_Aio_Port);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.Text_Io__Red);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Text_Io_Laser);
            this.groupBox1.Controls.Add(this.Text_Io_Enable);
            this.groupBox1.Location = new System.Drawing.Point(15, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(197, 325);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "激光器参数";
            // 
            // Ccbox_LaserType
            // 
            this.Ccbox_LaserType.FormattingEnabled = true;
            this.Ccbox_LaserType.Items.AddRange(new object[] {
            "408-Fiber",
            "408-YLR",
            "408-YAG",
            "504-Fiber",
            "408V2-Fiber"});
            this.Ccbox_LaserType.Location = new System.Drawing.Point(95, 20);
            this.Ccbox_LaserType.Name = "Ccbox_LaserType";
            this.Ccbox_LaserType.Size = new System.Drawing.Size(78, 20);
            this.Ccbox_LaserType.TabIndex = 19;
            this.Ccbox_LaserType.Text = "408-Fiber";
            this.Ccbox_LaserType.DropDownClosed += new System.EventHandler(this.CCBOX_LASER_DropDownClosed);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "激光器类型";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 20;
            this.label3.Text = "使能IO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 21;
            this.label4.Text = "出光IO";
            // 
            // Text_Io_Pwm
            // 
            this.Text_Io_Pwm.Location = new System.Drawing.Point(95, 224);
            this.Text_Io_Pwm.Name = "Text_Io_Pwm";
            this.Text_Io_Pwm.Size = new System.Drawing.Size(78, 21);
            this.Text_Io_Pwm.TabIndex = 32;
            this.Text_Io_Pwm.Text = "9";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 22;
            this.label5.Text = "红光IO";
            // 
            // Text_Aout_Range
            // 
            this.Text_Aout_Range.Location = new System.Drawing.Point(95, 190);
            this.Text_Aout_Range.Name = "Text_Aout_Range";
            this.Text_Aout_Range.Size = new System.Drawing.Size(78, 21);
            this.Text_Aout_Range.TabIndex = 31;
            this.Text_Aout_Range.Text = "128";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 23;
            this.label6.Text = "功率AIO";
            // 
            // Text_Aio_Port
            // 
            this.Text_Aio_Port.Location = new System.Drawing.Point(95, 156);
            this.Text_Aio_Port.Name = "Text_Aio_Port";
            this.Text_Aio_Port.Size = new System.Drawing.Size(78, 21);
            this.Text_Aio_Port.TabIndex = 30;
            this.Text_Aio_Port.Text = "3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 24;
            this.label7.Text = "功率值";
            // 
            // Text_Io__Red
            // 
            this.Text_Io__Red.Location = new System.Drawing.Point(95, 122);
            this.Text_Io__Red.Name = "Text_Io__Red";
            this.Text_Io__Red.Size = new System.Drawing.Size(78, 21);
            this.Text_Io__Red.TabIndex = 29;
            this.Text_Io__Red.Text = "48";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 25;
            this.label8.Text = "频率IO";
            // 
            // Text_Io_Laser
            // 
            this.Text_Io_Laser.Location = new System.Drawing.Point(95, 88);
            this.Text_Io_Laser.Name = "Text_Io_Laser";
            this.Text_Io_Laser.Size = new System.Drawing.Size(78, 21);
            this.Text_Io_Laser.TabIndex = 28;
            this.Text_Io_Laser.Text = "8";
            // 
            // Text_Io_Enable
            // 
            this.Text_Io_Enable.Location = new System.Drawing.Point(95, 54);
            this.Text_Io_Enable.Name = "Text_Io_Enable";
            this.Text_Io_Enable.Size = new System.Drawing.Size(78, 21);
            this.Text_Io_Enable.TabIndex = 27;
            this.Text_Io_Enable.Text = "47";
            // 
            // Btn_Laser
            // 
            this.Btn_Laser.Location = new System.Drawing.Point(119, 364);
            this.Btn_Laser.Name = "Btn_Laser";
            this.Btn_Laser.Size = new System.Drawing.Size(87, 23);
            this.Btn_Laser.TabIndex = 35;
            this.Btn_Laser.Text = "激光(关)";
            this.Btn_Laser.UseVisualStyleBackColor = true;
            this.Btn_Laser.Click += new System.EventHandler(this.BTN_LASER_Click);
            // 
            // Btn_Red
            // 
            this.Btn_Red.Location = new System.Drawing.Point(14, 364);
            this.Btn_Red.Name = "Btn_Red";
            this.Btn_Red.Size = new System.Drawing.Size(87, 23);
            this.Btn_Red.TabIndex = 34;
            this.Btn_Red.Text = "红光(关)";
            this.Btn_Red.UseVisualStyleBackColor = true;
            this.Btn_Red.Click += new System.EventHandler(this.BTN_RED_Click);
            // 
            // tabPage_AxisPara
            // 
            this.tabPage_AxisPara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_AxisPara.Controls.Add(this.AxisParaList);
            this.tabPage_AxisPara.Controls.Add(this.Btn_Set);
            this.tabPage_AxisPara.Controls.Add(this.Btn_Scan);
            this.tabPage_AxisPara.Controls.Add(this.groupBox2);
            this.tabPage_AxisPara.Location = new System.Drawing.Point(4, 22);
            this.tabPage_AxisPara.Name = "tabPage_AxisPara";
            this.tabPage_AxisPara.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_AxisPara.Size = new System.Drawing.Size(778, 620);
            this.tabPage_AxisPara.TabIndex = 1;
            this.tabPage_AxisPara.Text = "轴参数";
            this.tabPage_AxisPara.UseVisualStyleBackColor = true;
            // 
            // AxisParaList
            // 
            this.AxisParaList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AxisParaList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.AxisParaList.Location = new System.Drawing.Point(-1, -1);
            this.AxisParaList.Name = "AxisParaList";
            this.AxisParaList.RowHeadersWidth = 220;
            this.AxisParaList.RowTemplate.Height = 23;
            this.AxisParaList.Size = new System.Drawing.Size(782, 482);
            this.AxisParaList.TabIndex = 12;
            this.AxisParaList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.AxisParaList_CellEndEdit);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Axis0";
            this.Column1.Name = "Column1";
            this.Column1.Width = 140;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Axis1";
            this.Column2.Name = "Column2";
            this.Column2.Width = 140;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Axis2";
            this.Column3.Name = "Column3";
            this.Column3.Width = 140;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Axis3";
            this.Column4.Name = "Column4";
            this.Column4.Width = 140;
            // 
            // Btn_Set
            // 
            this.Btn_Set.Location = new System.Drawing.Point(659, 569);
            this.Btn_Set.Name = "Btn_Set";
            this.Btn_Set.Size = new System.Drawing.Size(75, 23);
            this.Btn_Set.TabIndex = 11;
            this.Btn_Set.Text = "应  用";
            this.Btn_Set.UseVisualStyleBackColor = true;
            this.Btn_Set.Click += new System.EventHandler(this.Btn_Set_Click);
            // 
            // Btn_Scan
            // 
            this.Btn_Scan.Location = new System.Drawing.Point(659, 515);
            this.Btn_Scan.Name = "Btn_Scan";
            this.Btn_Scan.Size = new System.Drawing.Size(75, 23);
            this.Btn_Scan.TabIndex = 10;
            this.Btn_Scan.Text = "刷  新";
            this.Btn_Scan.UseVisualStyleBackColor = true;
            this.Btn_Scan.Click += new System.EventHandler(this.Btn_Scan_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.Btn_AxisEnable);
            this.groupBox2.Controls.Add(this.Btn_AxisStop);
            this.groupBox2.Controls.Add(this.Btn_AxisHome);
            this.groupBox2.Controls.Add(this.Btn_AxisFwd);
            this.groupBox2.Controls.Add(this.Btn_AxisRev);
            this.groupBox2.Controls.Add(this.Text_Dist);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.Check_MoveMode);
            this.groupBox2.Controls.Add(this.cBoxAxisList);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(0, 487);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(612, 125);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "轴调试";
            // 
            // Btn_AxisEnable
            // 
            this.Btn_AxisEnable.Location = new System.Drawing.Point(472, 31);
            this.Btn_AxisEnable.Name = "Btn_AxisEnable";
            this.Btn_AxisEnable.Size = new System.Drawing.Size(75, 23);
            this.Btn_AxisEnable.TabIndex = 9;
            this.Btn_AxisEnable.Text = "使  能";
            this.Btn_AxisEnable.UseVisualStyleBackColor = true;
            this.Btn_AxisEnable.Click += new System.EventHandler(this.Btn_AxisEnable_Click);
            // 
            // Btn_AxisStop
            // 
            this.Btn_AxisStop.Location = new System.Drawing.Point(363, 82);
            this.Btn_AxisStop.Name = "Btn_AxisStop";
            this.Btn_AxisStop.Size = new System.Drawing.Size(75, 23);
            this.Btn_AxisStop.TabIndex = 8;
            this.Btn_AxisStop.Text = "停  止";
            this.Btn_AxisStop.UseVisualStyleBackColor = true;
            this.Btn_AxisStop.Click += new System.EventHandler(this.Btn_AxisStop_Click);
            // 
            // Btn_AxisHome
            // 
            this.Btn_AxisHome.Location = new System.Drawing.Point(250, 82);
            this.Btn_AxisHome.Name = "Btn_AxisHome";
            this.Btn_AxisHome.Size = new System.Drawing.Size(75, 23);
            this.Btn_AxisHome.TabIndex = 7;
            this.Btn_AxisHome.Text = "回  零";
            this.Btn_AxisHome.UseVisualStyleBackColor = true;
            this.Btn_AxisHome.Click += new System.EventHandler(this.Btn_AxisHome_Click);
            // 
            // Btn_AxisFwd
            // 
            this.Btn_AxisFwd.Location = new System.Drawing.Point(137, 82);
            this.Btn_AxisFwd.Name = "Btn_AxisFwd";
            this.Btn_AxisFwd.Size = new System.Drawing.Size(75, 23);
            this.Btn_AxisFwd.TabIndex = 6;
            this.Btn_AxisFwd.Text = "正  转";
            this.Btn_AxisFwd.UseVisualStyleBackColor = true;
            this.Btn_AxisFwd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_AxisFwd_MouseDown);
            this.Btn_AxisFwd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Btn_AxisFwd_MouseUp);
            // 
            // Btn_AxisRev
            // 
            this.Btn_AxisRev.Location = new System.Drawing.Point(24, 82);
            this.Btn_AxisRev.Name = "Btn_AxisRev";
            this.Btn_AxisRev.Size = new System.Drawing.Size(75, 23);
            this.Btn_AxisRev.TabIndex = 5;
            this.Btn_AxisRev.Text = "反  转";
            this.Btn_AxisRev.UseVisualStyleBackColor = true;
            this.Btn_AxisRev.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_AxisRev_MouseDown);
            this.Btn_AxisRev.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Btn_AxisRev_MouseUp);
            // 
            // Text_Dist
            // 
            this.Text_Dist.Location = new System.Drawing.Point(338, 31);
            this.Text_Dist.Name = "Text_Dist";
            this.Text_Dist.Size = new System.Drawing.Size(100, 21);
            this.Text_Dist.TabIndex = 4;
            this.Text_Dist.Text = "5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(267, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "寸动距离：";
            // 
            // Check_MoveMode
            // 
            this.Check_MoveMode.AutoSize = true;
            this.Check_MoveMode.Location = new System.Drawing.Point(203, 35);
            this.Check_MoveMode.Name = "Check_MoveMode";
            this.Check_MoveMode.Size = new System.Drawing.Size(48, 16);
            this.Check_MoveMode.TabIndex = 2;
            this.Check_MoveMode.Text = "寸动";
            this.Check_MoveMode.UseVisualStyleBackColor = true;
            // 
            // cBoxAxisList
            // 
            this.cBoxAxisList.FormattingEnabled = true;
            this.cBoxAxisList.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cBoxAxisList.Location = new System.Drawing.Point(69, 31);
            this.cBoxAxisList.Name = "cBoxAxisList";
            this.cBoxAxisList.Size = new System.Drawing.Size(93, 20);
            this.cBoxAxisList.TabIndex = 1;
            this.cBoxAxisList.Text = "0";
            this.cBoxAxisList.SelectedIndexChanged += new System.EventHandler(this.cBoxAxisList_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "轴选：";
            // 
            // tabPage_ScanPara
            // 
            this.tabPage_ScanPara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_ScanPara.Controls.Add(this.groupBox5);
            this.tabPage_ScanPara.Controls.Add(this.groupBox4);
            this.tabPage_ScanPara.Controls.Add(this.groupBox3);
            this.tabPage_ScanPara.Location = new System.Drawing.Point(4, 22);
            this.tabPage_ScanPara.Name = "tabPage_ScanPara";
            this.tabPage_ScanPara.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_ScanPara.Size = new System.Drawing.Size(778, 620);
            this.tabPage_ScanPara.TabIndex = 2;
            this.tabPage_ScanPara.Text = "振镜参数";
            this.tabPage_ScanPara.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Btn_ScanCorrect);
            this.groupBox5.Controls.Add(this.Btn_CorrectFile);
            this.groupBox5.Controls.Add(this.Text_CorrnetFileName);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Location = new System.Drawing.Point(7, 329);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(591, 100);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "振镜校正";
            // 
            // Btn_ScanCorrect
            // 
            this.Btn_ScanCorrect.Location = new System.Drawing.Point(512, 41);
            this.Btn_ScanCorrect.Name = "Btn_ScanCorrect";
            this.Btn_ScanCorrect.Size = new System.Drawing.Size(75, 23);
            this.Btn_ScanCorrect.TabIndex = 20;
            this.Btn_ScanCorrect.Text = "校正";
            this.Btn_ScanCorrect.UseVisualStyleBackColor = true;
            this.Btn_ScanCorrect.Click += new System.EventHandler(this.Btn_ScanCorrect_Click);
            // 
            // Btn_CorrectFile
            // 
            this.Btn_CorrectFile.Location = new System.Drawing.Point(431, 41);
            this.Btn_CorrectFile.Name = "Btn_CorrectFile";
            this.Btn_CorrectFile.Size = new System.Drawing.Size(75, 23);
            this.Btn_CorrectFile.TabIndex = 19;
            this.Btn_CorrectFile.Text = "选择";
            this.Btn_CorrectFile.UseVisualStyleBackColor = true;
            this.Btn_CorrectFile.Click += new System.EventHandler(this.Btn_CorrectFile_Click);
            // 
            // Text_CorrnetFileName
            // 
            this.Text_CorrnetFileName.Location = new System.Drawing.Point(72, 41);
            this.Text_CorrnetFileName.Name = "Text_CorrnetFileName";
            this.Text_CorrnetFileName.Size = new System.Drawing.Size(353, 21);
            this.Text_CorrnetFileName.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 44);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 0;
            this.label16.Text = "校正文件：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Btn_ScanStop);
            this.groupBox4.Controls.Add(this.Btn_ScanHome);
            this.groupBox4.Controls.Add(this.Btn_ScanFwd);
            this.groupBox4.Controls.Add(this.Btn_ScanRev);
            this.groupBox4.Controls.Add(this.Text_ScanStep);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.Check_ModeSCan);
            this.groupBox4.Controls.Add(this.RadioLaser);
            this.groupBox4.Controls.Add(this.RadioRed);
            this.groupBox4.Controls.Add(this.CBoxScanAxis);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Location = new System.Drawing.Point(252, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(346, 317);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "振镜轴测试";
            // 
            // Btn_ScanStop
            // 
            this.Btn_ScanStop.Location = new System.Drawing.Point(160, 184);
            this.Btn_ScanStop.Name = "Btn_ScanStop";
            this.Btn_ScanStop.Size = new System.Drawing.Size(75, 23);
            this.Btn_ScanStop.TabIndex = 18;
            this.Btn_ScanStop.Text = "停  止";
            this.Btn_ScanStop.UseVisualStyleBackColor = true;
            this.Btn_ScanStop.Click += new System.EventHandler(this.Btn_ScanStop_Click);
            // 
            // Btn_ScanHome
            // 
            this.Btn_ScanHome.Location = new System.Drawing.Point(30, 184);
            this.Btn_ScanHome.Name = "Btn_ScanHome";
            this.Btn_ScanHome.Size = new System.Drawing.Size(75, 23);
            this.Btn_ScanHome.TabIndex = 17;
            this.Btn_ScanHome.Text = "回零位";
            this.Btn_ScanHome.UseVisualStyleBackColor = true;
            this.Btn_ScanHome.Click += new System.EventHandler(this.Btn_ScanHome_Click);
            // 
            // Btn_ScanFwd
            // 
            this.Btn_ScanFwd.Location = new System.Drawing.Point(160, 133);
            this.Btn_ScanFwd.Name = "Btn_ScanFwd";
            this.Btn_ScanFwd.Size = new System.Drawing.Size(75, 23);
            this.Btn_ScanFwd.TabIndex = 16;
            this.Btn_ScanFwd.Text = "正  转";
            this.Btn_ScanFwd.UseVisualStyleBackColor = true;
            this.Btn_ScanFwd.Click += new System.EventHandler(this.Btn_ScanFwd_Click);
            this.Btn_ScanFwd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_ScanFwd_MouseDown);
            this.Btn_ScanFwd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Btn_ScanFwd_MouseUp);
            // 
            // Btn_ScanRev
            // 
            this.Btn_ScanRev.Location = new System.Drawing.Point(30, 133);
            this.Btn_ScanRev.Name = "Btn_ScanRev";
            this.Btn_ScanRev.Size = new System.Drawing.Size(75, 23);
            this.Btn_ScanRev.TabIndex = 15;
            this.Btn_ScanRev.Text = "反  转";
            this.Btn_ScanRev.UseVisualStyleBackColor = true;
            this.Btn_ScanRev.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Btn_ScanRev_MouseDown);
            this.Btn_ScanRev.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Btn_ScanRev_MouseUp);
            // 
            // Text_ScanStep
            // 
            this.Text_ScanStep.Location = new System.Drawing.Point(179, 77);
            this.Text_ScanStep.Name = "Text_ScanStep";
            this.Text_ScanStep.Size = new System.Drawing.Size(77, 21);
            this.Text_ScanStep.TabIndex = 14;
            this.Text_ScanStep.Text = "5";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(98, 80);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 13;
            this.label15.Text = "寸动距离：";
            // 
            // Check_ModeSCan
            // 
            this.Check_ModeSCan.AutoSize = true;
            this.Check_ModeSCan.Location = new System.Drawing.Point(30, 79);
            this.Check_ModeSCan.Name = "Check_ModeSCan";
            this.Check_ModeSCan.Size = new System.Drawing.Size(48, 16);
            this.Check_ModeSCan.TabIndex = 12;
            this.Check_ModeSCan.Text = "寸动";
            this.Check_ModeSCan.UseVisualStyleBackColor = true;
            // 
            // RadioLaser
            // 
            this.RadioLaser.AutoSize = true;
            this.RadioLaser.Location = new System.Drawing.Point(251, 25);
            this.RadioLaser.Name = "RadioLaser";
            this.RadioLaser.Size = new System.Drawing.Size(47, 16);
            this.RadioLaser.TabIndex = 11;
            this.RadioLaser.Text = "激光";
            this.RadioLaser.UseVisualStyleBackColor = true;
            // 
            // RadioRed
            // 
            this.RadioRed.AutoSize = true;
            this.RadioRed.Checked = true;
            this.RadioRed.Location = new System.Drawing.Point(174, 25);
            this.RadioRed.Name = "RadioRed";
            this.RadioRed.Size = new System.Drawing.Size(47, 16);
            this.RadioRed.TabIndex = 10;
            this.RadioRed.TabStop = true;
            this.RadioRed.Text = "红光";
            this.RadioRed.UseVisualStyleBackColor = true;
            // 
            // CBoxScanAxis
            // 
            this.CBoxScanAxis.FormattingEnabled = true;
            this.CBoxScanAxis.Items.AddRange(new object[] {
            "X轴",
            "Y轴"});
            this.CBoxScanAxis.Location = new System.Drawing.Point(50, 26);
            this.CBoxScanAxis.Name = "CBoxScanAxis";
            this.CBoxScanAxis.Size = new System.Drawing.Size(69, 20);
            this.CBoxScanAxis.TabIndex = 9;
            this.CBoxScanAxis.Text = "X轴";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 8;
            this.label14.Text = "轴：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Btn_ScanSet);
            this.groupBox3.Controls.Add(this.Text_ScanSpeed);
            this.groupBox3.Controls.Add(this.Text_ScanUnits);
            this.groupBox3.Controls.Add(this.Check_XyChange);
            this.groupBox3.Controls.Add(this.CBoxScanID);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Location = new System.Drawing.Point(7, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(239, 317);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "振镜参数";
            // 
            // Btn_ScanSet
            // 
            this.Btn_ScanSet.Location = new System.Drawing.Point(150, 275);
            this.Btn_ScanSet.Name = "Btn_ScanSet";
            this.Btn_ScanSet.Size = new System.Drawing.Size(71, 23);
            this.Btn_ScanSet.TabIndex = 8;
            this.Btn_ScanSet.Text = "应  用";
            this.Btn_ScanSet.UseVisualStyleBackColor = true;
            this.Btn_ScanSet.Click += new System.EventHandler(this.Btn_ScanSet_Click);
            // 
            // Text_ScanSpeed
            // 
            this.Text_ScanSpeed.Location = new System.Drawing.Point(98, 130);
            this.Text_ScanSpeed.Name = "Text_ScanSpeed";
            this.Text_ScanSpeed.Size = new System.Drawing.Size(74, 21);
            this.Text_ScanSpeed.TabIndex = 7;
            this.Text_ScanSpeed.Text = "1000";
            // 
            // Text_ScanUnits
            // 
            this.Text_ScanUnits.Location = new System.Drawing.Point(98, 93);
            this.Text_ScanUnits.Name = "Text_ScanUnits";
            this.Text_ScanUnits.Size = new System.Drawing.Size(74, 21);
            this.Text_ScanUnits.TabIndex = 6;
            this.Text_ScanUnits.Text = "1000";
            // 
            // Check_XyChange
            // 
            this.Check_XyChange.AutoSize = true;
            this.Check_XyChange.Location = new System.Drawing.Point(98, 64);
            this.Check_XyChange.Name = "Check_XyChange";
            this.Check_XyChange.Size = new System.Drawing.Size(42, 16);
            this.Check_XyChange.TabIndex = 5;
            this.Check_XyChange.Text = "X=Y";
            this.Check_XyChange.UseVisualStyleBackColor = true;
            this.Check_XyChange.CheckedChanged += new System.EventHandler(this.Check_XyChange_CheckedChanged);
            // 
            // CBoxScanID
            // 
            this.CBoxScanID.FormattingEnabled = true;
            this.CBoxScanID.Items.AddRange(new object[] {
            "0",
            "1"});
            this.CBoxScanID.Location = new System.Drawing.Point(99, 26);
            this.CBoxScanID.Name = "CBoxScanID";
            this.CBoxScanID.Size = new System.Drawing.Size(73, 20);
            this.CBoxScanID.TabIndex = 4;
            this.CBoxScanID.Text = "0";
            this.CBoxScanID.SelectedIndexChanged += new System.EventHandler(this.CBoxScanID_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 133);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 12);
            this.label13.TabIndex = 3;
            this.label13.Text = "运行速度:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 96);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "脉冲当量:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "XY交换：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "振镜组：";
            // 
            // tabPage_FlyPara
            // 
            this.tabPage_FlyPara.Controls.Add(this.groupBox7);
            this.tabPage_FlyPara.Controls.Add(this.groupBox6);
            this.tabPage_FlyPara.Location = new System.Drawing.Point(4, 22);
            this.tabPage_FlyPara.Name = "tabPage_FlyPara";
            this.tabPage_FlyPara.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_FlyPara.Size = new System.Drawing.Size(778, 620);
            this.tabPage_FlyPara.TabIndex = 3;
            this.tabPage_FlyPara.Text = "联动参数";
            this.tabPage_FlyPara.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button4);
            this.groupBox7.Controls.Add(this.button3);
            this.groupBox7.Controls.Add(this.button2);
            this.groupBox7.Controls.Add(this.radioButton2);
            this.groupBox7.Controls.Add(this.radioButton1);
            this.groupBox7.Controls.Add(this.label42);
            this.groupBox7.Controls.Add(this.textBox14);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Controls.Add(this.textBox13);
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.textBox12);
            this.groupBox7.Controls.Add(this.label38);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Location = new System.Drawing.Point(8, 392);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(760, 227);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "振镜平台坐标系校正";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(524, 99);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(93, 29);
            this.button4.TabIndex = 46;
            this.button4.Text = "停  止";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(524, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(93, 29);
            this.button3.TabIndex = 45;
            this.button3.Text = "标  刻";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(281, 113);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 29);
            this.button2.TabIndex = 36;
            this.button2.Text = "计算角度";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(363, 33);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 16);
            this.radioButton2.TabIndex = 44;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "激光";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(281, 32);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 16);
            this.radioButton1.TabIndex = 43;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "红光";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(171, 136);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(17, 12);
            this.label42.TabIndex = 42;
            this.label42.Text = "mm";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(90, 127);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(75, 21);
            this.textBox14.TabIndex = 41;
            this.textBox14.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(171, 90);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(17, 12);
            this.label41.TabIndex = 40;
            this.label41.Text = "mm";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(90, 81);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(75, 21);
            this.textBox13.TabIndex = 39;
            this.textBox13.Text = "100";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(171, 41);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(17, 12);
            this.label40.TabIndex = 37;
            this.label40.Text = "mm";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 130);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(89, 12);
            this.label39.TabIndex = 38;
            this.label39.Text = "测量高度偏差：";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(90, 32);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(75, 21);
            this.textBox12.TabIndex = 36;
            this.textBox12.Text = "100";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 84);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(89, 12);
            this.label38.TabIndex = 37;
            this.label38.Text = "平台测量长度：";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(6, 41);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 12);
            this.label37.TabIndex = 36;
            this.label37.Text = "标刻长度：";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button1);
            this.groupBox6.Controls.Add(this.Text_Linkage_Division);
            this.groupBox6.Controls.Add(this.Text_Linkage_Enable);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.Text_Linkage_Angle);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.Text_Linkage_LimitY);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.Text_Linkage_LimitX);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.Text_Linkage_YDelay);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.Text_Linkage_XDelay);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.Text_Linkage_MLlimtY);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.Text_Linkage_MLlimtX);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.Text_Linkage_Zsmooth);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.Text_Linkage_MaxSp);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.Text_Linkage_Dec);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.Text_Linkage_Acc);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.Text_Linkage_AxisY);
            this.groupBox6.Controls.Add(this.Text_Linkage_AxisX);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Location = new System.Drawing.Point(8, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(761, 370);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "联动参数";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(281, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 29);
            this.button1.TabIndex = 35;
            this.button1.Text = "应  用";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Text_Linkage_Division
            // 
            this.Text_Linkage_Division.AutoSize = true;
            this.Text_Linkage_Division.Location = new System.Drawing.Point(398, 235);
            this.Text_Linkage_Division.Name = "Text_Linkage_Division";
            this.Text_Linkage_Division.Size = new System.Drawing.Size(72, 16);
            this.Text_Linkage_Division.TabIndex = 34;
            this.Text_Linkage_Division.Text = "分割联动";
            this.Text_Linkage_Division.UseVisualStyleBackColor = true;
            // 
            // Text_Linkage_Enable
            // 
            this.Text_Linkage_Enable.AutoSize = true;
            this.Text_Linkage_Enable.Location = new System.Drawing.Point(281, 235);
            this.Text_Linkage_Enable.Name = "Text_Linkage_Enable";
            this.Text_Linkage_Enable.Size = new System.Drawing.Size(72, 16);
            this.Text_Linkage_Enable.TabIndex = 33;
            this.Text_Linkage_Enable.Text = "整体联动";
            this.Text_Linkage_Enable.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(444, 193);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(17, 12);
            this.label35.TabIndex = 32;
            this.label35.Text = "°";
            // 
            // Text_Linkage_Angle
            // 
            this.Text_Linkage_Angle.Location = new System.Drawing.Point(363, 184);
            this.Text_Linkage_Angle.Name = "Text_Linkage_Angle";
            this.Text_Linkage_Angle.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_Angle.TabIndex = 31;
            this.Text_Linkage_Angle.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(279, 187);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(77, 12);
            this.label36.TabIndex = 30;
            this.label36.Text = "坐标系角度：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(444, 155);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(17, 12);
            this.label33.TabIndex = 29;
            this.label33.Text = "mm";
            // 
            // Text_Linkage_LimitY
            // 
            this.Text_Linkage_LimitY.Location = new System.Drawing.Point(363, 146);
            this.Text_Linkage_LimitY.Name = "Text_Linkage_LimitY";
            this.Text_Linkage_LimitY.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_LimitY.TabIndex = 28;
            this.Text_Linkage_LimitY.Text = "50";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(279, 149);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(71, 12);
            this.label34.TabIndex = 27;
            this.label34.Text = "振镜Y行程：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(444, 116);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(17, 12);
            this.label31.TabIndex = 26;
            this.label31.Text = "mm";
            // 
            // Text_Linkage_LimitX
            // 
            this.Text_Linkage_LimitX.Location = new System.Drawing.Point(363, 107);
            this.Text_Linkage_LimitX.Name = "Text_Linkage_LimitX";
            this.Text_Linkage_LimitX.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_LimitX.TabIndex = 25;
            this.Text_Linkage_LimitX.Text = "50";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(279, 110);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(71, 12);
            this.label32.TabIndex = 24;
            this.label32.Text = "振镜X行程：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(444, 76);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(17, 12);
            this.label29.TabIndex = 23;
            this.label29.Text = "us";
            // 
            // Text_Linkage_YDelay
            // 
            this.Text_Linkage_YDelay.Location = new System.Drawing.Point(363, 67);
            this.Text_Linkage_YDelay.Name = "Text_Linkage_YDelay";
            this.Text_Linkage_YDelay.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_YDelay.TabIndex = 22;
            this.Text_Linkage_YDelay.Text = "1000";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(279, 70);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(95, 12);
            this.label30.TabIndex = 21;
            this.label30.Text = "平台Y联动延时：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(444, 38);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 12);
            this.label27.TabIndex = 20;
            this.label27.Text = "us";
            // 
            // Text_Linkage_XDelay
            // 
            this.Text_Linkage_XDelay.Location = new System.Drawing.Point(363, 29);
            this.Text_Linkage_XDelay.Name = "Text_Linkage_XDelay";
            this.Text_Linkage_XDelay.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_XDelay.TabIndex = 19;
            this.Text_Linkage_XDelay.Text = "1000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(279, 32);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(95, 12);
            this.label28.TabIndex = 18;
            this.label28.Text = "平台X联动延时：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(171, 269);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 12);
            this.label26.TabIndex = 17;
            this.label26.Text = "mm";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(171, 308);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 12);
            this.label25.TabIndex = 16;
            this.label25.Text = "mm";
            // 
            // Text_Linkage_MLlimtY
            // 
            this.Text_Linkage_MLlimtY.Location = new System.Drawing.Point(90, 299);
            this.Text_Linkage_MLlimtY.Name = "Text_Linkage_MLlimtY";
            this.Text_Linkage_MLlimtY.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_MLlimtY.TabIndex = 15;
            this.Text_Linkage_MLlimtY.Text = "300";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 302);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(71, 12);
            this.label23.TabIndex = 14;
            this.label23.Text = "平台Y行程：";
            // 
            // Text_Linkage_MLlimtX
            // 
            this.Text_Linkage_MLlimtX.Location = new System.Drawing.Point(90, 260);
            this.Text_Linkage_MLlimtX.Name = "Text_Linkage_MLlimtX";
            this.Text_Linkage_MLlimtX.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_MLlimtX.TabIndex = 13;
            this.Text_Linkage_MLlimtX.Text = "300";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 263);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 12);
            this.label24.TabIndex = 12;
            this.label24.Text = "平台X行程：";
            // 
            // Text_Linkage_Zsmooth
            // 
            this.Text_Linkage_Zsmooth.Location = new System.Drawing.Point(90, 220);
            this.Text_Linkage_Zsmooth.Name = "Text_Linkage_Zsmooth";
            this.Text_Linkage_Zsmooth.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_Zsmooth.TabIndex = 11;
            this.Text_Linkage_Zsmooth.Text = "0.2";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 223);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 12);
            this.label21.TabIndex = 10;
            this.label21.Text = "平台平滑角度：";
            // 
            // Text_Linkage_MaxSp
            // 
            this.Text_Linkage_MaxSp.Location = new System.Drawing.Point(90, 181);
            this.Text_Linkage_MaxSp.Name = "Text_Linkage_MaxSp";
            this.Text_Linkage_MaxSp.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_MaxSp.TabIndex = 9;
            this.Text_Linkage_MaxSp.Text = "80";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 184);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 12);
            this.label22.TabIndex = 8;
            this.label22.Text = "平台最高速度：";
            // 
            // Text_Linkage_Dec
            // 
            this.Text_Linkage_Dec.Location = new System.Drawing.Point(90, 143);
            this.Text_Linkage_Dec.Name = "Text_Linkage_Dec";
            this.Text_Linkage_Dec.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_Dec.TabIndex = 7;
            this.Text_Linkage_Dec.Text = "800";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 146);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 12);
            this.label20.TabIndex = 6;
            this.label20.Text = "平台减速度：";
            // 
            // Text_Linkage_Acc
            // 
            this.Text_Linkage_Acc.Location = new System.Drawing.Point(90, 104);
            this.Text_Linkage_Acc.Name = "Text_Linkage_Acc";
            this.Text_Linkage_Acc.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_Acc.TabIndex = 5;
            this.Text_Linkage_Acc.Text = "800";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 107);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 12);
            this.label19.TabIndex = 4;
            this.label19.Text = "平台加速度：";
            // 
            // Text_Linkage_AxisY
            // 
            this.Text_Linkage_AxisY.Location = new System.Drawing.Point(90, 64);
            this.Text_Linkage_AxisY.Name = "Text_Linkage_AxisY";
            this.Text_Linkage_AxisY.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_AxisY.TabIndex = 3;
            this.Text_Linkage_AxisY.Text = "1";
            // 
            // Text_Linkage_AxisX
            // 
            this.Text_Linkage_AxisX.Location = new System.Drawing.Point(90, 26);
            this.Text_Linkage_AxisX.Name = "Text_Linkage_AxisX";
            this.Text_Linkage_AxisX.Size = new System.Drawing.Size(75, 21);
            this.Text_Linkage_AxisX.TabIndex = 2;
            this.Text_Linkage_AxisX.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 12);
            this.label18.TabIndex = 1;
            this.label18.Text = "平台Y轴号：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "平台X轴号：";
            // 
            // FormSysPara
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(785, 650);
            this.Controls.Add(this.tabSysPara);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormSysPara";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "参数设置";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormSysPara_FormClosed);
            this.Load += new System.EventHandler(this.FormSysPara_Load);
            this.tabSysPara.ResumeLayout(false);
            this.tabPage_LaserSet.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage_AxisPara.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AxisParaList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage_ScanPara.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage_FlyPara.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabSysPara;
        private System.Windows.Forms.TabPage tabPage_LaserSet;
        private System.Windows.Forms.TabPage tabPage_AxisPara;
        private System.Windows.Forms.TabPage tabPage_ScanPara;
        private System.Windows.Forms.Button Btn_Laser;
        private System.Windows.Forms.Button Btn_Red;
        private System.Windows.Forms.TextBox Text_Io_Pwm;
        private System.Windows.Forms.TextBox Text_Aout_Range;
        private System.Windows.Forms.TextBox Text_Aio_Port;
        private System.Windows.Forms.TextBox Text_Io__Red;
        private System.Windows.Forms.TextBox Text_Io_Laser;
        private System.Windows.Forms.TextBox Text_Io_Enable;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Ccbox_LaserType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_Set;
        private System.Windows.Forms.Button Btn_Scan;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_AxisEnable;
        private System.Windows.Forms.Button Btn_AxisStop;
        private System.Windows.Forms.Button Btn_AxisHome;
        private System.Windows.Forms.Button Btn_AxisFwd;
        private System.Windows.Forms.Button Btn_AxisRev;
        private System.Windows.Forms.TextBox Text_Dist;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox Check_MoveMode;
        private System.Windows.Forms.ComboBox cBoxAxisList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView AxisParaList;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button Btn_ScanCorrect;
        private System.Windows.Forms.Button Btn_CorrectFile;
        private System.Windows.Forms.TextBox Text_CorrnetFileName;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button Btn_ScanStop;
        private System.Windows.Forms.Button Btn_ScanHome;
        private System.Windows.Forms.Button Btn_ScanFwd;
        private System.Windows.Forms.Button Btn_ScanRev;
        private System.Windows.Forms.TextBox Text_ScanStep;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox Check_ModeSCan;
        private System.Windows.Forms.RadioButton RadioLaser;
        private System.Windows.Forms.RadioButton RadioRed;
        private System.Windows.Forms.ComboBox CBoxScanAxis;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox Text_ScanSpeed;
        private System.Windows.Forms.TextBox Text_ScanUnits;
        private System.Windows.Forms.CheckBox Check_XyChange;
        private System.Windows.Forms.ComboBox CBoxScanID;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Btn_ScanSet;
        private System.Windows.Forms.TabPage tabPage_FlyPara;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox Text_Linkage_AxisY;
        private System.Windows.Forms.TextBox Text_Linkage_AxisX;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox Text_Linkage_Division;
        private System.Windows.Forms.CheckBox Text_Linkage_Enable;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox Text_Linkage_Angle;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox Text_Linkage_LimitY;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox Text_Linkage_LimitX;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox Text_Linkage_YDelay;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox Text_Linkage_XDelay;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox Text_Linkage_MLlimtY;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox Text_Linkage_MLlimtX;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox Text_Linkage_Zsmooth;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox Text_Linkage_MaxSp;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox Text_Linkage_Dec;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox Text_Linkage_Acc;
        private System.Windows.Forms.Label label19;
    }
}