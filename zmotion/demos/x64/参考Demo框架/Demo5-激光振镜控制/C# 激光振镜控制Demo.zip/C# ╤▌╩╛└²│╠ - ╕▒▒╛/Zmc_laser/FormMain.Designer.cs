﻿namespace Zmc_laser
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TabPageMark = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BTN_OpenTeach = new System.Windows.Forms.Button();
            this.Lab_FileName = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.BTN_SaveFile = new System.Windows.Forms.Button();
            this.Btn_Mid = new System.Windows.Forms.Button();
            this.Btn_Change = new System.Windows.Forms.Button();
            this.Btn_Del = new System.Windows.Forms.Button();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.Tab_MarkEdit = new System.Windows.Forms.TabControl();
            this.tabPage_Line = new System.Windows.Forms.TabPage();
            this.Line_IfSpiral = new System.Windows.Forms.CheckBox();
            this.Line_IfFill = new System.Windows.Forms.CheckBox();
            this.Line_End_Angle = new System.Windows.Forms.TextBox();
            this.labAngle2 = new System.Windows.Forms.Label();
            this.Lile_Type5 = new System.Windows.Forms.RadioButton();
            this.Lile_Type4 = new System.Windows.Forms.RadioButton();
            this.Lile_Type3 = new System.Windows.Forms.RadioButton();
            this.Lile_Type2 = new System.Windows.Forms.RadioButton();
            this.Lile_Type1 = new System.Windows.Forms.RadioButton();
            this.Line_Start_Angle = new System.Windows.Forms.TextBox();
            this.labAngle1 = new System.Windows.Forms.Label();
            this.Line_End_PosY = new System.Windows.Forms.TextBox();
            this.Line_Start_PosY = new System.Windows.Forms.TextBox();
            this.Line_End_PosX = new System.Windows.Forms.TextBox();
            this.Line_Start_PosX = new System.Windows.Forms.TextBox();
            this.labPosX = new System.Windows.Forms.Label();
            this.labEndY = new System.Windows.Forms.Label();
            this.labEndX = new System.Windows.Forms.Label();
            this.labPosY = new System.Windows.Forms.Label();
            this.tabPage_Word = new System.Windows.Forms.TabPage();
            this.Word_IfSpiral = new System.Windows.Forms.CheckBox();
            this.Word_IfFill = new System.Windows.Forms.CheckBox();
            this.Word_Text = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.Word_Delete = new System.Windows.Forms.CheckBox();
            this.Word_Italicas = new System.Windows.Forms.CheckBox();
            this.Word_UnderLine = new System.Windows.Forms.CheckBox();
            this.Word_Thickness = new System.Windows.Forms.CheckBox();
            this.Word_TiltI = new System.Windows.Forms.TextBox();
            this.Word_PosY = new System.Windows.Forms.TextBox();
            this.Word_PosX = new System.Windows.Forms.TextBox();
            this.Word_Aangle = new System.Windows.Forms.TextBox();
            this.Word_Width = new System.Windows.Forms.TextBox();
            this.Word_Height = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.Word_Accuracy = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.Word_Font = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage_BarCode = new System.Windows.Forms.TabPage();
            this.BarCode_Text = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.BarCode_IfSpiral = new System.Windows.Forms.CheckBox();
            this.BarCode_IfFill = new System.Windows.Forms.CheckBox();
            this.BarCode_Angle = new System.Windows.Forms.TextBox();
            this.BarCode_PosY = new System.Windows.Forms.TextBox();
            this.BarCode_PosX = new System.Windows.Forms.TextBox();
            this.BarCode_Width = new System.Windows.Forms.TextBox();
            this.BarCode_Heigth = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.BarCode_Type = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage_Cad = new System.Windows.Forms.TabPage();
            this.Cad_IfSpira = new System.Windows.Forms.CheckBox();
            this.Cad_IfFill = new System.Windows.Forms.CheckBox();
            this.Cad_Angle = new System.Windows.Forms.TextBox();
            this.Cad_PosY = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Cad_PosX = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.Btn_OpenCadFile = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.Cad_FileName = new System.Windows.Forms.TextBox();
            this.Cad_High = new System.Windows.Forms.TextBox();
            this.Cad_Width = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.Btn_Technology = new System.Windows.Forms.Button();
            this.groupBox_Work = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.BTN_SAVE = new System.Windows.Forms.Button();
            this.HomeFlah = new System.Windows.Forms.CheckBox();
            this.LoopRun = new System.Windows.Forms.CheckBox();
            this.Radio_Laser = new System.Windows.Forms.RadioButton();
            this.Radio_Red = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Check_Red = new System.Windows.Forms.CheckBox();
            this.Text_PwmDuty = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.Text_PwmFreq = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Text_Power = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.Text_JumpDelay = new System.Windows.Forms.TextBox();
            this.Text_MarkSpeed = new System.Windows.Forms.TextBox();
            this.Text_StartDelay = new System.Windows.Forms.TextBox();
            this.Text_EmpSpeed = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Text_CornerDelay = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Text_EndDelay = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.File_listView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.TEXT_ALM = new System.Windows.Forms.RichTextBox();
            this.MyPicture = new System.Windows.Forms.PictureBox();
            this.Lab_ScanStatus = new System.Windows.Forms.Label();
            this.Lab_AxisStatus = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label69 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.Btn_SetPara = new System.Windows.Forms.Button();
            this.Btn_IoStatus = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.TabPageMark.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.Tab_MarkEdit.SuspendLayout();
            this.tabPage_Line.SuspendLayout();
            this.tabPage_Word.SuspendLayout();
            this.tabPage_BarCode.SuspendLayout();
            this.tabPage_Cad.SuspendLayout();
            this.groupBox_Work.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MyPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.TabPageMark);
            this.tabControl1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(1, 80);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(1);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 771);
            this.tabControl1.TabIndex = 0;
            // 
            // TabPageMark
            // 
            this.TabPageMark.Controls.Add(this.groupBox2);
            this.TabPageMark.Controls.Add(this.groupBox_Work);
            this.TabPageMark.Controls.Add(this.tabControl2);
            this.TabPageMark.Controls.Add(this.MyPicture);
            this.TabPageMark.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TabPageMark.Location = new System.Drawing.Point(4, 4);
            this.TabPageMark.Margin = new System.Windows.Forms.Padding(1);
            this.TabPageMark.Name = "TabPageMark";
            this.TabPageMark.Padding = new System.Windows.Forms.Padding(3);
            this.TabPageMark.Size = new System.Drawing.Size(1327, 743);
            this.TabPageMark.TabIndex = 0;
            this.TabPageMark.Text = "标刻文件";
            this.TabPageMark.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.BTN_OpenTeach);
            this.groupBox2.Controls.Add(this.Lab_FileName);
            this.groupBox2.Controls.Add(this.label75);
            this.groupBox2.Controls.Add(this.BTN_SaveFile);
            this.groupBox2.Controls.Add(this.Btn_Mid);
            this.groupBox2.Controls.Add(this.Btn_Change);
            this.groupBox2.Controls.Add(this.Btn_Del);
            this.groupBox2.Controls.Add(this.Btn_Add);
            this.groupBox2.Controls.Add(this.Tab_MarkEdit);
            this.groupBox2.Controls.Add(this.Btn_Technology);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(949, 1);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox2.Size = new System.Drawing.Size(377, 359);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "图形编辑";
            this.groupBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox2_Paint);
            // 
            // BTN_OpenTeach
            // 
            this.BTN_OpenTeach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_OpenTeach.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BTN_OpenTeach.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_OpenTeach.Location = new System.Drawing.Point(211, 16);
            this.BTN_OpenTeach.Name = "BTN_OpenTeach";
            this.BTN_OpenTeach.Size = new System.Drawing.Size(75, 27);
            this.BTN_OpenTeach.TabIndex = 72;
            this.BTN_OpenTeach.Text = "打开文件";
            this.BTN_OpenTeach.UseVisualStyleBackColor = false;
            this.BTN_OpenTeach.Click += new System.EventHandler(this.BTN_OpenTeach_Click_1);
            // 
            // Lab_FileName
            // 
            this.Lab_FileName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lab_FileName.AutoSize = true;
            this.Lab_FileName.Location = new System.Drawing.Point(51, 23);
            this.Lab_FileName.Name = "Lab_FileName";
            this.Lab_FileName.Size = new System.Drawing.Size(70, 14);
            this.Lab_FileName.TabIndex = 71;
            this.Lab_FileName.Text = "Teach.txt";
            this.Lab_FileName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label75
            // 
            this.label75.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(3, 23);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(42, 14);
            this.label75.TabIndex = 70;
            this.label75.Text = "文件:";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BTN_SaveFile
            // 
            this.BTN_SaveFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_SaveFile.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BTN_SaveFile.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_SaveFile.Location = new System.Drawing.Point(296, 16);
            this.BTN_SaveFile.Name = "BTN_SaveFile";
            this.BTN_SaveFile.Size = new System.Drawing.Size(75, 27);
            this.BTN_SaveFile.TabIndex = 69;
            this.BTN_SaveFile.Text = "保存文件";
            this.BTN_SaveFile.UseVisualStyleBackColor = false;
            this.BTN_SaveFile.Click += new System.EventHandler(this.BTN_SaveFile_Click);
            // 
            // Btn_Mid
            // 
            this.Btn_Mid.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Btn_Mid.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_Mid.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Btn_Mid.Location = new System.Drawing.Point(211, 326);
            this.Btn_Mid.Name = "Btn_Mid";
            this.Btn_Mid.Size = new System.Drawing.Size(63, 27);
            this.Btn_Mid.TabIndex = 68;
            this.Btn_Mid.Text = "居  中";
            this.Btn_Mid.UseVisualStyleBackColor = false;
            this.Btn_Mid.Click += new System.EventHandler(this.Btn_Mid_Click);
            // 
            // Btn_Change
            // 
            this.Btn_Change.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Btn_Change.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_Change.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Btn_Change.Location = new System.Drawing.Point(143, 326);
            this.Btn_Change.Name = "Btn_Change";
            this.Btn_Change.Size = new System.Drawing.Size(63, 27);
            this.Btn_Change.TabIndex = 67;
            this.Btn_Change.Text = "修  改";
            this.Btn_Change.UseVisualStyleBackColor = false;
            this.Btn_Change.Click += new System.EventHandler(this.Btn_Change_Click);
            // 
            // Btn_Del
            // 
            this.Btn_Del.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Btn_Del.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_Del.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Btn_Del.Location = new System.Drawing.Point(75, 326);
            this.Btn_Del.Name = "Btn_Del";
            this.Btn_Del.Size = new System.Drawing.Size(63, 27);
            this.Btn_Del.TabIndex = 66;
            this.Btn_Del.Text = "删  除";
            this.Btn_Del.UseVisualStyleBackColor = false;
            this.Btn_Del.Click += new System.EventHandler(this.Btn_Del_Click);
            // 
            // Btn_Add
            // 
            this.Btn_Add.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Btn_Add.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_Add.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Btn_Add.Location = new System.Drawing.Point(7, 326);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(63, 27);
            this.Btn_Add.TabIndex = 65;
            this.Btn_Add.Text = "添  加";
            this.Btn_Add.UseVisualStyleBackColor = false;
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // Tab_MarkEdit
            // 
            this.Tab_MarkEdit.Controls.Add(this.tabPage_Line);
            this.Tab_MarkEdit.Controls.Add(this.tabPage_Word);
            this.Tab_MarkEdit.Controls.Add(this.tabPage_BarCode);
            this.Tab_MarkEdit.Controls.Add(this.tabPage_Cad);
            this.Tab_MarkEdit.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Tab_MarkEdit.Location = new System.Drawing.Point(6, 48);
            this.Tab_MarkEdit.Name = "Tab_MarkEdit";
            this.Tab_MarkEdit.SelectedIndex = 0;
            this.Tab_MarkEdit.Size = new System.Drawing.Size(369, 270);
            this.Tab_MarkEdit.TabIndex = 3;
            this.Tab_MarkEdit.Selected += new System.Windows.Forms.TabControlEventHandler(this.Tab_MarkEdit_Selected);
            // 
            // tabPage_Line
            // 
            this.tabPage_Line.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_Line.Controls.Add(this.Line_IfSpiral);
            this.tabPage_Line.Controls.Add(this.Line_IfFill);
            this.tabPage_Line.Controls.Add(this.Line_End_Angle);
            this.tabPage_Line.Controls.Add(this.labAngle2);
            this.tabPage_Line.Controls.Add(this.Lile_Type5);
            this.tabPage_Line.Controls.Add(this.Lile_Type4);
            this.tabPage_Line.Controls.Add(this.Lile_Type3);
            this.tabPage_Line.Controls.Add(this.Lile_Type2);
            this.tabPage_Line.Controls.Add(this.Lile_Type1);
            this.tabPage_Line.Controls.Add(this.Line_Start_Angle);
            this.tabPage_Line.Controls.Add(this.labAngle1);
            this.tabPage_Line.Controls.Add(this.Line_End_PosY);
            this.tabPage_Line.Controls.Add(this.Line_Start_PosY);
            this.tabPage_Line.Controls.Add(this.Line_End_PosX);
            this.tabPage_Line.Controls.Add(this.Line_Start_PosX);
            this.tabPage_Line.Controls.Add(this.labPosX);
            this.tabPage_Line.Controls.Add(this.labEndY);
            this.tabPage_Line.Controls.Add(this.labEndX);
            this.tabPage_Line.Controls.Add(this.labPosY);
            this.tabPage_Line.Location = new System.Drawing.Point(4, 24);
            this.tabPage_Line.Margin = new System.Windows.Forms.Padding(1);
            this.tabPage_Line.Name = "tabPage_Line";
            this.tabPage_Line.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Line.Size = new System.Drawing.Size(361, 242);
            this.tabPage_Line.TabIndex = 0;
            this.tabPage_Line.Text = "多段线";
            this.tabPage_Line.UseVisualStyleBackColor = true;
            // 
            // Line_IfSpiral
            // 
            this.Line_IfSpiral.AutoSize = true;
            this.Line_IfSpiral.Location = new System.Drawing.Point(115, 209);
            this.Line_IfSpiral.Name = "Line_IfSpiral";
            this.Line_IfSpiral.Size = new System.Drawing.Size(96, 18);
            this.Line_IfSpiral.TabIndex = 81;
            this.Line_IfSpiral.Text = "螺旋线使能";
            this.Line_IfSpiral.UseVisualStyleBackColor = true;
            this.Line_IfSpiral.CheckedChanged += new System.EventHandler(this.SpiralCheck_CheckedChanged);
            // 
            // Line_IfFill
            // 
            this.Line_IfFill.AutoSize = true;
            this.Line_IfFill.Location = new System.Drawing.Point(13, 209);
            this.Line_IfFill.Name = "Line_IfFill";
            this.Line_IfFill.Size = new System.Drawing.Size(82, 18);
            this.Line_IfFill.TabIndex = 80;
            this.Line_IfFill.Text = "填充使能";
            this.Line_IfFill.UseVisualStyleBackColor = true;
            this.Line_IfFill.CheckedChanged += new System.EventHandler(this.FillCheck_CheckedChanged);
            // 
            // Line_End_Angle
            // 
            this.Line_End_Angle.Location = new System.Drawing.Point(258, 138);
            this.Line_End_Angle.Name = "Line_End_Angle";
            this.Line_End_Angle.Size = new System.Drawing.Size(58, 23);
            this.Line_End_Angle.TabIndex = 79;
            this.Line_End_Angle.Text = "90";
            this.Line_End_Angle.Visible = false;
            // 
            // labAngle2
            // 
            this.labAngle2.AutoSize = true;
            this.labAngle2.Location = new System.Drawing.Point(193, 145);
            this.labAngle2.Name = "labAngle2";
            this.labAngle2.Size = new System.Drawing.Size(70, 14);
            this.labAngle2.TabIndex = 78;
            this.labAngle2.Text = "旋转角度:";
            this.labAngle2.Visible = false;
            // 
            // Lile_Type5
            // 
            this.Lile_Type5.AutoSize = true;
            this.Lile_Type5.Checked = true;
            this.Lile_Type5.Location = new System.Drawing.Point(281, 28);
            this.Lile_Type5.Name = "Lile_Type5";
            this.Lile_Type5.Size = new System.Drawing.Size(53, 18);
            this.Lile_Type5.TabIndex = 77;
            this.Lile_Type5.TabStop = true;
            this.Lile_Type5.Text = "矩形";
            this.Lile_Type5.UseVisualStyleBackColor = true;
            this.Lile_Type5.CheckedChanged += new System.EventHandler(this.Lile_Type5_CheckedChanged);
            // 
            // Lile_Type4
            // 
            this.Lile_Type4.AutoSize = true;
            this.Lile_Type4.Location = new System.Drawing.Point(212, 28);
            this.Lile_Type4.Name = "Lile_Type4";
            this.Lile_Type4.Size = new System.Drawing.Size(53, 18);
            this.Lile_Type4.TabIndex = 76;
            this.Lile_Type4.TabStop = true;
            this.Lile_Type4.Text = "整圆";
            this.Lile_Type4.UseVisualStyleBackColor = true;
            this.Lile_Type4.CheckedChanged += new System.EventHandler(this.Lile_Type4_CheckedChanged);
            // 
            // Lile_Type3
            // 
            this.Lile_Type3.AutoSize = true;
            this.Lile_Type3.Location = new System.Drawing.Point(143, 28);
            this.Lile_Type3.Name = "Lile_Type3";
            this.Lile_Type3.Size = new System.Drawing.Size(53, 18);
            this.Lile_Type3.TabIndex = 75;
            this.Lile_Type3.TabStop = true;
            this.Lile_Type3.Text = "圆弧";
            this.Lile_Type3.UseVisualStyleBackColor = true;
            this.Lile_Type3.CheckedChanged += new System.EventHandler(this.Lile_Type3_CheckedChanged);
            // 
            // Lile_Type2
            // 
            this.Lile_Type2.AutoSize = true;
            this.Lile_Type2.Location = new System.Drawing.Point(74, 28);
            this.Lile_Type2.Name = "Lile_Type2";
            this.Lile_Type2.Size = new System.Drawing.Size(53, 18);
            this.Lile_Type2.TabIndex = 74;
            this.Lile_Type2.TabStop = true;
            this.Lile_Type2.Text = "直线";
            this.Lile_Type2.UseVisualStyleBackColor = true;
            this.Lile_Type2.CheckedChanged += new System.EventHandler(this.Lile_Type2_CheckedChanged);
            // 
            // Lile_Type1
            // 
            this.Lile_Type1.AutoSize = true;
            this.Lile_Type1.Location = new System.Drawing.Point(17, 28);
            this.Lile_Type1.Name = "Lile_Type1";
            this.Lile_Type1.Size = new System.Drawing.Size(39, 18);
            this.Lile_Type1.TabIndex = 73;
            this.Lile_Type1.TabStop = true;
            this.Lile_Type1.Text = "点";
            this.Lile_Type1.UseVisualStyleBackColor = true;
            this.Lile_Type1.CheckedChanged += new System.EventHandler(this.Lile_Type1_CheckedChanged);
            // 
            // Line_Start_Angle
            // 
            this.Line_Start_Angle.Location = new System.Drawing.Point(81, 138);
            this.Line_Start_Angle.Name = "Line_Start_Angle";
            this.Line_Start_Angle.Size = new System.Drawing.Size(58, 23);
            this.Line_Start_Angle.TabIndex = 70;
            this.Line_Start_Angle.Text = "0";
            this.Line_Start_Angle.Visible = false;
            // 
            // labAngle1
            // 
            this.labAngle1.AutoSize = true;
            this.labAngle1.Location = new System.Drawing.Point(16, 145);
            this.labAngle1.Name = "labAngle1";
            this.labAngle1.Size = new System.Drawing.Size(70, 14);
            this.labAngle1.TabIndex = 65;
            this.labAngle1.Text = "起始角度:";
            this.labAngle1.Visible = false;
            // 
            // Line_End_PosY
            // 
            this.Line_End_PosY.Location = new System.Drawing.Point(258, 103);
            this.Line_End_PosY.Name = "Line_End_PosY";
            this.Line_End_PosY.Size = new System.Drawing.Size(58, 23);
            this.Line_End_PosY.TabIndex = 72;
            this.Line_End_PosY.Text = "10";
            // 
            // Line_Start_PosY
            // 
            this.Line_Start_PosY.Location = new System.Drawing.Point(258, 67);
            this.Line_Start_PosY.Name = "Line_Start_PosY";
            this.Line_Start_PosY.Size = new System.Drawing.Size(58, 23);
            this.Line_Start_PosY.TabIndex = 71;
            this.Line_Start_PosY.Text = "0";
            // 
            // Line_End_PosX
            // 
            this.Line_End_PosX.Location = new System.Drawing.Point(81, 105);
            this.Line_End_PosX.Name = "Line_End_PosX";
            this.Line_End_PosX.Size = new System.Drawing.Size(58, 23);
            this.Line_End_PosX.TabIndex = 69;
            this.Line_End_PosX.Text = "10";
            // 
            // Line_Start_PosX
            // 
            this.Line_Start_PosX.Location = new System.Drawing.Point(81, 69);
            this.Line_Start_PosX.Name = "Line_Start_PosX";
            this.Line_Start_PosX.Size = new System.Drawing.Size(58, 23);
            this.Line_Start_PosX.TabIndex = 68;
            this.Line_Start_PosX.Text = "0";
            // 
            // labPosX
            // 
            this.labPosX.AutoSize = true;
            this.labPosX.Location = new System.Drawing.Point(16, 76);
            this.labPosX.Name = "labPosX";
            this.labPosX.Size = new System.Drawing.Size(56, 14);
            this.labPosX.TabIndex = 63;
            this.labPosX.Text = "起点X：";
            // 
            // labEndY
            // 
            this.labEndY.AutoSize = true;
            this.labEndY.Location = new System.Drawing.Point(193, 108);
            this.labEndY.Name = "labEndY";
            this.labEndY.Size = new System.Drawing.Size(70, 14);
            this.labEndY.TabIndex = 67;
            this.labEndY.Text = "结束点Y：";
            // 
            // labEndX
            // 
            this.labEndX.AutoSize = true;
            this.labEndX.Location = new System.Drawing.Point(16, 112);
            this.labEndX.Name = "labEndX";
            this.labEndX.Size = new System.Drawing.Size(70, 14);
            this.labEndX.TabIndex = 64;
            this.labEndX.Text = "结束点X：";
            // 
            // labPosY
            // 
            this.labPosY.AutoSize = true;
            this.labPosY.Location = new System.Drawing.Point(193, 72);
            this.labPosY.Name = "labPosY";
            this.labPosY.Size = new System.Drawing.Size(56, 14);
            this.labPosY.TabIndex = 66;
            this.labPosY.Text = "起点Y：";
            // 
            // tabPage_Word
            // 
            this.tabPage_Word.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_Word.Controls.Add(this.Word_IfSpiral);
            this.tabPage_Word.Controls.Add(this.Word_IfFill);
            this.tabPage_Word.Controls.Add(this.Word_Text);
            this.tabPage_Word.Controls.Add(this.label37);
            this.tabPage_Word.Controls.Add(this.Word_Delete);
            this.tabPage_Word.Controls.Add(this.Word_Italicas);
            this.tabPage_Word.Controls.Add(this.Word_UnderLine);
            this.tabPage_Word.Controls.Add(this.Word_Thickness);
            this.tabPage_Word.Controls.Add(this.Word_TiltI);
            this.tabPage_Word.Controls.Add(this.Word_PosY);
            this.tabPage_Word.Controls.Add(this.Word_PosX);
            this.tabPage_Word.Controls.Add(this.Word_Aangle);
            this.tabPage_Word.Controls.Add(this.Word_Width);
            this.tabPage_Word.Controls.Add(this.Word_Height);
            this.tabPage_Word.Controls.Add(this.label36);
            this.tabPage_Word.Controls.Add(this.label8);
            this.tabPage_Word.Controls.Add(this.label9);
            this.tabPage_Word.Controls.Add(this.label15);
            this.tabPage_Word.Controls.Add(this.label16);
            this.tabPage_Word.Controls.Add(this.label17);
            this.tabPage_Word.Controls.Add(this.Word_Accuracy);
            this.tabPage_Word.Controls.Add(this.label30);
            this.tabPage_Word.Controls.Add(this.Word_Font);
            this.tabPage_Word.Controls.Add(this.label18);
            this.tabPage_Word.Location = new System.Drawing.Point(4, 24);
            this.tabPage_Word.Name = "tabPage_Word";
            this.tabPage_Word.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Word.Size = new System.Drawing.Size(361, 242);
            this.tabPage_Word.TabIndex = 1;
            this.tabPage_Word.Text = "文本";
            this.tabPage_Word.UseVisualStyleBackColor = true;
            // 
            // Word_IfSpiral
            // 
            this.Word_IfSpiral.AutoSize = true;
            this.Word_IfSpiral.Location = new System.Drawing.Point(115, 216);
            this.Word_IfSpiral.Name = "Word_IfSpiral";
            this.Word_IfSpiral.Size = new System.Drawing.Size(96, 18);
            this.Word_IfSpiral.TabIndex = 83;
            this.Word_IfSpiral.Text = "螺旋线使能";
            this.Word_IfSpiral.UseVisualStyleBackColor = true;
            this.Word_IfSpiral.CheckedChanged += new System.EventHandler(this.SpiralCheck_CheckedChanged);
            // 
            // Word_IfFill
            // 
            this.Word_IfFill.AutoSize = true;
            this.Word_IfFill.Location = new System.Drawing.Point(13, 216);
            this.Word_IfFill.Name = "Word_IfFill";
            this.Word_IfFill.Size = new System.Drawing.Size(82, 18);
            this.Word_IfFill.TabIndex = 82;
            this.Word_IfFill.Text = "填充使能";
            this.Word_IfFill.UseVisualStyleBackColor = true;
            this.Word_IfFill.CheckedChanged += new System.EventHandler(this.FillCheck_CheckedChanged);
            // 
            // Word_Text
            // 
            this.Word_Text.Location = new System.Drawing.Point(55, 185);
            this.Word_Text.Name = "Word_Text";
            this.Word_Text.Size = new System.Drawing.Size(287, 23);
            this.Word_Text.TabIndex = 73;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(15, 188);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(42, 14);
            this.label37.TabIndex = 72;
            this.label37.Text = "文本:";
            // 
            // Word_Delete
            // 
            this.Word_Delete.AutoSize = true;
            this.Word_Delete.Location = new System.Drawing.Point(263, 155);
            this.Word_Delete.Name = "Word_Delete";
            this.Word_Delete.Size = new System.Drawing.Size(68, 18);
            this.Word_Delete.TabIndex = 71;
            this.Word_Delete.Text = "删除线";
            this.Word_Delete.UseVisualStyleBackColor = true;
            // 
            // Word_Italicas
            // 
            this.Word_Italicas.AutoSize = true;
            this.Word_Italicas.Location = new System.Drawing.Point(181, 155);
            this.Word_Italicas.Name = "Word_Italicas";
            this.Word_Italicas.Size = new System.Drawing.Size(54, 18);
            this.Word_Italicas.TabIndex = 70;
            this.Word_Italicas.Text = "倾斜";
            this.Word_Italicas.UseVisualStyleBackColor = true;
            // 
            // Word_UnderLine
            // 
            this.Word_UnderLine.AutoSize = true;
            this.Word_UnderLine.Location = new System.Drawing.Point(99, 155);
            this.Word_UnderLine.Name = "Word_UnderLine";
            this.Word_UnderLine.Size = new System.Drawing.Size(68, 18);
            this.Word_UnderLine.TabIndex = 69;
            this.Word_UnderLine.Text = "下划线";
            this.Word_UnderLine.UseVisualStyleBackColor = true;
            // 
            // Word_Thickness
            // 
            this.Word_Thickness.AutoSize = true;
            this.Word_Thickness.Location = new System.Drawing.Point(17, 155);
            this.Word_Thickness.Name = "Word_Thickness";
            this.Word_Thickness.Size = new System.Drawing.Size(54, 18);
            this.Word_Thickness.TabIndex = 53;
            this.Word_Thickness.Text = "加粗";
            this.Word_Thickness.UseVisualStyleBackColor = true;
            // 
            // Word_TiltI
            // 
            this.Word_TiltI.Location = new System.Drawing.Point(247, 122);
            this.Word_TiltI.Name = "Word_TiltI";
            this.Word_TiltI.Size = new System.Drawing.Size(90, 23);
            this.Word_TiltI.TabIndex = 68;
            this.Word_TiltI.Text = "0";
            // 
            // Word_PosY
            // 
            this.Word_PosY.Location = new System.Drawing.Point(247, 50);
            this.Word_PosY.Name = "Word_PosY";
            this.Word_PosY.Size = new System.Drawing.Size(90, 23);
            this.Word_PosY.TabIndex = 67;
            this.Word_PosY.Text = "0";
            // 
            // Word_PosX
            // 
            this.Word_PosX.Location = new System.Drawing.Point(80, 51);
            this.Word_PosX.Name = "Word_PosX";
            this.Word_PosX.Size = new System.Drawing.Size(90, 23);
            this.Word_PosX.TabIndex = 66;
            this.Word_PosX.Text = "0";
            // 
            // Word_Aangle
            // 
            this.Word_Aangle.Location = new System.Drawing.Point(80, 120);
            this.Word_Aangle.Name = "Word_Aangle";
            this.Word_Aangle.Size = new System.Drawing.Size(90, 23);
            this.Word_Aangle.TabIndex = 65;
            this.Word_Aangle.Text = "0";
            // 
            // Word_Width
            // 
            this.Word_Width.Location = new System.Drawing.Point(80, 84);
            this.Word_Width.Name = "Word_Width";
            this.Word_Width.Size = new System.Drawing.Size(90, 23);
            this.Word_Width.TabIndex = 64;
            this.Word_Width.Text = "30";
            // 
            // Word_Height
            // 
            this.Word_Height.Location = new System.Drawing.Point(247, 87);
            this.Word_Height.Name = "Word_Height";
            this.Word_Height.Size = new System.Drawing.Size(90, 23);
            this.Word_Height.TabIndex = 63;
            this.Word_Height.Text = "30";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(182, 127);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(70, 14);
            this.label36.TabIndex = 62;
            this.label36.Text = "倾斜角度:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(182, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 14);
            this.label8.TabIndex = 61;
            this.label8.Text = "Y位置：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 14);
            this.label9.TabIndex = 60;
            this.label9.Text = "X位置：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 127);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 14);
            this.label15.TabIndex = 59;
            this.label15.Text = "旋转角度:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 91);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 14);
            this.label16.TabIndex = 58;
            this.label16.Text = "宽度：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(182, 94);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 14);
            this.label17.TabIndex = 57;
            this.label17.Text = "高度：";
            // 
            // Word_Accuracy
            // 
            this.Word_Accuracy.Location = new System.Drawing.Point(247, 15);
            this.Word_Accuracy.Name = "Word_Accuracy";
            this.Word_Accuracy.Size = new System.Drawing.Size(90, 23);
            this.Word_Accuracy.TabIndex = 52;
            this.Word_Accuracy.Text = "0.1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(182, 19);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(70, 14);
            this.label30.TabIndex = 56;
            this.label30.Text = "文本精度:";
            // 
            // Word_Font
            // 
            this.Word_Font.FormattingEnabled = true;
            this.Word_Font.Location = new System.Drawing.Point(50, 16);
            this.Word_Font.Name = "Word_Font";
            this.Word_Font.Size = new System.Drawing.Size(121, 22);
            this.Word_Font.TabIndex = 55;
            this.Word_Font.Text = "宋体";
            this.Word_Font.DropDown += new System.EventHandler(this.Word_Font_DropDown);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 14);
            this.label18.TabIndex = 54;
            this.label18.Text = "字体:";
            // 
            // tabPage_BarCode
            // 
            this.tabPage_BarCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_BarCode.Controls.Add(this.BarCode_Text);
            this.tabPage_BarCode.Controls.Add(this.label23);
            this.tabPage_BarCode.Controls.Add(this.BarCode_IfSpiral);
            this.tabPage_BarCode.Controls.Add(this.BarCode_IfFill);
            this.tabPage_BarCode.Controls.Add(this.BarCode_Angle);
            this.tabPage_BarCode.Controls.Add(this.BarCode_PosY);
            this.tabPage_BarCode.Controls.Add(this.BarCode_PosX);
            this.tabPage_BarCode.Controls.Add(this.BarCode_Width);
            this.tabPage_BarCode.Controls.Add(this.BarCode_Heigth);
            this.tabPage_BarCode.Controls.Add(this.label1);
            this.tabPage_BarCode.Controls.Add(this.label3);
            this.tabPage_BarCode.Controls.Add(this.label4);
            this.tabPage_BarCode.Controls.Add(this.label5);
            this.tabPage_BarCode.Controls.Add(this.label6);
            this.tabPage_BarCode.Controls.Add(this.BarCode_Type);
            this.tabPage_BarCode.Controls.Add(this.label7);
            this.tabPage_BarCode.Location = new System.Drawing.Point(4, 24);
            this.tabPage_BarCode.Name = "tabPage_BarCode";
            this.tabPage_BarCode.Size = new System.Drawing.Size(361, 242);
            this.tabPage_BarCode.TabIndex = 2;
            this.tabPage_BarCode.Text = "条码";
            this.tabPage_BarCode.UseVisualStyleBackColor = true;
            // 
            // BarCode_Text
            // 
            this.BarCode_Text.Location = new System.Drawing.Point(81, 166);
            this.BarCode_Text.Name = "BarCode_Text";
            this.BarCode_Text.Size = new System.Drawing.Size(250, 23);
            this.BarCode_Text.TabIndex = 85;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 169);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 14);
            this.label23.TabIndex = 84;
            this.label23.Text = "条码内容:";
            // 
            // BarCode_IfSpiral
            // 
            this.BarCode_IfSpiral.AutoSize = true;
            this.BarCode_IfSpiral.Location = new System.Drawing.Point(115, 213);
            this.BarCode_IfSpiral.Name = "BarCode_IfSpiral";
            this.BarCode_IfSpiral.Size = new System.Drawing.Size(96, 18);
            this.BarCode_IfSpiral.TabIndex = 83;
            this.BarCode_IfSpiral.Text = "螺旋线使能";
            this.BarCode_IfSpiral.UseVisualStyleBackColor = true;
            this.BarCode_IfSpiral.CheckedChanged += new System.EventHandler(this.SpiralCheck_CheckedChanged);
            // 
            // BarCode_IfFill
            // 
            this.BarCode_IfFill.AutoSize = true;
            this.BarCode_IfFill.Location = new System.Drawing.Point(13, 213);
            this.BarCode_IfFill.Name = "BarCode_IfFill";
            this.BarCode_IfFill.Size = new System.Drawing.Size(82, 18);
            this.BarCode_IfFill.TabIndex = 82;
            this.BarCode_IfFill.Text = "填充使能";
            this.BarCode_IfFill.UseVisualStyleBackColor = true;
            this.BarCode_IfFill.CheckedChanged += new System.EventHandler(this.FillCheck_CheckedChanged);
            // 
            // BarCode_Angle
            // 
            this.BarCode_Angle.Location = new System.Drawing.Point(81, 125);
            this.BarCode_Angle.Name = "BarCode_Angle";
            this.BarCode_Angle.Size = new System.Drawing.Size(90, 23);
            this.BarCode_Angle.TabIndex = 68;
            this.BarCode_Angle.Text = "0";
            // 
            // BarCode_PosY
            // 
            this.BarCode_PosY.Location = new System.Drawing.Point(241, 55);
            this.BarCode_PosY.Name = "BarCode_PosY";
            this.BarCode_PosY.Size = new System.Drawing.Size(90, 23);
            this.BarCode_PosY.TabIndex = 67;
            this.BarCode_PosY.Text = "0";
            // 
            // BarCode_PosX
            // 
            this.BarCode_PosX.Location = new System.Drawing.Point(79, 55);
            this.BarCode_PosX.Name = "BarCode_PosX";
            this.BarCode_PosX.Size = new System.Drawing.Size(90, 23);
            this.BarCode_PosX.TabIndex = 66;
            this.BarCode_PosX.Text = "0";
            // 
            // BarCode_Width
            // 
            this.BarCode_Width.Location = new System.Drawing.Point(80, 89);
            this.BarCode_Width.Name = "BarCode_Width";
            this.BarCode_Width.Size = new System.Drawing.Size(90, 23);
            this.BarCode_Width.TabIndex = 65;
            this.BarCode_Width.Text = "30";
            // 
            // BarCode_Heigth
            // 
            this.BarCode_Heigth.Location = new System.Drawing.Point(241, 89);
            this.BarCode_Heigth.Name = "BarCode_Heigth";
            this.BarCode_Heigth.Size = new System.Drawing.Size(90, 23);
            this.BarCode_Heigth.TabIndex = 64;
            this.BarCode_Heigth.Text = "30";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(182, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 14);
            this.label1.TabIndex = 63;
            this.label1.Text = "Y位置：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 14);
            this.label3.TabIndex = 62;
            this.label3.Text = "X位置：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 14);
            this.label4.TabIndex = 61;
            this.label4.Text = "旋转角度:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 14);
            this.label5.TabIndex = 60;
            this.label5.Text = "宽度：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(182, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 14);
            this.label6.TabIndex = 59;
            this.label6.Text = "高度：";
            // 
            // BarCode_Type
            // 
            this.BarCode_Type.FormattingEnabled = true;
            this.BarCode_Type.Items.AddRange(new object[] {
            "Code 39",
            "Code 93",
            "Code 128A",
            "Code 128B",
            "Code 128C",
            "EAN-8",
            "EAN-13",
            "EAN 128A",
            "EAN 128B",
            "EAN 128C",
            "UPC-A",
            "UPC-E",
            "GS1-128",
            "QR Code",
            "Code 25",
            "ITF 25",
            "Codabar"});
            this.BarCode_Type.Location = new System.Drawing.Point(79, 18);
            this.BarCode_Type.Name = "BarCode_Type";
            this.BarCode_Type.Size = new System.Drawing.Size(121, 22);
            this.BarCode_Type.TabIndex = 58;
            this.BarCode_Type.Text = "QR Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 14);
            this.label7.TabIndex = 57;
            this.label7.Text = "条码类型:";
            // 
            // tabPage_Cad
            // 
            this.tabPage_Cad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_Cad.Controls.Add(this.Cad_IfSpira);
            this.tabPage_Cad.Controls.Add(this.Cad_IfFill);
            this.tabPage_Cad.Controls.Add(this.Cad_Angle);
            this.tabPage_Cad.Controls.Add(this.Cad_PosY);
            this.tabPage_Cad.Controls.Add(this.label33);
            this.tabPage_Cad.Controls.Add(this.label34);
            this.tabPage_Cad.Controls.Add(this.label32);
            this.tabPage_Cad.Controls.Add(this.Cad_PosX);
            this.tabPage_Cad.Controls.Add(this.label35);
            this.tabPage_Cad.Controls.Add(this.Btn_OpenCadFile);
            this.tabPage_Cad.Controls.Add(this.label31);
            this.tabPage_Cad.Controls.Add(this.Cad_FileName);
            this.tabPage_Cad.Controls.Add(this.Cad_High);
            this.tabPage_Cad.Controls.Add(this.Cad_Width);
            this.tabPage_Cad.Controls.Add(this.label29);
            this.tabPage_Cad.Location = new System.Drawing.Point(4, 24);
            this.tabPage_Cad.Name = "tabPage_Cad";
            this.tabPage_Cad.Size = new System.Drawing.Size(361, 242);
            this.tabPage_Cad.TabIndex = 3;
            this.tabPage_Cad.Text = "CAD";
            this.tabPage_Cad.UseVisualStyleBackColor = true;
            // 
            // Cad_IfSpira
            // 
            this.Cad_IfSpira.AutoSize = true;
            this.Cad_IfSpira.Location = new System.Drawing.Point(115, 210);
            this.Cad_IfSpira.Name = "Cad_IfSpira";
            this.Cad_IfSpira.Size = new System.Drawing.Size(96, 18);
            this.Cad_IfSpira.TabIndex = 83;
            this.Cad_IfSpira.Text = "螺旋线使能";
            this.Cad_IfSpira.UseVisualStyleBackColor = true;
            this.Cad_IfSpira.CheckedChanged += new System.EventHandler(this.SpiralCheck_CheckedChanged);
            // 
            // Cad_IfFill
            // 
            this.Cad_IfFill.AutoSize = true;
            this.Cad_IfFill.Location = new System.Drawing.Point(13, 210);
            this.Cad_IfFill.Name = "Cad_IfFill";
            this.Cad_IfFill.Size = new System.Drawing.Size(82, 18);
            this.Cad_IfFill.TabIndex = 82;
            this.Cad_IfFill.Text = "填充使能";
            this.Cad_IfFill.UseVisualStyleBackColor = true;
            this.Cad_IfFill.CheckedChanged += new System.EventHandler(this.FillCheck_CheckedChanged);
            // 
            // Cad_Angle
            // 
            this.Cad_Angle.Location = new System.Drawing.Point(65, 134);
            this.Cad_Angle.Name = "Cad_Angle";
            this.Cad_Angle.Size = new System.Drawing.Size(90, 23);
            this.Cad_Angle.TabIndex = 66;
            this.Cad_Angle.Text = "0";
            // 
            // Cad_PosY
            // 
            this.Cad_PosY.Location = new System.Drawing.Point(231, 60);
            this.Cad_PosY.Name = "Cad_PosY";
            this.Cad_PosY.Size = new System.Drawing.Size(90, 23);
            this.Cad_PosY.TabIndex = 68;
            this.Cad_PosY.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 137);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(70, 14);
            this.label33.TabIndex = 61;
            this.label33.Text = "旋转角度:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(8, 63);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(56, 14);
            this.label34.TabIndex = 62;
            this.label34.Text = "X位置：";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(8, 101);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(49, 14);
            this.label32.TabIndex = 60;
            this.label32.Text = "宽度：";
            // 
            // Cad_PosX
            // 
            this.Cad_PosX.Location = new System.Drawing.Point(65, 60);
            this.Cad_PosX.Name = "Cad_PosX";
            this.Cad_PosX.Size = new System.Drawing.Size(90, 23);
            this.Cad_PosX.TabIndex = 67;
            this.Cad_PosX.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(184, 63);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(56, 14);
            this.label35.TabIndex = 63;
            this.label35.Text = "Y位置：";
            // 
            // Btn_OpenCadFile
            // 
            this.Btn_OpenCadFile.BackColor = System.Drawing.Color.Silver;
            this.Btn_OpenCadFile.Location = new System.Drawing.Point(268, 18);
            this.Btn_OpenCadFile.Name = "Btn_OpenCadFile";
            this.Btn_OpenCadFile.Size = new System.Drawing.Size(75, 23);
            this.Btn_OpenCadFile.TabIndex = 58;
            this.Btn_OpenCadFile.Text = "选择文件";
            this.Btn_OpenCadFile.UseVisualStyleBackColor = false;
            this.Btn_OpenCadFile.Click += new System.EventHandler(this.Btn_OpenCadFile_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(184, 107);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 14);
            this.label31.TabIndex = 59;
            this.label31.Text = "高度：";
            // 
            // Cad_FileName
            // 
            this.Cad_FileName.Location = new System.Drawing.Point(65, 20);
            this.Cad_FileName.Name = "Cad_FileName";
            this.Cad_FileName.Size = new System.Drawing.Size(193, 23);
            this.Cad_FileName.TabIndex = 57;
            // 
            // Cad_High
            // 
            this.Cad_High.Location = new System.Drawing.Point(231, 101);
            this.Cad_High.Name = "Cad_High";
            this.Cad_High.Size = new System.Drawing.Size(90, 23);
            this.Cad_High.TabIndex = 64;
            this.Cad_High.Text = "30";
            // 
            // Cad_Width
            // 
            this.Cad_Width.Location = new System.Drawing.Point(65, 98);
            this.Cad_Width.Name = "Cad_Width";
            this.Cad_Width.Size = new System.Drawing.Size(90, 23);
            this.Cad_Width.TabIndex = 65;
            this.Cad_Width.Text = "30";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(7, 23);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(49, 14);
            this.label29.TabIndex = 56;
            this.label29.Text = "文件：";
            // 
            // Btn_Technology
            // 
            this.Btn_Technology.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Technology.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Btn_Technology.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_Technology.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Btn_Technology.Location = new System.Drawing.Point(287, 324);
            this.Btn_Technology.Name = "Btn_Technology";
            this.Btn_Technology.Size = new System.Drawing.Size(85, 27);
            this.Btn_Technology.TabIndex = 49;
            this.Btn_Technology.Text = "工艺参数";
            this.Btn_Technology.UseVisualStyleBackColor = false;
            this.Btn_Technology.Click += new System.EventHandler(this.Btn_Technology_Click);
            // 
            // groupBox_Work
            // 
            this.groupBox_Work.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_Work.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_Work.Controls.Add(this.button3);
            this.groupBox_Work.Controls.Add(this.BTN_SAVE);
            this.groupBox_Work.Controls.Add(this.HomeFlah);
            this.groupBox_Work.Controls.Add(this.LoopRun);
            this.groupBox_Work.Controls.Add(this.Radio_Laser);
            this.groupBox_Work.Controls.Add(this.Radio_Red);
            this.groupBox_Work.Controls.Add(this.button2);
            this.groupBox_Work.Controls.Add(this.button1);
            this.groupBox_Work.Controls.Add(this.Check_Red);
            this.groupBox_Work.Controls.Add(this.Text_PwmDuty);
            this.groupBox_Work.Controls.Add(this.label22);
            this.groupBox_Work.Controls.Add(this.Text_PwmFreq);
            this.groupBox_Work.Controls.Add(this.label21);
            this.groupBox_Work.Controls.Add(this.Text_Power);
            this.groupBox_Work.Controls.Add(this.label20);
            this.groupBox_Work.Controls.Add(this.label19);
            this.groupBox_Work.Controls.Add(this.Text_JumpDelay);
            this.groupBox_Work.Controls.Add(this.Text_MarkSpeed);
            this.groupBox_Work.Controls.Add(this.Text_StartDelay);
            this.groupBox_Work.Controls.Add(this.Text_EmpSpeed);
            this.groupBox_Work.Controls.Add(this.label11);
            this.groupBox_Work.Controls.Add(this.label10);
            this.groupBox_Work.Controls.Add(this.Text_CornerDelay);
            this.groupBox_Work.Controls.Add(this.label14);
            this.groupBox_Work.Controls.Add(this.label12);
            this.groupBox_Work.Controls.Add(this.Text_EndDelay);
            this.groupBox_Work.Controls.Add(this.label13);
            this.groupBox_Work.Location = new System.Drawing.Point(949, 365);
            this.groupBox_Work.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox_Work.Name = "groupBox_Work";
            this.groupBox_Work.Padding = new System.Windows.Forms.Padding(1);
            this.groupBox_Work.Size = new System.Drawing.Size(378, 378);
            this.groupBox_Work.TabIndex = 3;
            this.groupBox_Work.TabStop = false;
            this.groupBox_Work.Text = "加工运行";
            this.groupBox_Work.Paint += new System.Windows.Forms.PaintEventHandler(this.groupBox_Work_Paint);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.Image = global::Zmc_laser.Properties.Resources.整机复位;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(213, 324);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 36);
            this.button3.TabIndex = 45;
            this.button3.Text = "整机复位";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // BTN_SAVE
            // 
            this.BTN_SAVE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_SAVE.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BTN_SAVE.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BTN_SAVE.Location = new System.Drawing.Point(14, 343);
            this.BTN_SAVE.Name = "BTN_SAVE";
            this.BTN_SAVE.Size = new System.Drawing.Size(63, 27);
            this.BTN_SAVE.TabIndex = 44;
            this.BTN_SAVE.Text = "应 用";
            this.BTN_SAVE.UseVisualStyleBackColor = false;
            this.BTN_SAVE.Click += new System.EventHandler(this.BTN_SAVE_Click);
            // 
            // HomeFlah
            // 
            this.HomeFlah.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.HomeFlah.AutoSize = true;
            this.HomeFlah.Checked = true;
            this.HomeFlah.CheckState = System.Windows.Forms.CheckState.Checked;
            this.HomeFlah.Location = new System.Drawing.Point(213, 94);
            this.HomeFlah.Name = "HomeFlah";
            this.HomeFlah.Size = new System.Drawing.Size(96, 18);
            this.HomeFlah.TabIndex = 43;
            this.HomeFlah.Text = "完成回零位";
            this.HomeFlah.UseVisualStyleBackColor = true;
            // 
            // LoopRun
            // 
            this.LoopRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LoopRun.AutoSize = true;
            this.LoopRun.Location = new System.Drawing.Point(213, 60);
            this.LoopRun.Name = "LoopRun";
            this.LoopRun.Size = new System.Drawing.Size(96, 18);
            this.LoopRun.TabIndex = 42;
            this.LoopRun.Text = "连续运行  ";
            this.LoopRun.UseVisualStyleBackColor = true;
            // 
            // Radio_Laser
            // 
            this.Radio_Laser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Radio_Laser.AutoSize = true;
            this.Radio_Laser.Location = new System.Drawing.Point(288, 135);
            this.Radio_Laser.Name = "Radio_Laser";
            this.Radio_Laser.Size = new System.Drawing.Size(53, 18);
            this.Radio_Laser.TabIndex = 41;
            this.Radio_Laser.Text = "激光";
            this.Radio_Laser.UseVisualStyleBackColor = true;
            // 
            // Radio_Red
            // 
            this.Radio_Red.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Radio_Red.AutoSize = true;
            this.Radio_Red.Checked = true;
            this.Radio_Red.Location = new System.Drawing.Point(213, 135);
            this.Radio_Red.Name = "Radio_Red";
            this.Radio_Red.Size = new System.Drawing.Size(53, 18);
            this.Radio_Red.TabIndex = 40;
            this.Radio_Red.TabStop = true;
            this.Radio_Red.Text = "红光";
            this.Radio_Red.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.Image = global::Zmc_laser.Properties.Resources.stop;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(211, 255);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 36);
            this.button2.TabIndex = 39;
            this.button2.Text = "停止(F2)";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Image = global::Zmc_laser.Properties.Resources.激光;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(211, 185);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 36);
            this.button1.TabIndex = 38;
            this.button1.Text = "标刻(F1)";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Check_Red
            // 
            this.Check_Red.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Check_Red.AutoSize = true;
            this.Check_Red.Location = new System.Drawing.Point(213, 26);
            this.Check_Red.Name = "Check_Red";
            this.Check_Red.Size = new System.Drawing.Size(96, 18);
            this.Check_Red.TabIndex = 37;
            this.Check_Red.Text = "边框预览  ";
            this.Check_Red.UseVisualStyleBackColor = true;
            this.Check_Red.CheckedChanged += new System.EventHandler(this.Check_Red_CheckedChanged);
            // 
            // Text_PwmDuty
            // 
            this.Text_PwmDuty.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_PwmDuty.Location = new System.Drawing.Point(103, 166);
            this.Text_PwmDuty.Name = "Text_PwmDuty";
            this.Text_PwmDuty.Size = new System.Drawing.Size(58, 23);
            this.Text_PwmDuty.TabIndex = 36;
            this.Text_PwmDuty.Text = "0.5";
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 172);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 14);
            this.label22.TabIndex = 35;
            this.label22.Text = "PWM占空比";
            // 
            // Text_PwmFreq
            // 
            this.Text_PwmFreq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_PwmFreq.Location = new System.Drawing.Point(103, 131);
            this.Text_PwmFreq.Name = "Text_PwmFreq";
            this.Text_PwmFreq.Size = new System.Drawing.Size(58, 23);
            this.Text_PwmFreq.TabIndex = 34;
            this.Text_PwmFreq.Text = "40000";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(11, 137);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 14);
            this.label21.TabIndex = 33;
            this.label21.Text = "PWM频率(hz)";
            // 
            // Text_Power
            // 
            this.Text_Power.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_Power.Location = new System.Drawing.Point(103, 96);
            this.Text_Power.Name = "Text_Power";
            this.Text_Power.Size = new System.Drawing.Size(58, 23);
            this.Text_Power.TabIndex = 32;
            this.Text_Power.Text = "10";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 102);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 14);
            this.label20.TabIndex = 31;
            this.label20.Text = "功率(%)";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 277);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 14);
            this.label19.TabIndex = 29;
            this.label19.Text = "跳转延时(us)";
            // 
            // Text_JumpDelay
            // 
            this.Text_JumpDelay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_JumpDelay.Location = new System.Drawing.Point(103, 271);
            this.Text_JumpDelay.Name = "Text_JumpDelay";
            this.Text_JumpDelay.Size = new System.Drawing.Size(58, 23);
            this.Text_JumpDelay.TabIndex = 30;
            this.Text_JumpDelay.Text = "1000";
            // 
            // Text_MarkSpeed
            // 
            this.Text_MarkSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_MarkSpeed.Location = new System.Drawing.Point(103, 61);
            this.Text_MarkSpeed.Name = "Text_MarkSpeed";
            this.Text_MarkSpeed.Size = new System.Drawing.Size(58, 23);
            this.Text_MarkSpeed.TabIndex = 28;
            this.Text_MarkSpeed.Text = "1000";
            // 
            // Text_StartDelay
            // 
            this.Text_StartDelay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_StartDelay.Location = new System.Drawing.Point(103, 201);
            this.Text_StartDelay.Name = "Text_StartDelay";
            this.Text_StartDelay.Size = new System.Drawing.Size(58, 23);
            this.Text_StartDelay.TabIndex = 23;
            this.Text_StartDelay.Text = "500";
            // 
            // Text_EmpSpeed
            // 
            this.Text_EmpSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_EmpSpeed.Location = new System.Drawing.Point(103, 26);
            this.Text_EmpSpeed.Name = "Text_EmpSpeed";
            this.Text_EmpSpeed.Size = new System.Drawing.Size(58, 23);
            this.Text_EmpSpeed.TabIndex = 27;
            this.Text_EmpSpeed.Text = "3000";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 242);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 14);
            this.label11.TabIndex = 20;
            this.label11.Text = "关光延时(us)";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 14);
            this.label10.TabIndex = 25;
            this.label10.Text = "空移速度";
            // 
            // Text_CornerDelay
            // 
            this.Text_CornerDelay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_CornerDelay.Location = new System.Drawing.Point(105, 306);
            this.Text_CornerDelay.Name = "Text_CornerDelay";
            this.Text_CornerDelay.Size = new System.Drawing.Size(58, 23);
            this.Text_CornerDelay.TabIndex = 22;
            this.Text_CornerDelay.Text = "0";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 14);
            this.label14.TabIndex = 26;
            this.label14.Text = "加工速度";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 207);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 14);
            this.label12.TabIndex = 19;
            this.label12.Text = "开光延时(us)";
            // 
            // Text_EndDelay
            // 
            this.Text_EndDelay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Text_EndDelay.Location = new System.Drawing.Point(103, 236);
            this.Text_EndDelay.Name = "Text_EndDelay";
            this.Text_EndDelay.Size = new System.Drawing.Size(58, 23);
            this.Text_EndDelay.TabIndex = 24;
            this.Text_EndDelay.Text = "500";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 312);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 14);
            this.label13.TabIndex = 18;
            this.label13.Text = "拐角延时(us)";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Location = new System.Drawing.Point(-4, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(239, 740);
            this.tabControl2.TabIndex = 42;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Transparent;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.File_listView);
            this.tabPage3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(231, 712);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "标刻流程";
            // 
            // File_listView
            // 
            this.File_listView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.File_listView.BackColor = System.Drawing.Color.LightGray;
            this.File_listView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.File_listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.File_listView.ForeColor = System.Drawing.SystemColors.WindowText;
            this.File_listView.FullRowSelect = true;
            this.File_listView.GridLines = true;
            this.File_listView.HideSelection = false;
            this.File_listView.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.File_listView.Location = new System.Drawing.Point(-1, -5);
            this.File_listView.Name = "File_listView";
            this.File_listView.Size = new System.Drawing.Size(235, 720);
            this.File_listView.TabIndex = 1;
            this.File_listView.UseCompatibleStateImageBehavior = false;
            this.File_listView.View = System.Windows.Forms.View.Details;
            this.File_listView.SelectedIndexChanged += new System.EventHandler(this.File_listView_SelectedIndexChanged_1);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "编号";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "类型";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "轨迹数据";
            this.columnHeader3.Width = 400;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.TEXT_ALM);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(231, 712);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "日志记录";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // TEXT_ALM
            // 
            this.TEXT_ALM.BackColor = System.Drawing.SystemColors.InfoText;
            this.TEXT_ALM.ForeColor = System.Drawing.Color.Lime;
            this.TEXT_ALM.Location = new System.Drawing.Point(0, 0);
            this.TEXT_ALM.Name = "TEXT_ALM";
            this.TEXT_ALM.Size = new System.Drawing.Size(235, 712);
            this.TEXT_ALM.TabIndex = 1;
            this.TEXT_ALM.Text = "";
            // 
            // MyPicture
            // 
            this.MyPicture.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MyPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MyPicture.Location = new System.Drawing.Point(236, 9);
            this.MyPicture.Name = "MyPicture";
            this.MyPicture.Size = new System.Drawing.Size(710, 734);
            this.MyPicture.TabIndex = 43;
            this.MyPicture.TabStop = false;
            this.MyPicture.DoubleClick += new System.EventHandler(this.MyPicture_DoubleClick);
            this.MyPicture.MouseEnter += new System.EventHandler(this.MyPicture_MouseEnter);
            this.MyPicture.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MyPicture_MouseMove);
            this.MyPicture.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.MyPicture_MouseWheel);
            // 
            // Lab_ScanStatus
            // 
            this.Lab_ScanStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Lab_ScanStatus.BackColor = System.Drawing.Color.Teal;
            this.Lab_ScanStatus.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Lab_ScanStatus.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Lab_ScanStatus.Location = new System.Drawing.Point(420, 854);
            this.Lab_ScanStatus.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Lab_ScanStatus.Name = "Lab_ScanStatus";
            this.Lab_ScanStatus.Size = new System.Drawing.Size(418, 23);
            this.Lab_ScanStatus.TabIndex = 47;
            this.Lab_ScanStatus.Text = "振镜X: 0  停止 振镜Y: 0 停止";
            this.Lab_ScanStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Lab_AxisStatus
            // 
            this.Lab_AxisStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Lab_AxisStatus.BackColor = System.Drawing.Color.Teal;
            this.Lab_AxisStatus.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Lab_AxisStatus.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Lab_AxisStatus.Location = new System.Drawing.Point(1, 854);
            this.Lab_AxisStatus.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Lab_AxisStatus.Name = "Lab_AxisStatus";
            this.Lab_AxisStatus.Size = new System.Drawing.Size(418, 23);
            this.Lab_AxisStatus.TabIndex = 46;
            this.Lab_AxisStatus.Text = "平台X: 0  停止 平台Y: 0 停止";
            this.Lab_AxisStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.LightSteelBlue;
            this.label69.Font = new System.Drawing.Font("宋体", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(190, 1);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(932, 79);
            this.label69.TabIndex = 47;
            this.label69.Text = "激光振镜控制演示例程";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox6.Image = global::Zmc_laser.Properties.Resources.正运动logo_右对齐_;
            this.pictureBox6.Location = new System.Drawing.Point(1, 1);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(186, 79);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 46;
            this.pictureBox6.TabStop = false;
            // 
            // Btn_SetPara
            // 
            this.Btn_SetPara.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_SetPara.BackColor = System.Drawing.Color.Silver;
            this.Btn_SetPara.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_SetPara.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Btn_SetPara.Image = global::Zmc_laser.Properties.Resources.设置;
            this.Btn_SetPara.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Btn_SetPara.Location = new System.Drawing.Point(1229, 1);
            this.Btn_SetPara.Margin = new System.Windows.Forms.Padding(1);
            this.Btn_SetPara.Name = "Btn_SetPara";
            this.Btn_SetPara.Size = new System.Drawing.Size(102, 79);
            this.Btn_SetPara.TabIndex = 44;
            this.Btn_SetPara.Text = "系统设置";
            this.Btn_SetPara.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_SetPara.UseVisualStyleBackColor = false;
            this.Btn_SetPara.Click += new System.EventHandler(this.Btn_SetPara_Click);
            // 
            // Btn_IoStatus
            // 
            this.Btn_IoStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_IoStatus.BackColor = System.Drawing.Color.Silver;
            this.Btn_IoStatus.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Btn_IoStatus.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Btn_IoStatus.Image = global::Zmc_laser.Properties.Resources.维修;
            this.Btn_IoStatus.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Btn_IoStatus.Location = new System.Drawing.Point(1128, 1);
            this.Btn_IoStatus.Name = "Btn_IoStatus";
            this.Btn_IoStatus.Size = new System.Drawing.Size(102, 79);
            this.Btn_IoStatus.TabIndex = 45;
            this.Btn_IoStatus.Text = "状态监控";
            this.Btn_IoStatus.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.Btn_IoStatus.UseVisualStyleBackColor = false;
            this.Btn_IoStatus.Click += new System.EventHandler(this.Btn_IoStatus_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(839, 854);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(496, 23);
            this.label2.TabIndex = 48;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1328, 876);
            this.Controls.Add(this.Btn_SetPara);
            this.Controls.Add(this.Btn_IoStatus);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.Lab_ScanStatus);
            this.Controls.Add(this.Lab_AxisStatus);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "激光控制演示系统";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.SizeChanged += new System.EventHandler(this.FormMain_SizeChanged);
            this.tabControl1.ResumeLayout(false);
            this.TabPageMark.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.Tab_MarkEdit.ResumeLayout(false);
            this.tabPage_Line.ResumeLayout(false);
            this.tabPage_Line.PerformLayout();
            this.tabPage_Word.ResumeLayout(false);
            this.tabPage_Word.PerformLayout();
            this.tabPage_BarCode.ResumeLayout(false);
            this.tabPage_BarCode.PerformLayout();
            this.tabPage_Cad.ResumeLayout(false);
            this.tabPage_Cad.PerformLayout();
            this.groupBox_Work.ResumeLayout(false);
            this.groupBox_Work.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MyPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TabPageMark;
        private System.Windows.Forms.GroupBox groupBox_Work;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox Check_Red;
        private System.Windows.Forms.TextBox Text_PwmDuty;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox Text_PwmFreq;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox Text_Power;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox Text_JumpDelay;
        private System.Windows.Forms.TextBox Text_MarkSpeed;
        private System.Windows.Forms.TextBox Text_StartDelay;
        private System.Windows.Forms.TextBox Text_EmpSpeed;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Text_CornerDelay;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Text_EndDelay;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_Mid;
        private System.Windows.Forms.Button Btn_Change;
        private System.Windows.Forms.Button Btn_Del;
        private System.Windows.Forms.Button Btn_Add;
        private System.Windows.Forms.TabControl Tab_MarkEdit;
        private System.Windows.Forms.TabPage tabPage_Line;
        private System.Windows.Forms.CheckBox Line_IfSpiral;
        private System.Windows.Forms.CheckBox Line_IfFill;
        private System.Windows.Forms.TextBox Line_End_Angle;
        private System.Windows.Forms.Label labAngle2;
        private System.Windows.Forms.RadioButton Lile_Type5;
        private System.Windows.Forms.RadioButton Lile_Type4;
        private System.Windows.Forms.RadioButton Lile_Type3;
        private System.Windows.Forms.RadioButton Lile_Type2;
        private System.Windows.Forms.RadioButton Lile_Type1;
        private System.Windows.Forms.TextBox Line_Start_Angle;
        private System.Windows.Forms.Label labAngle1;
        private System.Windows.Forms.TextBox Line_End_PosY;
        private System.Windows.Forms.TextBox Line_Start_PosY;
        private System.Windows.Forms.TextBox Line_End_PosX;
        private System.Windows.Forms.TextBox Line_Start_PosX;
        private System.Windows.Forms.Label labPosX;
        private System.Windows.Forms.Label labEndY;
        private System.Windows.Forms.Label labEndX;
        private System.Windows.Forms.Label labPosY;
        private System.Windows.Forms.TabPage tabPage_Word;
        private System.Windows.Forms.CheckBox Word_IfSpiral;
        private System.Windows.Forms.CheckBox Word_IfFill;
        private System.Windows.Forms.TextBox Word_Text;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.CheckBox Word_Delete;
        private System.Windows.Forms.CheckBox Word_Italicas;
        private System.Windows.Forms.CheckBox Word_UnderLine;
        private System.Windows.Forms.CheckBox Word_Thickness;
        private System.Windows.Forms.TextBox Word_TiltI;
        private System.Windows.Forms.TextBox Word_PosY;
        private System.Windows.Forms.TextBox Word_PosX;
        private System.Windows.Forms.TextBox Word_Aangle;
        private System.Windows.Forms.TextBox Word_Width;
        private System.Windows.Forms.TextBox Word_Height;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox Word_Accuracy;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox Word_Font;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage_BarCode;
        private System.Windows.Forms.TextBox BarCode_Text;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox BarCode_IfSpiral;
        private System.Windows.Forms.CheckBox BarCode_IfFill;
        private System.Windows.Forms.TextBox BarCode_Angle;
        private System.Windows.Forms.TextBox BarCode_PosY;
        private System.Windows.Forms.TextBox BarCode_PosX;
        private System.Windows.Forms.TextBox BarCode_Width;
        private System.Windows.Forms.TextBox BarCode_Heigth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox BarCode_Type;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage_Cad;
        private System.Windows.Forms.CheckBox Cad_IfSpira;
        private System.Windows.Forms.CheckBox Cad_IfFill;
        private System.Windows.Forms.TextBox Cad_Angle;
        private System.Windows.Forms.TextBox Cad_PosY;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox Cad_PosX;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button Btn_OpenCadFile;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox Cad_FileName;
        private System.Windows.Forms.TextBox Cad_High;
        private System.Windows.Forms.TextBox Cad_Width;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label Lab_ScanStatus;
        private System.Windows.Forms.Label Lab_AxisStatus;
        private System.Windows.Forms.Button Btn_IoStatus;
        private System.Windows.Forms.Button Btn_SetPara;
        private System.Windows.Forms.Button Btn_Technology;
        private System.Windows.Forms.PictureBox MyPicture;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ListView File_listView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.CheckBox HomeFlah;
        private System.Windows.Forms.CheckBox LoopRun;
        private System.Windows.Forms.RadioButton Radio_Laser;
        private System.Windows.Forms.RadioButton Radio_Red;
        private System.Windows.Forms.Button BTN_SAVE;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.RichTextBox TEXT_ALM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTN_OpenTeach;
        private System.Windows.Forms.Label Lab_FileName;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Button BTN_SaveFile;
        private System.Windows.Forms.Button button3;
    }
}

