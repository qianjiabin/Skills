﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using cszmcaux;
using Zmotion_Laser;
using System.IO;
using System.Runtime.InteropServices;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Zmc_laser;


namespace Zmc_laser
{
    public partial class FormMain : Form
    {
        AutoSizeForm autoSize = new AutoSizeForm();

        public int m_ProductionNum = 0;      //生产数量
        public bool ThreadPauseFlag = false; //暂停标志
        public IntPtr g_handle;         //链接返回的句柄，可以作为卡号

        public bool ThreadFlag = false;
        Thread ThreadDrawId;            //线程ID

        public int CodeType = 0;
        StringBuilder rstCodeType = new StringBuilder(64);
        StringBuilder rstInfo = new StringBuilder(64);

        public int m_StartStatus = 0;         //启动状态
        public float m_MarkTime = 0;         //标刻时间

        public double m_dUnitsPerMm = 1.0;
        public double m_PicScale = 1.0;
        public double m_PicOffsetX = 0.0;
        public double m_PicOffsetY = 0.0;

        public FormMain()
        {
            InitializeComponent();

            Control.CheckForIllegalCrossThreadCalls = false;
        }

        public static Color m_PenColor = Color.Black;                //默认颜色
        public static Pen m_Pen = new Pen(m_PenColor, 1);           //画笔颜色,宽度
        public static Bitmap m_BitImage;                            //定义一个用于保存即时图像的位图
        public Graphics m_Graphics;
        public double PicWidth, PicHeight;

        //加载界面读取配置文件
        private void FormMain_Load(object sender, EventArgs e)
        {
            autoSize.controllInitializeSize(this);
            //this.WindowState = FormWindowState.Maximized;
            TEXT_ALM.Text = "";
            Read_MarkCfg();         //读取INI配置文件

            CtrText_From_Val();

            //打标卡链接
            int iret = 0;
            if ((int)ZmcCardPara.G_CardHandle == 0)
            {
                iret = zmcaux.ZAux_OpenEth(ZmcCardPara.G_MarkCardIpAdrr, out ZmcCardPara.G_CardHandle);
            }

            if (ZmcCardPara.G_CardHandle != (IntPtr)0)
            {

                this.Text = "激光控制器已连接";
                Add_AlmInfo("激光控制器连接成功.",0);
                Axis_Init();
                ScanAxis_Init();
                Laser_Init();

                ReadTeachFile();                        //读取示教文件
    

            }
            else
            {
                this.Text = "激光控制器未连接";
                MessageBox.Show("激光控制器连接失败");

                Add_AlmInfo("激光控制器连接失败." + " ErrorCode:" + iret.ToString(),1);
            }


        }

        private void FormMain_SizeChanged(object sender, EventArgs e)
        {
            autoSize.controlAutoSize(this);
        }

        //变量到控件显示值
        private void CtrText_From_Val()
        {
            Text_EmpSpeed.Text = ZmcCardPara.m_dEmpSpeed.ToString();
            Text_MarkSpeed.Text = ZmcCardPara.m_dMarkSpeed.ToString();
            Text_Power.Text = ZmcCardPara.m_nPower.ToString();
            Text_PwmFreq.Text = ZmcCardPara.m_nPwmFreq.ToString();
            Text_PwmDuty.Text = ZmcCardPara.m_fPwmDuty.ToString();
            Text_StartDelay.Text = ZmcCardPara.m_nStartDelay.ToString();
            Text_EndDelay.Text = ZmcCardPara.m_nLastDelay.ToString();
            Text_JumpDelay.Text = ZmcCardPara.m_nJumpDelay.ToString();
            Text_CornerDelay.Text = ZmcCardPara.m_nCorDelay.ToString();

     
        }

        //控件显示值刷新到变量
        private void CtrText_To_Val()
        {
            ZmcCardPara.m_dEmpSpeed = Convert.ToSingle(Text_EmpSpeed.Text);
            ZmcCardPara.m_dMarkSpeed = Convert.ToSingle(Text_MarkSpeed.Text);
            ZmcCardPara.m_nPower = Convert.ToInt32(Text_Power.Text);
            ZmcCardPara.m_nPwmFreq = Convert.ToInt32(Text_PwmFreq.Text);
            ZmcCardPara.m_fPwmDuty = Convert.ToSingle(Text_PwmDuty.Text);
            ZmcCardPara.m_nStartDelay = Convert.ToSingle(Text_StartDelay.Text);
            ZmcCardPara.m_nLastDelay = Convert.ToSingle(Text_EndDelay.Text);
            ZmcCardPara.m_nJumpDelay = Convert.ToSingle(Text_JumpDelay.Text);
            ZmcCardPara.m_nCorDelay = Convert.ToSingle(Text_CornerDelay.Text);
        }

        //窗口关闭保存配置文件参
        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            //配置文件读取
            string nFilePath = System.Environment.CurrentDirectory + "\\ini";
            if (!System.IO.Directory.Exists(nFilePath))
            {
                System.IO.Directory.CreateDirectory(nFilePath);//不存在就创建目录 
            }
            //文件名带目录创建
            string nFileName = nFilePath + "\\";
            nFileName += "ZmcLaserSet.ini";
            if (File.Exists(nFileName) == false)
            {
                //创建文件
                FileStream TestFile = new FileStream(nFileName, FileMode.OpenOrCreate);
                StreamWriter SwFile = new StreamWriter(TestFile);
                SwFile.Close();
            }
            Write_MarkCfg(nFileName);

        }

        //初始化轴参数
        private void Axis_Init()
        {
            ZmcCardPara.Set_AxisPara();
        }

        //振镜轴参数初始化
        private void ScanAxis_Init()
        {

            ZmcCardPara.Sel_ScanAxis();

            int nScanNum = 0;
            int ScanExChange = 0;
            int nXDirect = 0;
            int nYDirect = 0;
            double dUnits = 1000.0;
            double dScaleRatio = 0;

            if (!File.Exists(ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile))
            {
                Add_AlmInfo("振镜矫正失败，矫正文件不存在." + ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile,1);
                return;
            }

            int rtn = ZmcLaser.ZScan_CorrectFile2(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile, 4000);
            if (ZmcCardPara.CheckError(rtn, "ZScan_CorrectFile2 Error")) return;

            //int32 __stdcall ZScan_ReadFile2Para(char* pFilePath, int& nScanNum, int& nScanExChange, int& nXDirect, int& nYDirect, double& dUnits, double& dScaleRatio);
            rtn = ZmcLaser.ZScan_ReadFile2Para(ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile, ref nScanNum, ref ScanExChange, ref nXDirect, ref nYDirect, ref dUnits, ref dScaleRatio);
            if (ZmcCardPara.CheckError(rtn, "ZScan_ReadFile2Para Error")) return;

            //int rtn = ZmcLaser.ZScan_CorrectFileRead(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile, ref nScanNum, ref ScanExChange, ref nXDirect, ref nYDirect, ref dUnits, ref dScaleRatio, 4000);
            //if (ZmcCardPara.CheckError(rtn, "ZScan_CorrectFile Error")) return;
            if(ZmcCardPara.m_ScanId != nScanNum)
            {
                Add_AlmInfo("振镜矫正文件振镜组不一致，检查矫正文件" + ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile,2);
                return;
            }

            rtn = zmcaux.ZAux_Direct_SetAtype(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, 21);
            rtn = zmcaux.ZAux_Direct_SetUnits(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, (float)dUnits);

            rtn = zmcaux.ZAux_Direct_SetAtype(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY, 21);
            rtn = zmcaux.ZAux_Direct_SetUnits(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY, (float)dUnits);

            ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].units = (float)dUnits;

            Add_AlmInfo("振镜矫正完成.",0 );
        }

        //激光器参数初始化
        private void Laser_Init()
        {
            int Iret = 0;
            if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.FIBER_408)									//408 FIBER转换板参数设置
            {
                Iret = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, 0);
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.YLR_408)
            {
                Iret = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, -1);
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.YAG_408)									//408 YAG转换板参数设置
            {
                Iret = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, 1);
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.FIBER_504)									//504
            {
                Iret = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, -1);
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.FIBER_408V2)									//504
            {
                Iret = zmcaux.ZAux_SetLaserSet(ZmcCardPara.G_CardHandle, 1, 1);
            }
        }

        //状态监控界面
        private void Btn_IoStatus_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            FormStatus SysStatusForm = new FormStatus();
            SysStatusForm.ShowDialog();
        }

        //参数设置界面
        private void Btn_SetPara_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            FormSysPara SysParaForm = new FormSysPara();
            SysParaForm.ShowDialog();
        }

        //工艺参数界面
        private void Btn_Technology_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            FormTechnology LaserTechnologyForm = new FormTechnology();
            LaserTechnologyForm.Owner = this;
            LaserTechnologyForm.Show();
        }

        //生成Z3P文件
        public void Make3File()
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            CtrText_To_Val();


            uint rtn  = ZmcLaser.ZmotionLaser_CloseFile3();
            if (CheckError(rtn, "ZmotionLaser_CloseFile3")) return;

            //打开打标库3次文件功能
             rtn = ZmcLaser.ZmotionLaser_OpenFile3(ZmcCardPara.G_CardHandle);
            if (CheckError(rtn, "ZmotionLaser_OpenFile3")) return;

            rtn = ZmcLaser.ZmotionLaser_SetPowerMode(0);
            if (CheckError(rtn, "ZmotionLaser_SetPowerMode")) return;


            rtn = ZmcLaser.ZmotionLaser_SetOutputLimits(55);								//设置输出口最大编号限制
            if (CheckError(rtn, "ZmotionLaser_OpenFile3")) return;

            rtn = ZmcLaser.ZmotionLaser_SetScanAxis(ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY);							    	//设置振镜轴号
            if (CheckError(rtn, "ZmotionLaser_SetScanAxis")) return;

            //开关光IO口，及开关光动作设置
            rtn = ZmcLaser.ZmotionLaser_SetOutput(ZmcCardPara.m_nLaserIO, ZmcCardPara.m_nEnableIO, ZmcCardPara.m_nRedIO, 0);		//设置开光光控制IO
            if (CheckError(rtn, "ZmotionLaser_SetOutput")) return;

            rtn = ZmcLaser.ZmotionLaser_SetOtherOutDeal(49, 46);     //设置急停以及功率锁存IO口
            if (CheckError(rtn, "ZmotionLaser_SetOtherOutDeal")) return;

            rtn = ZmcLaser.ZmotionLaser_SetMoveInstruct(0);                               //设置运动函数名称类型
            if (CheckError(rtn, "ZmotionLaser_SetMoveInstruct")) return;

  
            rtn = ZmcLaser.ZmotionLaser_SetLightInstruct(1);             //开关光动作选择 0-SetOutput接口IO控制  1-SetLightString自定义
            if (CheckError(rtn, "ZmotionLaser_SetLightInstruct")) return;

            //自定义开关光动作。设置开光前加入字符,与关光字符串
            string OpenStr, CloseStr;
            if(Radio_Red.Checked)
            {
                OpenStr = "MOVE_OP(" + ZmcCardPara.m_nRedIO + ",ON)\n";                          //开光动作字符串
                CloseStr = "MOVE_OP(" + ZmcCardPara.m_nRedIO + ",OFF)\n";                        //关光动作字符串
            }
            else
            {
                OpenStr = "MOVE_OP(" + ZmcCardPara.m_nLaserIO + ",ON)\n";                          //开光动作字符串
                CloseStr = "MOVE_OP(" + ZmcCardPara.m_nLaserIO + ",OFF)\n";                        //关光动作字符串
            }
            rtn = ZmcLaser.ZmotionLaser_SetLightString(OpenStr, CloseStr);                     //设定开关光动作字符串
            if (CheckError(rtn, "ZmotionLaser_SetLightInstruct")) return;
     

            //激光器功率控制相关设置
            if (ZmcCardPara.m_LinkAgePara.bEnable)
            {
                rtn = ZmcLaser.ZmotionLaser_SetPowerEnable(true);                            //开启动态修改功率
                if (CheckError(rtn, "ZmotionLaser_SetPowerEnable")) return;
            }
            else
            {
                rtn = ZmcLaser.ZmotionLaser_SetPowerEnable(false);                           //关闭动态修改功率
                if (CheckError(rtn, "ZmotionLaser_SetPowerEnable")) return ;

                int vllll = (int)(ZmcCardPara.m_nPower * ZmcCardPara.m_nAoutVal / 100.0);
                string Tempstr;
                Tempstr = "MOVE_AOUT(3," + vllll.ToString()  + ")\nMOVE_OP(46,ON)\nMOVE_OP(46,OFF)\n";
                rtn = ZmcLaser.ZmotionLaser_AddString(Tempstr, 1);
                if (CheckError(rtn, "ZmotionLaser_AddString")) return;
            }

            rtn = ZmcLaser.ZmotionLaser_SetPwmNum(ZmcCardPara.m_nPwmIo);
            if (CheckError(rtn, "ZmotionLaser_SetPowerMode")) return;

            rtn = ZmcLaser.ZmotionLaser_AoutInit(ZmcCardPara.m_nAout, ZmcCardPara.m_nAoutVal);				//设置模拟量功率设置
            if (CheckError(rtn, "ZmotionLaser_AoutInit")) return;

            rtn = ZmcLaser.ZmotionLaser_SetValidPowerLimit(ZmcCardPara.m_nMinPower, ZmcCardPara.m_nMaxPower);
            if (CheckError(rtn, "ZmotionLaser_SetValidPowerLimit")) return;



            //CAD导图图形优化
            ZmcLaser.Struct_IntVect_AutoDeal m_CadAutoDeal;
            m_CadAutoDeal.bMerge = true;				//合并相连线
            m_CadAutoDeal.bMergeAccuracy = 0.05;		    //相连线曲线精度
            rtn = ZmcLaser.ZmotionLaser_SetIntVectAuto(m_CadAutoDeal);
            if (CheckError(rtn, "ZmotionLaser_SetIntVectAuto")) return;
        
            //设置加工工艺参数
            rtn = ZmcLaser.ZmotionLaser_SetVectPar(ZmcCardPara.m_nPower, ZmcCardPara.m_nPwmFreq, ZmcCardPara.m_dMarkSpeed, ZmcCardPara.m_dEmpSpeed, ZmcCardPara.m_nStartDelay, ZmcCardPara.m_nLastDelay, ZmcCardPara.m_nJumpDelay
                , 10, ZmcCardPara.m_nCorDelay, ZmcCardPara.m_nLastDelay, 1);
            if (CheckError(rtn, "ZmotionLaser_SetVectPar")) return;


            //设置联动参数
            if (ZmcCardPara.m_LinkAgePara.bEnable)
            {
                rtn = ZmcLaser.ZmotionLaser_SetPlatParam(ZmcCardPara.m_LinkAgePara.nMotorAxisX, ZmcCardPara.m_LinkAgePara.nMotorAxisY, ZmcCardPara.m_LinkAgePara.fMotorMaxSp
                    , ZmcCardPara.m_LinkAgePara.fMotorAcc, ZmcCardPara.m_LinkAgePara.fMotorDec, ZmcCardPara.m_LinkAgePara.fXDelayTime / 1000, ZmcCardPara.m_LinkAgePara.fYDelayTime / 1000);
                if (CheckError(rtn, "ZmotionLaser_SetPlatParam")) return ;

                rtn = ZmcLaser.ZmotionLaser_SetLinkagePar(1, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].units
                    , -1 * ZmcCardPara.m_LinkAgePara.fScanXLimit / 2, ZmcCardPara.m_LinkAgePara.fScanXLimit / 2, -1 * ZmcCardPara.m_LinkAgePara.fScanYLimit / 2, ZmcCardPara.m_LinkAgePara.fScanYLimit / 2
                    , -1 * ZmcCardPara.m_LinkAgePara.fMotorXLimit / 2, ZmcCardPara.m_LinkAgePara.fMotorXLimit / 2, -1 * ZmcCardPara.m_LinkAgePara.fMotorYLimit / 2, ZmcCardPara.m_LinkAgePara.fMotorYLimit / 2);
                if (CheckError(rtn, "ZmotionLaser_SetLinkagePar")) return ;
            }

            //加工图形
            for (int i = 0; i < ZmcCardPara.m_TotalLine; i++)
            {

                //是否螺旋线异化
                if (ZmcCardPara.m_GraphData[i].If_Spiral)
                {
                    rtn = ZmcLaser.ZmotionLaser_SpiralStart(ZmcCardPara.m_SpiralRadio, ZmcCardPara.m_SpiralDist, ZmcCardPara.m_SpiralAccuracy, true);
                    if (CheckError(rtn, "ZmotionLaser_SpiralStart")) return;
                }

                //是否填充
                if (ZmcCardPara.m_GraphData[i].If_Fill)
                {
                    ZmcCardPara.m_FillPara.m_bEnable = true;
                    rtn = ZmcLaser.ZmotionLaser_SetFillObject(ZmcCardPara.m_FillPara, 1);
                    if (CheckError(rtn, "ZmotionLaser_SetFillObject")) return;

                    //开始填充
                    rtn = ZmcLaser.ZmotionLaser_FillStart();
                    if (CheckError(rtn, "ZmotionLaser_FillStart")) return;
                }


                switch (ZmcCardPara.m_GraphData[i].iType)
                {
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:
                        rtn = ZmcLaser.ZmotionLaser_Point(1, ZmcCardPara.m_GraphData[i].fStartx, ZmcCardPara.m_GraphData[i].fStarty);         //点
                        if (CheckError(rtn, "ZmotionLaser_Point")) return;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:
                        rtn = ZmcLaser.ZmotionLaser_Line(1, ZmcCardPara.m_GraphData[i].fStartx, ZmcCardPara.m_GraphData[i].fStarty, ZmcCardPara.m_GraphData[i].fEndx, ZmcCardPara.m_GraphData[i].fEndy);         //直线
                        if (CheckError(rtn, "ZmotionLaser_Line")) return;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:
                        rtn = ZmcLaser.ZmotionLaser_Arc(1, ZmcCardPara.m_GraphData[i].fStartx,ZmcCardPara. m_GraphData[i].fStarty, ZmcCardPara.m_GraphData[i].fEndx, ZmcCardPara.m_GraphData[i].fAngle1, ZmcCardPara.m_GraphData[i].fAngle2, ZmcCardPara.m_GraphData[i].fEndy);         //圆弧
                        if (CheckError(rtn, "ZmotionLaser_Arc")) return;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:
                        rtn = ZmcLaser.ZmotionLaser_Circle(1, ZmcCardPara.m_GraphData[i].fStartx, ZmcCardPara.m_GraphData[i].fStarty, ZmcCardPara.m_GraphData[i].fEndx,ZmcCardPara.m_GraphData[i].fEndy);         //圆
                        if (CheckError(rtn, "ZmotionLaser_Circle")) return;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:
                        double[] Tempx = new double[5];
                        double[] Tempy = new double[5];
                        int[] TempState = new int[5];

                        Tempx[0] = ZmcCardPara.m_GraphData[i].fStartx;
                        Tempy[0] = ZmcCardPara.m_GraphData[i].fStarty;
                        TempState[0] = 0;

                        Tempx[1] = ZmcCardPara.m_GraphData[i].fStartx + ZmcCardPara.m_GraphData[i].fEndx;
                        Tempy[1] = ZmcCardPara.m_GraphData[i].fStarty;
                        TempState[1] = 0;

                        Tempx[2] = ZmcCardPara.m_GraphData[i].fStartx + ZmcCardPara.m_GraphData[i].fEndx;
                        Tempy[2] = ZmcCardPara.m_GraphData[i].fStarty - ZmcCardPara.m_GraphData[i].fEndy;
                        TempState[2] = 0;

                        Tempx[3] = ZmcCardPara.m_GraphData[i].fStartx;
                        Tempy[3] = ZmcCardPara.m_GraphData[i].fStarty - ZmcCardPara.m_GraphData[i].fEndy;
                        TempState[3] = 0;

                        Tempx[4] = ZmcCardPara.m_GraphData[i].fStartx;
                        Tempy[4] = ZmcCardPara.m_GraphData[i].fStarty;
                        TempState[4] = 0;

                        rtn = ZmcLaser.ZmotionLaser_Polyline(1, Tempx, Tempy, TempState, 4);         //圆
                        if (CheckError(rtn, "ZmotionLaser_Polyline")) return;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:     //文本
                        bool bThickness, bItalics, bUnderline, bDelete;
                        //设置文本字体参数
                        bThickness = ((ZmcCardPara.m_GraphData[i].nBitMode & 0x1) == 0x1) ? true : false;
                        bItalics = ((ZmcCardPara.m_GraphData[i].nBitMode & 0x2) == 0x2) ? true : false;
                        bUnderline = ((ZmcCardPara.m_GraphData[i].nBitMode & 0x4) == 0x4) ? true : false;
                        bDelete = ((ZmcCardPara.m_GraphData[i].nBitMode & 0x8) == 0x8) ? true : false;
                        rtn = ZmcLaser.ZmotionLaser_SetTextStyle(ZmcCardPara.m_GraphData[i].GraphStr, bThickness, bItalics, bUnderline, bDelete, ZmcCardPara.m_GraphData[i].fEndy, ZmcCardPara.m_GraphData[i].fEndx, ZmcCardPara.m_GraphData[i].fAngle1, ZmcCardPara.m_GraphData[i].fAngle2);
                        if (CheckError(rtn, "ZmotionLaser_SetTextStyle")) return;

                        //加工文本字符
                        rtn = ZmcLaser.ZmotionLaser_Text(1, ZmcCardPara.m_GraphData[i].GraphStr1, ZmcCardPara.m_GraphData[i].fStartx,ZmcCardPara.m_GraphData[i].fStarty, ZmcCardPara.m_GraphData[i].fAccuracy);
                        if (CheckError(rtn, "ZmotionLaser_Text")) return ;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:  //条码

                        rtn = ZmcLaser.ZmotionLaser_BarCode(1, ZmcCardPara.m_GraphData[i].GraphStr1, ZmcCardPara.m_GraphData[i].GraphStr, ZmcCardPara.m_GraphData[i].fStartx, ZmcCardPara.m_GraphData[i].fStarty, ZmcCardPara.m_GraphData[i].fEndx, ZmcCardPara.m_GraphData[i].fEndy, ZmcCardPara.m_GraphData[i].fAngle1);
			           if(CheckError(rtn,"ZmotionLaser_BarCode")) return;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:   //CAD图形
                        rtn = ZmcLaser.ZmotionLaser_FileVector(ZmcCardPara.m_GraphData[i].GraphStr, ZmcCardPara.m_GraphData[i].fStartx, ZmcCardPara.m_GraphData[i].fStarty, ZmcCardPara.m_GraphData[i].fEndx, ZmcCardPara.m_GraphData[i].fEndy, ZmcCardPara.m_GraphData[i].fAngle1);
			            if(CheckError(rtn,"ZmotionLaser_FileVector")) return;
                        break;
                    default:
                        break;

                }

                //结束填充
                if (ZmcCardPara.m_GraphData[i].If_Fill)
                {
                    rtn = ZmcLaser.ZmotionLaser_FillEnd();
                    if (CheckError(rtn, "ZmotionLaser_FillEnd")) return;
                }

                //关闭异化
                if (ZmcCardPara.m_GraphData[i].If_Spiral)
                {
                    rtn =ZmcLaser.ZmotionLaser_SpiralEnd();
                    if (CheckError(rtn, "ZmotionLaser_SpiralEnd")) return;
                }

            }

            //添加计时
            rtn = ZmcLaser.ZmotionLaser_AddString("TIME_TICKUS = 0", 1);            //开始计时
            if (CheckError(rtn, "ZmotionLaser_AddString")) return;

            //计时
            rtn = ZmcLaser.ZmotionLaser_AddString("WAIT IDLE\nVR(0) = TIME_TICKUS",2);         //结束计时
            if (CheckError(rtn, "ZmotionLaser_AddString")) return;



            //回零位字符串添加
            if (HomeFlah.Checked)
            {
                string BasStr , TempStr;
                BasStr = "WAIT IDLE\nBASE(" + ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX.ToString() +  "," + ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY.ToString() + ")\nMOVESCANABS(0,0)\n";
                TempStr = "WAIT IDLE\nMOVEABS(0) Axis(" + ZmcCardPara.m_LinkAgePara.nMotorAxisX.ToString() +  ")\nMOVEABS(0) Axis(" + ZmcCardPara.m_LinkAgePara.nMotorAxisY.ToString() + ")\n";
                BasStr += TempStr;
                TempStr = "WAIT UNTIL IDLE(" + ZmcCardPara.m_LinkAgePara.nMotorAxisX.ToString() + ") AND IDLE(" + ZmcCardPara.m_LinkAgePara.nMotorAxisY.ToString() + ")\n";
                BasStr += TempStr;

                rtn = ZmcLaser.ZmotionLaser_AddString(BasStr, 2);
                if (CheckError(rtn, "ZmotionLaser_AddString")) return;
            }

            //显示轨迹
            ZmcCardPara.ZCad_ArrayLen = ZmcLaser.ZmotionLaser_GetCurVectArrayLen();                                 //获取轨迹长度
            if (ZmcCardPara.ZCad_ArrayLen > 0)
            {
                ZmcCardPara.ZCad_ArrayInfo = new ZmcLaser.Struct_ZCad_Array[ZmcCardPara.ZCad_ArrayLen];
                rtn = ZmcLaser.ZmotionLaser_SetArrayForGraph(ref ZmcCardPara.ZCad_ArrayInfo[0], (int)ZmcCardPara.ZCad_ArrayLen);    //获取图形数据
                //绘图
                Show_Picture();

            }


            //生成加工三次文件
            if (ZmcCardPara.m_LinkAgePara.bEnable)
            {
                if (ZmcCardPara.m_LinkAgePara.bDivision_Enable)
                {
                    rtn = ZmcLaser.ZmotionLaser_CreateDLinkFile3(".//ZscanLaser.z3p", true);
                    if (CheckError(rtn, "ZmotionLaser_CreateLinkFile3")) return;
                }
                else
                {
                    rtn = ZmcLaser.ZmotionLaser_CreateLinkFile3(".//ZscanLaser.z3p", true);
                    if (CheckError(rtn, "ZmotionLaser_CreateLinkFile3")) return;
                }
            }
            else
            {
                rtn = ZmcLaser.ZmotionLaser_CreateFile3(".//ZscanLaser.z3p");
                if (CheckError(rtn, "ZmotionLaser_CreateFile3")) return;
            }
        
            //rtn = ZmcLaser.ZmotionLaser_CloseFile3();
            //if (CheckError(rtn, "ZmotionLaser_CloseFile3")) return;

        }

        //保存示教文件
        private void BTN_SaveFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog SaveFileDialog1 = new SaveFileDialog();
            SaveFileDialog1.InitialDirectory = ZmcCardPara.TeachFilePath;
            SaveFileDialog1.Filter = "TXT File(*.txt)|*.txt";
            SaveFileDialog1.FileName = "TeachFile";

            if (SaveFileDialog1.ShowDialog() == DialogResult.OK)            //打开配置文件
            {
                string localFilePath = SaveFileDialog1.FileName.ToString();
                ZmcCardPara.TeachFilePath = localFilePath.Substring(0, localFilePath.LastIndexOf("\\"));
                ZmcCardPara.TeachName = localFilePath.Substring(localFilePath.LastIndexOf("\\") + 1);
                Lab_FileName.Text = ZmcCardPara.TeachName;

                SaveTeachFile();
            }
        }

        //打开示教文件
        private void BTN_OpenTeach_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = ZmcCardPara.TeachFilePath;
            openFileDialog1.Filter = "TXT File(*.txt)|*.txt";
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.FilterIndex = 1;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)            //打开配置文件
            {
                ZmcCardPara.TeachFilePath = openFileDialog1.FileName.ToString().Substring(0, openFileDialog1.FileName.ToString().LastIndexOf("\\"));
                ZmcCardPara.TeachName = openFileDialog1.SafeFileName;
                Lab_FileName.Text = ZmcCardPara.TeachName;
            }
            else
            {

            }
            ReadTeachFile();
        }

        //保存示教文件
        public void SaveTeachFile()
        {
             try
            {
                string FileName = ZmcCardPara.TeachFilePath +"\\"+ ZmcCardPara.TeachName; 

                //文本清空
                System.IO.File.WriteAllText(FileName, string.Empty);
         
                //定义文件信息对象
                FileInfo finfo = new FileInfo(FileName);
                if (!finfo.Exists)
                {
                    FileStream fs;
                    fs = File.Create(FileName);
                    fs.Close();
                    finfo = new FileInfo(FileName);
                }
                 
                //创建只写文件流
                using (FileStream fs = finfo.OpenWrite())
                {
                    //根据上面创建的文件流创建写数据流
                    StreamWriter streamWriter = new StreamWriter(fs);
 
                    //设置写数据流的起始位置为文件流的末尾
                    //streamWriter.BaseStream.Seek(0, SeekOrigin.End);
 
                    //写入内容
                    for (int i = 0; i < ZmcCardPara.m_TotalLine; i++)
                    {
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].iType.ToString() +" ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fStartx.ToString() +" ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fStarty.ToString() + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fEndx.ToString() + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fEndy.ToString() + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fAngle1.ToString() + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fAngle2.ToString() + " ");
                        if(ZmcCardPara.m_GraphData[i].If_Fill)
                        {
                            streamWriter.Write("1 ");
                        }
                        else
                        {
                            streamWriter.Write("0 ");
                        }
                        if (ZmcCardPara.m_GraphData[i].If_Spiral)
                        {
                            streamWriter.Write("1 ");
                        }
                        else
                        {
                            streamWriter.Write("0 ");
                        }
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].GraphStr + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].GraphStr1 + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].nBitMode.ToString() + " ");
                        streamWriter.Write(ZmcCardPara.m_GraphData[i].fAccuracy.ToString() + "\n");
                    }
                   
 
                    //清空缓冲区内容，并把缓冲区内容写入基础流
                    streamWriter.Flush();
 
                    //关闭写数据流
                    streamWriter.Close();
                }

                Add_AlmInfo("保存激光加工文件:" + FileName,0);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
  
        }

        //读取示教文件并解析
        public void ReadTeachFile()
        {
            try
            {
                     Lab_FileName.Text = ZmcCardPara.TeachName;
                    string FileName = ZmcCardPara.TeachFilePath +"\\"+ ZmcCardPara.TeachName;
                    if (File.Exists(FileName))
                    {
                        using (StreamReader sr = new StreamReader(FileName))
                        {
                            ZmcCardPara.Struct_Graph TempLine = new ZmcCardPara.Struct_Graph();
                            ZmcCardPara.m_TotalLine =0;                 //清空
                            ZmcCardPara.m_CurEditLine = 0;

                            string[] sArray;
                            string lineStr;
                            // 从文件读取并显示行，直到文件的末尾 
                            while ((lineStr = sr.ReadLine()) != null)
                            {
                                //解析行到数据
                                sArray = lineStr.Split(' ');
                                if (sArray.Length == 13)
                                {
                                    TempLine.iType = Convert.ToInt32(sArray[0]);
                                    TempLine.fStartx = Convert.ToSingle(sArray[1]);
                                    TempLine.fStarty = Convert.ToSingle(sArray[2]);
                                    TempLine.fEndx = Convert.ToSingle(sArray[3]);
                                    TempLine.fEndy = Convert.ToSingle(sArray[4]);
                                    TempLine.fAngle1 = Convert.ToSingle(sArray[5]);
                                    TempLine.fAngle2 = Convert.ToSingle(sArray[6]);
                                    TempLine.If_Fill = (Convert.ToInt32(sArray[7]) == 1) ? true : false;
                                    TempLine.If_Spiral = (Convert.ToInt32(sArray[8]) == 1) ? true : false;
                                    TempLine.GraphStr = sArray[9];
                                    TempLine.GraphStr1 = sArray[10];
                                    TempLine.nBitMode = Convert.ToInt32(sArray[11]);
                                    TempLine.fAccuracy = Convert.ToSingle(sArray[12]);

                                    ZmcCardPara.m_GraphData.Insert(ZmcCardPara.m_TotalLine, TempLine);
                                    ZmcCardPara.m_TotalLine++;
                                    ZmcCardPara.m_CurEditLine = ZmcCardPara.m_TotalLine - 1;

                                }
                                else
                                {
                                    //数据异常
                                }
                            }

                            ScanDrawList();             //刷新列表显示
                            Make3File();                //生成3次文件
                            Add_AlmInfo("加载激光加工文件:" + FileName + "成功.",0);
                            }
                    }
                    else
                    {
                        Add_AlmInfo("文件:" + FileName + "不存在.",2);
                        MessageBox.Show("文件:" + FileName + "不存在!");
                    }
                

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        //错误返回
        bool CheckError(uint ErrorCode, string CmdString)
        {
            if (0 != ErrorCode)
            {
                Add_AlmInfo(CmdString + "ErrorCode:" + ErrorCode.ToString(), 2);
                MessageBox.Show(CmdString + "ErrorCode:" + ErrorCode);
                return true;
            }
            return false;
        }

#region  轨迹图形编辑处理

        //添加一行
        private void Btn_Add_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            ZmcCardPara.Struct_Graph TempLine = new ZmcCardPara.Struct_Graph();

            TempLine.iType = ZmcCardPara.m_CurEditAype;
            switch (ZmcCardPara.m_CurEditAype)                  //添加类型
            {
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:    //点
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:     //线
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:      //圆弧
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:   //圆
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:     //矩形
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:     //文本
                        TempLine.fStartx = Convert.ToSingle(Word_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Word_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Word_Width.Text);
                        TempLine.fEndy = Convert.ToSingle(Word_Height.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Word_Aangle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Word_TiltI.Text);
                        TempLine.fAccuracy = Convert.ToSingle(Word_Accuracy.Text);
                        TempLine.GraphStr = Word_Font.Text;
                        TempLine.GraphStr1 =Word_Text.Text;
                        TempLine.If_Fill = Word_IfFill.Checked;
                        TempLine.If_Spiral = Word_IfSpiral.Checked;
                        int ibit = 0;
                        if(Word_Thickness.Checked)
                        {
                            ibit |= (1<<0);
                        }
                        else
                        {
                            ibit &=~(1<<0);
                        }

                         if(Word_UnderLine.Checked)
                        {
                            ibit |= (1<<1);
                        }
                        else
                        {
                            ibit &=~(1<<1);
                        }

                        if(Word_Italicas.Checked)
                        {
                            ibit |= (1<<2);
                        }
                        else
                        {
                            ibit &=~(1<<2);
                        }

                        if(Word_Delete.Checked)
                        {
                            ibit |= (1<<3);
                        }
                        else
                        {
                            ibit &=~(1<<3);
                        }
                        TempLine.nBitMode = ibit;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:  //条码
                        TempLine.fStartx = Convert.ToSingle(BarCode_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(BarCode_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(BarCode_Width.Text);
                        TempLine.fEndy = Convert.ToSingle(BarCode_Heigth.Text);
                        TempLine.fAngle1 = Convert.ToSingle(BarCode_Angle.Text);
                        TempLine.GraphStr = BarCode_Type.Text;
                        TempLine.GraphStr1 = BarCode_Text.Text;
                        TempLine.If_Fill = BarCode_IfFill.Checked;
                        TempLine.If_Spiral = BarCode_IfSpiral.Checked;
                    break;
                 case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:   //CAD图形
                        TempLine.fStartx = Convert.ToSingle(Cad_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Cad_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Cad_Width.Text);
                        TempLine.fEndy = Convert.ToSingle(Cad_High.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Cad_Angle.Text);
                        TempLine.GraphStr = Cad_FileName.Text;
                        TempLine.If_Fill = Cad_IfFill.Checked;
                        TempLine.If_Spiral = Cad_IfSpira.Checked;
                    break;
                default:
                    break;

            }

            ZmcCardPara.m_GraphData.Insert(ZmcCardPara.m_CurEditLine, TempLine);
            ZmcCardPara.m_TotalLine++;
            //ZmcCardPara.m_CurEditLine = ZmcCardPara.m_TotalLine - 1;

            ScanDrawList();             //刷新列表显示
            Make3File();                //生成3次文件
        }

        //删除一行
        private void Btn_Del_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            if (ZmcCardPara.m_CurEditLine < 0 || ZmcCardPara.m_CurEditLine >= ZmcCardPara.m_TotalLine || ZmcCardPara.m_TotalLine < 1) return;

            ZmcCardPara.m_GraphData.RemoveAt(ZmcCardPara.m_CurEditLine);
            ZmcCardPara.m_TotalLine--;
            if (ZmcCardPara.m_CurEditLine >= ZmcCardPara.m_TotalLine)
            {
                ZmcCardPara.m_CurEditLine = ZmcCardPara.m_TotalLine - 1;
                if (ZmcCardPara.m_CurEditLine < 0) ZmcCardPara.m_CurEditLine = 0;
            }

            ZmcCardPara.m_CurEditAype = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].iType;
            Line_Start_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
            Line_Start_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
            Line_End_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
            Line_End_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
            Line_Start_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
            Line_End_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle2.ToString();
            Line_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
            Line_IfSpiral.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;

            switch (ZmcCardPara.m_CurEditAype)                  //添加类型
            {
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:    //点
                    Tab_MarkEdit.SelectedIndex = 0;
                    Lile_Type1.Checked = true;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:     //线
                    Tab_MarkEdit.SelectedIndex = 0;
                    Lile_Type2.Checked = true;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:      //圆弧
                    Tab_MarkEdit.SelectedIndex = 0;
                    Lile_Type3.Checked = true;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:   //圆
                    Tab_MarkEdit.SelectedIndex = 0;
                    Lile_Type4.Checked = true;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:     //矩形
                    Tab_MarkEdit.SelectedIndex = 0;
                    Lile_Type5.Checked = true;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:     //文本
                    Tab_MarkEdit.SelectedIndex = 1;
                    Word_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                    Word_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                    Word_Width.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                    Word_Height.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                    Word_Aangle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                    Word_TiltI.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle2.ToString();
                    Word_Accuracy.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAccuracy.ToString();
                    Word_Font.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr.ToString();
                    Word_Text.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr1.ToString();
                    Word_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                    Word_IfSpiral.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;
                    int ibit = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].nBitMode;
                    Word_Thickness.Checked = ((ibit & 0x1) == 0) ? false : true;
                    Word_UnderLine.Checked = ((ibit & 0x2) == 0) ? false : true;
                    Word_Italicas.Checked = ((ibit & 0x4) == 0) ? false : true;
                    Word_Delete.Checked = ((ibit & 0x8) == 0) ? false : true;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:  //条码
                    Tab_MarkEdit.SelectedIndex = 2;
                    BarCode_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                    BarCode_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                    BarCode_Width.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                    BarCode_Heigth.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                    BarCode_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                    BarCode_Type.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr.ToString();
                    BarCode_Text.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr1.ToString();
                    BarCode_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                    BarCode_IfSpiral.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:   //CAD图形
                    Tab_MarkEdit.SelectedIndex = 3;
                    Cad_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                    Cad_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                    Cad_Width.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                    Cad_High.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                    Cad_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                    Cad_FileName.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr.ToString();
                    Cad_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                    Cad_IfSpira.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;
                    break;
                default:
                    break;

            }

            ScanDrawList();
            Make3File();
        }

        //修改一行
        private void Btn_Change_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            if (ZmcCardPara.m_CurEditLine < 0 || ZmcCardPara.m_CurEditLine >= ZmcCardPara.m_TotalLine) return;

            ZmcCardPara.Struct_Graph TempLine = new ZmcCardPara.Struct_Graph();
            TempLine.iType = ZmcCardPara.m_CurEditAype;
            switch (ZmcCardPara.m_CurEditAype)                  //添加类型
            {
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:    //点
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:     //线
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:      //圆弧
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:   //圆
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:     //矩形
                        TempLine.fStartx = Convert.ToSingle(Line_Start_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Line_Start_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Line_End_PosX.Text);
                        TempLine.fEndy = Convert.ToSingle(Line_End_PosY.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Line_Start_Angle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Line_End_Angle.Text);
                        TempLine.If_Fill = Line_IfFill.Checked;
                        TempLine.If_Spiral = Line_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:     //文本
                       TempLine.fStartx = Convert.ToSingle(Word_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Word_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Word_Width.Text);
                        TempLine.fEndy = Convert.ToSingle(Word_Height.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Word_Aangle.Text);
                        TempLine.fAngle2 = Convert.ToSingle(Word_TiltI.Text);
                        TempLine.fAccuracy = Convert.ToSingle(Word_Accuracy.Text);
                        TempLine.GraphStr = Word_Font.Text;
                        TempLine.GraphStr1 =Word_Text.Text;
                        TempLine.If_Fill = Word_IfFill.Checked;
                        TempLine.If_Spiral = Word_IfSpiral.Checked;
                        int ibit = 0;
                        if(Word_Thickness.Checked)
                        {
                            ibit |= (1<<0);
                        }
                        else
                        {
                            ibit &=~(1<<0);
                        }

                         if(Word_UnderLine.Checked)
                        {
                            ibit |= (1<<1);
                        }
                        else
                        {
                            ibit &=~(1<<1);
                        }

                        if(Word_Italicas.Checked)
                        {
                            ibit |= (1<<2);
                        }
                        else
                        {
                            ibit &=~(1<<2);
                        }

                        if(Word_Delete.Checked)
                        {
                            ibit |= (1<<3);
                        }
                        else
                        {
                            ibit &=~(1<<3);
                        }
                        TempLine.nBitMode = ibit;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:  //条码
                        TempLine.fStartx = Convert.ToSingle(BarCode_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(BarCode_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(BarCode_Width.Text);
                        TempLine.fEndy = Convert.ToSingle(BarCode_Heigth.Text);
                        TempLine.fAngle1 = Convert.ToSingle(BarCode_Angle.Text);
                        TempLine.GraphStr = BarCode_Type.Text;
                        TempLine.GraphStr1 = BarCode_Text.Text;
                        TempLine.If_Fill = BarCode_IfFill.Checked;
                        TempLine.If_Spiral = BarCode_IfSpiral.Checked;
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:   //CAD图形
                        TempLine.fStartx = Convert.ToSingle(Cad_PosX.Text);
                        TempLine.fStarty = Convert.ToSingle(Cad_PosY.Text);
                        TempLine.fEndx = Convert.ToSingle(Cad_Width.Text);
                        TempLine.fEndy = Convert.ToSingle(Cad_High.Text);
                        TempLine.fAngle1 = Convert.ToSingle(Cad_Angle.Text);
                        TempLine.GraphStr = Cad_FileName.Text;
                        TempLine.If_Fill = Cad_IfFill.Checked;
                        TempLine.If_Spiral = Cad_IfSpira.Checked;
                    break;
                default:
                    break;

            }

            ZmcCardPara.m_GraphData.RemoveAt(ZmcCardPara.m_CurEditLine);
            ZmcCardPara.m_GraphData.Insert(ZmcCardPara.m_CurEditLine, TempLine);

            ScanDrawList();
            Make3File();
        }

        //图形居中
        private void Btn_Mid_Click(object sender, EventArgs e)
        {

            float fStartX, fStartY, fEndX, fEndY, fMidX, fMidY;


            switch (ZmcCardPara.m_CurEditAype)                  //添加类型
            {
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:    //点
                    Line_Start_PosX.Text = "0";
                    Line_Start_PosY.Text = "0";
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:     //线
                    fStartX = Convert.ToSingle(Line_Start_PosX.Text);
                    fStartY = Convert.ToSingle(Line_Start_PosY.Text);
                    fEndX = Convert.ToSingle(Line_End_PosX.Text);
                    fEndY = Convert.ToSingle(Line_End_PosY.Text);

                    fMidX =  fStartX + (fEndX -fStartX)/2;
                    fMidY = fStartY + (fEndY - fStartY)/2;

                    Line_Start_PosX.Text = (fStartX - fMidX).ToString();
                    Line_Start_PosY.Text = (fStartY - fMidY).ToString();
                    Line_End_PosX.Text = (fEndX - fMidX).ToString();
                    Line_End_PosY.Text = (fEndY - fMidY).ToString();
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:      //圆弧
                    Line_Start_PosX.Text = "0";
                    Line_Start_PosY.Text = "0";
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:   //圆
                    Line_Start_PosX.Text = "0";
                    Line_Start_PosY.Text = "0";
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:     //矩形
                    fStartX = Convert.ToSingle(Line_Start_PosX.Text);
                    fStartY = Convert.ToSingle(Line_Start_PosY.Text);
                    fEndX = Convert.ToSingle(Line_End_PosX.Text);
                    fEndY = Convert.ToSingle(Line_End_PosY.Text);

                    Line_Start_PosX.Text = (-1 * fEndX/2.0).ToString();
                    Line_Start_PosY.Text = (fEndY/2.0).ToString();
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:     //文本
                    fStartX = Convert.ToSingle(Word_PosX.Text);
                    fStartY = Convert.ToSingle(Word_PosY.Text);
                    fEndX = Convert.ToSingle(Word_Width.Text);
                    fEndY = Convert.ToSingle(Word_Height.Text);

                    int ilen = Word_Text.Text.Length;
	                float fWidth =  (float)(ilen/2.0*fEndX*fEndY/100.0);		//获取总长度

                    Word_PosX.Text = (-1 * fWidth / 2.0).ToString();
                    Word_PosY.Text = (-1 * fEndY / 2.0).ToString();
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:  //条码
                    fStartX = Convert.ToSingle(BarCode_PosX.Text);
                    fStartY = Convert.ToSingle(BarCode_PosY.Text);
                    fEndX = Convert.ToSingle(BarCode_Width.Text);
                    fEndY = Convert.ToSingle(BarCode_Heigth.Text);

                    BarCode_PosX.Text = (-1 * fEndX / 2.0).ToString();
                    BarCode_PosY.Text = (-1 * fEndY / 2.0).ToString();
                    break;
                case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:   //CAD图形

                    fEndX = Convert.ToSingle(Cad_Width.Text);
                    fEndY = Convert.ToSingle(Cad_High.Text);
                    Cad_PosX.Text = (-1 * fEndX / 2.0).ToString("F3");
                    Cad_PosY.Text = (-1 * fEndY / 2.0).ToString("F3");
                    break;
                default:
                    break;

            }

            Btn_Change_Click(sender,e);     //修改当前行
        }

        //刷新显示列表
        public void ScanDrawList()
        {
    
            File_listView.Items.Clear();

            this.File_listView.BeginUpdate();
            //添加数据
            for (int i = 0; i < ZmcCardPara.m_TotalLine; i++)
            {
                ListViewItem lvi = File_listView.Items.Add(i.ToString());

                switch (ZmcCardPara.m_GraphData[i].iType)
                {
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:
                        lvi.SubItems.Add("点");
                        lvi.SubItems.Add("坐标(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")");
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:
                        lvi.SubItems.Add("直线");
                        lvi.SubItems.Add("起点(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "结束点(" + ZmcCardPara.m_GraphData[i].fEndx + "," + ZmcCardPara.m_GraphData[i].fEndy + ")");
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:
                        lvi.SubItems.Add("圆弧");
                        lvi.SubItems.Add("圆心(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "半径：" + ZmcCardPara.m_GraphData[i].fEndx + "起始角度：" + ZmcCardPara.m_GraphData[i].fAngle1 + "旋转角度：" + ZmcCardPara.m_GraphData[i].fAngle2);
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:
                        lvi.SubItems.Add("整圆");
                        lvi.SubItems.Add("圆心(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "半径：" + ZmcCardPara.m_GraphData[i].fEndx);
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:
                        lvi.SubItems.Add("矩形");
                        lvi.SubItems.Add("起点(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "长：" + ZmcCardPara.m_GraphData[i].fEndx + "宽：" + ZmcCardPara.m_GraphData[i].fEndy);
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:
                        lvi.SubItems.Add("文本");
                        lvi.SubItems.Add(ZmcCardPara.m_GraphData[i].GraphStr1 + "起点(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "宽：" + ZmcCardPara.m_GraphData[i].fEndx + "高：" + ZmcCardPara.m_GraphData[i].fEndy);
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:
                        lvi.SubItems.Add("条码");
                        lvi.SubItems.Add(ZmcCardPara.m_GraphData[i].GraphStr1 + "起点(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "宽：" + ZmcCardPara.m_GraphData[i].fEndx + "高：" + ZmcCardPara.m_GraphData[i].fEndy);
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:
                        lvi.SubItems.Add("CAD图形");
                        lvi.SubItems.Add("起点(" + ZmcCardPara.m_GraphData[i].fStartx + "," + ZmcCardPara.m_GraphData[i].fStarty + ")" + "宽：" + ZmcCardPara.m_GraphData[i].fEndx + "高：" + ZmcCardPara.m_GraphData[i].fEndy);
                        break;
                    default:
                        break;

                }

                lvi.ForeColor = Color.Black;
                if (ZmcCardPara.m_CurEditLine == i)
                {
                    lvi.BackColor = Color.FromArgb(0xf2, 0xf1, 0x0);
                }
                else
                {
                    lvi.BackColor = Color.LightGray;
                }

            }

            //结束数据处理，UI界面一次性绘制。
            this.File_listView.EndUpdate();

        }

        //切换编辑行
        private void File_listView_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (this.File_listView.SelectedItems.Count > 0)
            {
                ZmcCardPara.m_CurEditLine = this.File_listView.SelectedItems[0].Index;

                ZmcCardPara.m_CurEditAype = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].iType;
                Line_Start_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                Line_Start_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                Line_End_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                Line_End_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                Line_Start_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                Line_End_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle2.ToString();
                Line_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                Line_IfSpiral.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;

                switch (ZmcCardPara.m_CurEditAype)                  //添加类型
                {
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT:    //点
                        Tab_MarkEdit.SelectedIndex = 0;
                        Lile_Type1.Checked = true;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE:     //线
                        Tab_MarkEdit.SelectedIndex = 0;
                        Lile_Type2.Checked = true;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC:      //圆弧
                        Tab_MarkEdit.SelectedIndex = 0;
                        Lile_Type3.Checked = true;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE:   //圆
                        Tab_MarkEdit.SelectedIndex = 0;
                        Lile_Type4.Checked = true;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT:     //矩形
                        Tab_MarkEdit.SelectedIndex = 0;
                        Lile_Type5.Checked = true;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD:     //文本
                        Tab_MarkEdit.SelectedIndex = 1;       
                        Word_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                        Word_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                        Word_Width.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                        Word_Height.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                        Word_Aangle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                        Word_TiltI.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle2.ToString();
                        Word_Accuracy.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAccuracy.ToString();
                        Word_Font.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr.ToString();
                        Word_Text.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr1.ToString();
                        Word_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                        Word_IfSpiral.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;
                        int ibit =  ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].nBitMode;
                        Word_Thickness.Checked = ((ibit & 0x1) ==0) ? false : true;
                        Word_UnderLine.Checked = ((ibit & 0x2) == 0) ? false : true;
                        Word_Italicas.Checked = ((ibit & 0x4) == 0) ? false : true;
                        Word_Delete.Checked = ((ibit & 0x8) == 0) ? false : true;                 
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE:  //条码
                        Tab_MarkEdit.SelectedIndex = 2;
                        BarCode_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                        BarCode_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                        BarCode_Width.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                        BarCode_Heigth.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                        BarCode_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                        BarCode_Type.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr.ToString();
                        BarCode_Text.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr1.ToString();
                        BarCode_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                        BarCode_IfSpiral.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;
                        break;
                    case (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF:   //CAD图形
                        Tab_MarkEdit.SelectedIndex = 3;
                        Cad_PosX.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStartx.ToString();
                        Cad_PosY.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fStarty.ToString();
                        Cad_Width.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndx.ToString();
                        Cad_High.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fEndy.ToString();
                        Cad_Angle.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].fAngle1.ToString();
                        Cad_FileName.Text = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].GraphStr.ToString();
                        Cad_IfFill.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Fill;
                        Cad_IfSpira.Checked = ZmcCardPara.m_GraphData[ZmcCardPara.m_CurEditLine].If_Spiral;
                        break;
                    default:
                        break;



                }

            }
            ScanDrawList();
        }

        #endregion

        #region  图形绘制相关接口


        //还原图形比例显示绘图
        private void MyPicture_DoubleClick(object sender, EventArgs e)
        {
            m_PicOffsetX = 0;
            m_PicOffsetY = 0;
            m_PicScale = 1.0;

            //绘图
            Show_Picture();
        }

        //滚轮缩放
        private void MyPicture_MouseWheel(object sender, MouseEventArgs e)
        {
            double MousePosX, MousePosY;
            int iCenterX = MyPicture.Width/2;
            int iCenterY = MyPicture.Height/2;

            MousePosX = (e.Location.X - iCenterX) /m_dUnitsPerMm + m_PicOffsetX;
            MousePosY = (iCenterY - e.Location.Y) /m_dUnitsPerMm + m_PicOffsetY;
         
            if (e.Delta > 0)
            {
                // 滚轮向上，放大画布
                m_PicOffsetX = MousePosX*1.1 - MousePosX;                 //偏移
                m_PicOffsetY = MousePosY*1.1 - MousePosY;
                m_PicScale *= 1.1;
            }
            else
            {
                // 滚轮向下，缩小画布
                m_PicOffsetX = MousePosX /1.1 - MousePosX;                 //偏移
                m_PicOffsetY = MousePosY /1.1 - MousePosY;
                m_PicScale /= 1.1;              
            }


            //绘图
           Show_Picture();
        }

        private void MyPicture_MouseEnter(object sender, EventArgs e)
        {
            OperatingSystem os = Environment.OSVersion;
            Version version = os.Version;

            if (version.Major == 6 && version.Minor == 1)     //windows 7
            {
                MyPicture.Focus();
            }
        }

        private void MyPicture_MouseMove(object sender, MouseEventArgs e)
        {
            double MousePosX, MousePosY;
            int iCenterX = MyPicture.Width / 2;
            int iCenterY = MyPicture.Height / 2;

            MousePosX = (e.Location.X - iCenterX) / m_dUnitsPerMm + m_PicOffsetX;
            MousePosY = (iCenterY - e.Location.Y) / m_dUnitsPerMm + m_PicOffsetY;

            label2.Text = MousePosX.ToString("f2") + ",\t" + MousePosY.ToString("f2");
        }

        //显示图形
        public void Show_Picture1()
        {
            m_BitImage = new Bitmap(MyPicture.Width, MyPicture.Height);      //设置图像大小
            m_Graphics = Graphics.FromImage(m_BitImage);
            Draw_Rect(0, 0, MyPicture.Width - 1, MyPicture.Height - 1);
            MyPicture.Image = m_BitImage;

            PicWidth = MyPicture.Width - 10;
            PicHeight = MyPicture.Height - 10;

            //绘图
            m_Graphics.Clear(Color.White);
            m_PenColor = Color.Black;                        //默认颜色
            m_Pen = new Pen(m_PenColor, 1);              //画笔颜色,宽度   

            float Image_Left, Image_bottom, Image_Width, Image_Height;
            Image_Left = 0;
            Image_bottom = 0;
            Image_Width = 0;
            Image_Height = 0;

            uint iret = ZmcLaser.ZmotionLaser_GetCurGraphRange(ref Image_Left, ref Image_bottom, ref Image_Width, ref Image_Height, 0.05);
           ZmcCardPara.m_GraphRange[0] = Image_Left;
           ZmcCardPara.m_GraphRange[1] = Image_bottom;
           ZmcCardPara.m_GraphRange[2] = Image_Width;
           ZmcCardPara.m_GraphRange[3] = Image_Height;
            if (Image_Width < 0.0001 && Image_Height < 0.0001)
            {
                Image_Left = (float)0.0;
                Image_bottom = (float)0.0;
                Image_Width = (float)100.0;
                Image_Height = (float)100.0;
            }

            float top;
            //转成显示坐标
            top = (Image_bottom + Image_Height);

            //显示的区域
            double WinWidth = (PicWidth - 40) * 0.5;
            double WinHeight = (PicHeight - 40) * 0.5;

            // 实际的区域
            double ObjectWidth = Image_Width;
            double ObjectHeight = Image_Height;

            double ObjectPixHeight, ObjectPixWidth;
            if (ObjectWidth * WinHeight <= WinWidth * ObjectHeight)
            {
                ObjectPixHeight = WinHeight;
                ObjectPixWidth = ObjectPixHeight * ObjectWidth / ObjectHeight;
            }
            else
            {
                ObjectPixWidth = WinWidth;
                ObjectPixHeight = ObjectPixWidth * ObjectHeight / ObjectWidth;
            }

            //缩放比例
            double dScale = 0.0;
            dScale = ObjectPixHeight / ObjectHeight;
            m_dUnitsPerMm = dScale * m_PicScale;

            Draw_Rect(0, 0, MyPicture.Width - 1, MyPicture.Height - 1);

            int iCenterX, iCenterY;
            int iStartx, iStarty;

            //绘刻度尺X
            iCenterX = MyPicture.Width / 2;
            iCenterY = 0;


            Draw_Line(iCenterX, iCenterY, iCenterX, iCenterY + 15);
            Draw_String(iCenterX + 2, iCenterY, "0");
            for (int i = 0; i < 4; i++)
            {

                iStartx = iCenterX + (i + 1) * (MyPicture.Width / 10);
                iStarty = iCenterY;

                Draw_Line(iStartx, iStarty, iStartx, iStarty + 15);
                Draw_String(iStartx + 2, iStarty, ((i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Width / 10)).ToString("f2"));

                iStartx = iCenterX - (i + 1) * (MyPicture.Width / 10);
                iStarty = iCenterY;

                Draw_Line(iStartx, iStarty, iStartx, iStarty + 15);
                Draw_String(iStartx + 2, iStarty, (-1 * (i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Width / 10)).ToString("f2"));
            }

            //绘刻度尺Y
            iCenterX = 0;
            iCenterY = MyPicture.Height / 2;

            Draw_Line(iCenterX, iCenterY, iCenterX + 15, iCenterY);
            Draw_String(iCenterX + 2, iCenterY, "0");
            for (int i = 0; i < 4; i++)
            {

                iStartx = iCenterX;
                iStarty = iCenterY + (i + 1) * (MyPicture.Height / 10);

                Draw_Line(iStartx, iStarty, iStartx + 15, iStarty);
                Draw_String(iStartx + 2, iStarty, (-1 * (i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Height / 10)).ToString("f2"));

                iStartx = iCenterX;
                iStarty = iCenterY - (i + 1) * (MyPicture.Height / 10);

                Draw_Line(iStartx, iStarty, iStartx + 15, iStarty);
                Draw_String(iStartx + 2, iStarty, ((i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Height / 10)).ToString("f2"));
            }

            //绘制中心虚线
            Draw_DottedLine(0, MyPicture.Height / 2, MyPicture.Width, MyPicture.Height / 2);
            Draw_DottedLine(MyPicture.Width/2, 0, MyPicture.Width / 2, MyPicture.Height);


            //绘制轨迹
            m_Pen = new Pen(Color.Red, 1);              //画笔颜色,宽度   
            for (int i = 0; i < ZmcCardPara.ZCad_ArrayLen; i++)                //遍历数组
            {
                double dXPrevPos_x1, dXPrevPos_x2, dXPrevPos_z1, dXPrevPos_y1, dXPrevPos_y2, dXPrevPos_z2;
                dXPrevPos_x1 = ZmcCardPara.ZCad_ArrayInfo[i].x1 * m_dUnitsPerMm + MyPicture.Width / 2;
                dXPrevPos_x2 = ZmcCardPara.ZCad_ArrayInfo[i].x2 * m_dUnitsPerMm + MyPicture.Width / 2;
                dXPrevPos_z1 = ZmcCardPara.ZCad_ArrayInfo[i].z1 / Math.PI * 180;
                dXPrevPos_y1 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y1 * m_dUnitsPerMm;
                dXPrevPos_y2 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y2 * m_dUnitsPerMm;
                dXPrevPos_z2 = ZmcCardPara.ZCad_ArrayInfo[i].z2 / Math.PI * 180;

                if (ZmcCardPara.ZCad_ArrayInfo[i].m_nEmptyMove != 0)
                {
                    // Draw_DottedLine((int)dXPrevPos_x1, (int)dXPrevPos_y1, (int)dXPrevPos_x2, (int)dXPrevPos_y2);
                }
                else
                {
                    switch (ZmcCardPara.ZCad_ArrayInfo[i].m_nItemtype)
                    {
                        case ZmcLaser.ZCAD_ITEMTYPE_VECT:
                            break;
                        case ZmcLaser.ZCAD_ITEMTYPE_VECTPoint:
                            break;
                        case ZmcLaser.ZCAD_ITEMTYPE_VECTLine:
                            Draw_Line((int)dXPrevPos_x1, (int)dXPrevPos_y1, (int)dXPrevPos_x2, (int)dXPrevPos_y2);
                            break;
                        case ZmcLaser.ZCAD_ITEMTYPE_VECTArc:
                            dXPrevPos_x1 = ZmcCardPara.ZCad_ArrayInfo[i].x1 * m_dUnitsPerMm + MyPicture.Width / 2;
                            dXPrevPos_x2 = ZmcCardPara.ZCad_ArrayInfo[i].x2 * m_dUnitsPerMm + MyPicture.Width / 2;
                            dXPrevPos_y1 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y1 * m_dUnitsPerMm;
                            dXPrevPos_y2 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y2 * m_dUnitsPerMm;

                            if (dXPrevPos_z2 < 0)
                            {
                                dXPrevPos_z1 = dXPrevPos_z1 + dXPrevPos_z2;
                                dXPrevPos_z2 = -1 * dXPrevPos_z2;
                            }

                            if (dXPrevPos_z2 == 0)             //整圆
                            {
                                dXPrevPos_z2 += 360;
                            }
                            Draw_Arc((int)dXPrevPos_x1,MyPicture.Height - (int)dXPrevPos_y1,(int)Math.Abs(dXPrevPos_x2 - dXPrevPos_x1), (int)Math.Abs(dXPrevPos_y1 - dXPrevPos_y2), (float)dXPrevPos_z1, (float)dXPrevPos_z2);
                            break;
                        default:
                            Draw_Line((int)dXPrevPos_x1, (int)dXPrevPos_y1, (int)dXPrevPos_x2, (int)dXPrevPos_y2);
                            break;
                    }


                }
            }

            MyPicture.Image = m_BitImage;
        }

        public void Show_Picture()
        {
            m_BitImage = new Bitmap(MyPicture.Width, MyPicture.Height);      //设置图像大小
            m_Graphics = Graphics.FromImage(m_BitImage);
            Draw_Rect(0, 0, MyPicture.Width - 1, MyPicture.Height - 1);
            MyPicture.Image = m_BitImage;

            PicWidth = MyPicture.Width - 10;
            PicHeight = MyPicture.Height - 10;

            //绘图
            m_Graphics.Clear(Color.White);
            m_PenColor = Color.Black;                        //默认颜色
            m_Pen = new Pen(m_PenColor, 1);              //画笔颜色,宽度   

            float Image_Left, Image_bottom, Image_Width, Image_Height;
            Image_Left = 0;
            Image_bottom = 0;
            Image_Width = 0;
            Image_Height = 0;

            uint iret = ZmcLaser.ZmotionLaser_GetCurGraphRange(ref Image_Left, ref Image_bottom, ref Image_Width, ref Image_Height, 0.05);
            ZmcCardPara.m_GraphRange[0] = Image_Left;
            ZmcCardPara.m_GraphRange[1] = Image_bottom;
            ZmcCardPara.m_GraphRange[2] = Image_Width;
            ZmcCardPara.m_GraphRange[3] = Image_Height;
            if (Image_Width < 0.0001 && Image_Height < 0.0001)
            {
                Image_Left = (float)0.0;
                Image_bottom = (float)0.0;
                Image_Width = (float)100.0;
                Image_Height = (float)100.0;
            }

            float top;
            //转成显示坐标
            top = (Image_bottom + Image_Height);

            //显示的区域
            double WinWidth = (PicWidth - 40) * 0.5;
            double WinHeight = (PicHeight - 40) * 0.5;

            // 实际的区域
            double ObjectWidth = Image_Width;
            double ObjectHeight = Image_Height;

            double ObjectPixHeight, ObjectPixWidth;
            if (ObjectWidth * WinHeight <= WinWidth * ObjectHeight)
            {
                ObjectPixHeight = WinHeight;
                ObjectPixWidth = ObjectPixHeight * ObjectWidth / ObjectHeight;
            }
            else
            {
                ObjectPixWidth = WinWidth;
                ObjectPixHeight = ObjectPixWidth * ObjectHeight / ObjectWidth;
            }

            //缩放比例
            double dScale = 0.0;
            dScale = ObjectPixHeight / ObjectHeight;
            m_dUnitsPerMm = dScale * m_PicScale;

            Draw_Rect(0, 0, MyPicture.Width - 1, MyPicture.Height - 1);

            int iCenterX, iCenterY;
            int iStartx, iStarty;

            //绘刻度尺X
            iCenterX = MyPicture.Width / 2;
            iCenterY = 0;


            Draw_Line(iCenterX, iCenterY, iCenterX, iCenterY + 15);
            Draw_String(iCenterX + 2, iCenterY, m_PicOffsetX.ToString("f2"));
            for (int i = 0; i < 4; i++)
            {
                iStartx = iCenterX + (i + 1) * (MyPicture.Width / 10);
                iStarty = iCenterY;
                Draw_Line(iStartx, iStarty, iStartx, iStarty + 15);
                Draw_String(iStartx + 2, iStarty, ((i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Width / 10) + m_PicOffsetX).ToString("f2"));

                iStartx = iCenterX - (i + 1) * (MyPicture.Width / 10);
                iStarty = iCenterY;
                Draw_Line(iStartx, iStarty, iStartx, iStarty + 15);
                Draw_String(iStartx + 2, iStarty, (-1 * (i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Width / 10) + m_PicOffsetX).ToString("f2"));
            }

            //绘刻度尺Y
            iCenterX = 0;
            iCenterY = MyPicture.Height / 2;

            Draw_Line(iCenterX, iCenterY, iCenterX + 15, iCenterY);
            Draw_String(iCenterX + 2, iCenterY, (m_PicOffsetY / m_dUnitsPerMm).ToString("f2"));
            for (int i = 0; i < 4; i++)
            {

                iStartx = iCenterX;
                iStarty = iCenterY + (i + 1) * (MyPicture.Height / 10);

                Draw_Line(iStartx, iStarty, iStartx + 15, iStarty);
                Draw_String(iStartx + 2, iStarty, (-1 * (i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Height / 10)  + m_PicOffsetY).ToString("f2"));

                iStartx = iCenterX;
                iStarty = iCenterY - (i + 1) * (MyPicture.Height / 10);

                Draw_Line(iStartx, iStarty, iStartx + 15, iStarty);
                Draw_String(iStartx + 2, iStarty, ((i + 1) * 1 / m_dUnitsPerMm * (MyPicture.Height / 10) + m_PicOffsetY).ToString("f2"));
            }

            //绘制中心虚线
            Draw_DottedLine(0, MyPicture.Height / 2, MyPicture.Width, MyPicture.Height / 2);
            Draw_DottedLine(MyPicture.Width / 2, 0, MyPicture.Width / 2, MyPicture.Height);


            //绘制轨迹
            m_Pen = new Pen(Color.Red, 1);              //画笔颜色,宽度   
            for (int i = 0; i < ZmcCardPara.ZCad_ArrayLen; i++)                //遍历数组
            {
                double dXPrevPos_x1, dXPrevPos_x2, dXPrevPos_z1, dXPrevPos_y1, dXPrevPos_y2, dXPrevPos_z2;
                dXPrevPos_x1 = ZmcCardPara.ZCad_ArrayInfo[i].x1 * m_dUnitsPerMm + MyPicture.Width / 2 - m_PicOffsetX * m_dUnitsPerMm;
                dXPrevPos_x2 = ZmcCardPara.ZCad_ArrayInfo[i].x2 * m_dUnitsPerMm + MyPicture.Width / 2 - m_PicOffsetX * m_dUnitsPerMm;
                dXPrevPos_z1 = ZmcCardPara.ZCad_ArrayInfo[i].z1 / Math.PI * 180;
                dXPrevPos_y1 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y1 * m_dUnitsPerMm + m_PicOffsetY * m_dUnitsPerMm;
                dXPrevPos_y2 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y2 * m_dUnitsPerMm + m_PicOffsetY * m_dUnitsPerMm;
                dXPrevPos_z2 = ZmcCardPara.ZCad_ArrayInfo[i].z2 / Math.PI * 180;

                if (ZmcCardPara.ZCad_ArrayInfo[i].m_nEmptyMove != 0)
                {
                    // Draw_DottedLine((int)dXPrevPos_x1, (int)dXPrevPos_y1, (int)dXPrevPos_x2, (int)dXPrevPos_y2);
                }
                else
                {
                    switch (ZmcCardPara.ZCad_ArrayInfo[i].m_nItemtype)
                    {
                        case ZmcLaser.ZCAD_ITEMTYPE_VECT:
                            break;
                        case ZmcLaser.ZCAD_ITEMTYPE_VECTPoint:
                            break;
                        case ZmcLaser.ZCAD_ITEMTYPE_VECTLine:
                            Draw_Line((int)dXPrevPos_x1, (int)dXPrevPos_y1, (int)dXPrevPos_x2, (int)dXPrevPos_y2);
                            break;
                        case ZmcLaser.ZCAD_ITEMTYPE_VECTArc:
                            dXPrevPos_x1 = ZmcCardPara.ZCad_ArrayInfo[i].x1 * m_dUnitsPerMm + MyPicture.Width / 2 - m_PicOffsetX * m_dUnitsPerMm;
                            dXPrevPos_x2 = ZmcCardPara.ZCad_ArrayInfo[i].x2 * m_dUnitsPerMm + MyPicture.Width / 2 - m_PicOffsetX * m_dUnitsPerMm;
                            dXPrevPos_y1 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y1 * m_dUnitsPerMm + m_PicOffsetY * m_dUnitsPerMm;
                            dXPrevPos_y2 = MyPicture.Height / 2 - ZmcCardPara.ZCad_ArrayInfo[i].y2 * m_dUnitsPerMm + m_PicOffsetY * m_dUnitsPerMm;

                            if (dXPrevPos_z2 < 0)
                            {
                                dXPrevPos_z1 = dXPrevPos_z1 + dXPrevPos_z2;
                                dXPrevPos_z2 = -1 * dXPrevPos_z2;
                            }

                            if (dXPrevPos_z2 == 0)             //整圆
                            {
                                dXPrevPos_z2 += 360;
                            }
                            Draw_Arc((int)dXPrevPos_x1, MyPicture.Height - (int)dXPrevPos_y1, (int)Math.Abs(dXPrevPos_x2 - dXPrevPos_x1), (int)Math.Abs(dXPrevPos_y1 - dXPrevPos_y2), (float)dXPrevPos_z1, (float)dXPrevPos_z2);
                            break;
                        default:
                            Draw_Line((int)dXPrevPos_x1, (int)dXPrevPos_y1, (int)dXPrevPos_x2, (int)dXPrevPos_y2);
                            break;
                    }


                }
            }

            MyPicture.Image = m_BitImage;
        }

        //画直线
        public void Draw_Line(int startx, int starty, int endx, int endy)
        {
            m_Graphics.DrawLine(m_Pen, startx, starty, endx, endy);
        }

        //画矩形
        public void Draw_Rect(int x_pos, int y_pos, int iWight, int iHeight)
        {
            m_Graphics.DrawRectangle(m_Pen, x_pos, y_pos, iWight, iHeight);
        }

        //画虚线
        public void Draw_DottedLine(int startx, int starty, int endx, int endy)          //虚线
        {
            m_Pen.DashPattern = new float[] { 5, 5 };                                     //设置短划线和空白部分的数组
            m_Graphics.DrawLine(m_Pen, startx, starty, endx, endy);
            m_Pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;                   //实线
        }

        //画圆弧
        public void Draw_Arc(int x_pos, int y_pos, int iWight, int iHeight, float Start_Angle, float End_Angle)
        {
            if (iWight <= 0)
            {
                iWight = 1;
            }
            if (iHeight <= 0)
            {
                iHeight = 1;
            }
            Rectangle Rec = new Rectangle(x_pos, y_pos, iWight, iHeight);
            m_Graphics.DrawArc(m_Pen, Rec, Start_Angle, End_Angle);
        }

        //画字符
        public void Draw_String(int x_pos, int y_pos, String Str_Text)
        {
            Font font = new Font("宋体", 9f);
            Brush brush = Brushes.Black;
            m_Graphics.DrawString(Str_Text, font, brush, x_pos, y_pos);
        }

#endregion

        //编辑TAB页面发生修改
        private void Tab_MarkEdit_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPage == tabPage_Line)              //多段线编辑页面
            {
                if (Lile_Type1.Checked)
                {
                    ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT;
                }
                else if (Lile_Type2.Checked)
                {
                    ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE;
                }
                else if (Lile_Type3.Checked)
                {
                    ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC;
                }
                else if (Lile_Type4.Checked)
                {
                    ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE;
                }
                else if (Lile_Type5.Checked)
                {
                    ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT;
                }
            }
            else if (e.TabPage == tabPage_Word)         //文本编辑页面
            {
                ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_WORD;
            }
            else if (e.TabPage == tabPage_BarCode)      //条码编辑页面
            {
                ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_BARCODE;
            }
            else if (e.TabPage == tabPage_Cad)          //CAD编辑页面
            {
                ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_DXF;
            }

        }

        //点类型被选中
        private void Lile_Type1_CheckedChanged(object sender, EventArgs e)
        {
            ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_POINT;

            labPosX.Text = "起点X";
            labPosY.Text = "起点Y";

            Line_End_PosX.Visible = false;
            Line_End_PosY.Visible = false;
            Line_Start_Angle.Visible = false;
            Line_End_Angle.Visible = false;
            labEndX.Visible = false;
            labEndY.Visible = false;
            labAngle1.Visible = false;
            labAngle2.Visible = false;
        }

        //线类型被选中
        private void Lile_Type2_CheckedChanged(object sender, EventArgs e)
        {
            ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_LINE;

            labPosX.Text = "起点X";
            labPosY.Text = "起点Y";
            labEndX.Text = "结束点X";
            labEndY.Text = "结束点Y";
            Line_End_PosX.Text = "5";
            Line_End_PosY.Text = "5";

            Line_End_PosX.Visible = true;
            Line_End_PosY.Visible = true;
            Line_Start_Angle.Visible = false;
            Line_End_Angle.Visible = false;
            labEndX.Visible = true;
            labEndY.Visible = true;
            labAngle1.Visible = false;
            labAngle2.Visible = false;
        }

        //圆弧类型
        private void Lile_Type3_CheckedChanged(object sender, EventArgs e)
        {
            ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_ARC;

            labPosX.Text = "圆心X";
            labPosY.Text = "圆心Y";
            labEndX.Text = "圆弧半径";
            labEndY.Text = "圆精度";

            Line_End_PosX.Text = "5";
            Line_End_PosY.Text = "0.01";

            Line_End_PosX.Visible = true;
            Line_End_PosY.Visible = true;
            Line_Start_Angle.Visible = true;
            Line_End_Angle.Visible = true;
            labEndX.Visible = true;
            labEndY.Visible = true;
            labAngle1.Visible = true;
            labAngle2.Visible = true;
        }

        //圆类型
        private void Lile_Type4_CheckedChanged(object sender, EventArgs e)
        {
            ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_CIRCLE;

            labPosX.Text = "圆心X";
            labPosY.Text = "圆心Y";
            labEndX.Text = "圆弧半径";
            labEndY.Text = "圆精度";

            Line_End_PosX.Text = "5";
            Line_End_PosY.Text = "0.01";

            Line_End_PosX.Visible = true;
            Line_End_PosY.Visible = true;
            Line_Start_Angle.Visible = false;
            Line_End_Angle.Visible = false;
            labEndX.Visible = true;
            labEndY.Visible = true;
            labAngle1.Visible = false;
            labAngle2.Visible = false;
        }

        //矩形类型
        private void Lile_Type5_CheckedChanged(object sender, EventArgs e)
        {
            ZmcCardPara.m_CurEditAype = (int)ZmcCardPara.ZMC_MARK_TYPE.ZMC_MARK_RECT;

            labPosX.Text = "起点X";
            labPosY.Text = "起点Y";
            labEndX.Text = "宽度";
            labEndY.Text = "高度";
            Line_End_PosX.Text = "5";
            Line_End_PosY.Text = "5";

            Line_End_PosX.Visible = true;
            Line_End_PosY.Visible = true;
            Line_Start_Angle.Visible = false;
            Line_End_Angle.Visible = false;
            labEndX.Visible = true;
            labEndY.Visible = true;
            labAngle1.Visible = false;
            labAngle2.Visible = false;
        }

              //读写ini文件函数
        /// <summary>
        /// 写入
        /// </summary>
        /// <param name="section">需要写入的段落名</param>
        /// <param name="key">需要写入的键名</param>
        /// <param name="val">写入值</param>
        /// <param name="filepath">ini文件的完整路径</param>
        /// <returns></returns>
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        /// <summary>
        /// 获取值
        /// </summary>
        /// <param name="section">段落名</param>
        /// <param name="key">键名</param>
        /// <param name="defval">读取异常是的缺省值</param>
        /// <param name="retval">键名所对应的的值，没有找到返回空值</param>
        /// <param name="size">返回值允许的大小</param>
        /// <param name="filepath">ini文件的完整路径</param>
        /// <returns></returns>
        [DllImport("kernel32")]
        private static extern long GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        //读取INI配置文件
        public static void Read_MarkCfg()
        {
            //配置文件读取
            string nFilePath = System.Environment.CurrentDirectory + "\\ini";
            if (!System.IO.Directory.Exists(nFilePath))
            {
                System.IO.Directory.CreateDirectory(nFilePath);//不存在就创建目录 
            }
            //文件名带目录创建
            string nFileName = nFilePath + "\\ZmcLaserSet.ini";
            if (File.Exists(nFileName) == false)
            {
                //创建文件
                FileStream TestFile = new FileStream(nFileName, FileMode.OpenOrCreate);
                StreamWriter SwFile = new StreamWriter(TestFile);
                SwFile.Close();

                //初始化配置文件
                Write_MarkCfg(nFileName);
            }

            StringBuilder retval = new StringBuilder();
       
            //SYSTEM配置
            GetPrivateProfileString("System", "MarkCardIpAdrr", "192.168.0.11", retval, 128, nFileName);
            ZmcCardPara.G_MarkCardIpAdrr = retval.ToString();

            GetPrivateProfileString("System", "TeachFilePath",System.Environment.CurrentDirectory + "\\TeachFile", retval, 128, nFileName);
            ZmcCardPara.TeachFilePath = retval.ToString();

            GetPrivateProfileString("System", "TeachName","TeachFile.txt", retval, 128, nFileName);
            ZmcCardPara.TeachName = retval.ToString();

            //MarkPara配置
            GetPrivateProfileString("MarkPara", "EmpSpeed", "1000", retval, 20, nFileName);
            ZmcCardPara.m_dEmpSpeed = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("MarkPara", "MarkSpeed", "100", retval, 20, nFileName);
            ZmcCardPara.m_dMarkSpeed = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("MarkPara", "MarkPower", "30", retval, 20, nFileName);
            ZmcCardPara.m_nPower = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("MarkPara", "OpenDelay", "1000", retval, 20, nFileName);
            ZmcCardPara.m_nStartDelay = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("MarkPara", "CloseDelay", "1000", retval, 20, nFileName);
            ZmcCardPara.m_nLastDelay = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("MarkPara", "CornerDelay", "0", retval, 20, nFileName);
            ZmcCardPara.m_nCorDelay = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("MarkPara", "JumpDelay", "0", retval, 20, nFileName);
            ZmcCardPara.m_nJumpDelay = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("MarkPara", "LaserPower", "30", retval, 20, nFileName);
            ZmcCardPara.m_nPower = Convert.ToInt32(retval.ToString());

             GetPrivateProfileString("MarkPara", "PwmDuty", "0.5", retval, 20, nFileName);
            ZmcCardPara.m_fPwmDuty = Convert.ToSingle(retval.ToString());

             GetPrivateProfileString("MarkPara", "PwmFreq", "40000", retval, 20, nFileName);
            ZmcCardPara.m_nPwmFreq = Convert.ToInt32(retval.ToString());

            

            //激光器参数
            GetPrivateProfileString("LaserPara", "Type", "0", retval, 20, nFileName);
            ZmcCardPara.m_nLaserType = Convert.ToInt32(retval.ToString());

	        GetPrivateProfileString("LaserPara", "EnableIO", "47", retval, 20, nFileName);
            ZmcCardPara.m_nEnableIO = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("LaserPara", "LaserIO", "8", retval, 20, nFileName);
            ZmcCardPara.m_nLaserIO = Convert.ToInt32(retval.ToString());

             GetPrivateProfileString("LaserPara", "RedIO", "8", retval, 20, nFileName);
            ZmcCardPara.m_nRedIO = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("LaserPara", "Aout", "3", retval, 20, nFileName);
            ZmcCardPara.m_nAout = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("LaserPara", "AoutRange", "127", retval, 20, nFileName);
            ZmcCardPara.m_nAoutVal = Convert.ToInt32(retval.ToString());

             GetPrivateProfileString("LaserPara", "PwmIo", "9", retval, 20, nFileName);
            ZmcCardPara.m_nPwmIo = Convert.ToInt32(retval.ToString());

            //轴参数设置保存
            String lpAppName = ""; 
            for (int iAxis = 0; iAxis < 4; iAxis++)
            {
                lpAppName = "Axis" + iAxis.ToString();
                GetPrivateProfileString(lpAppName, "Atype", "1", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].atype = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "Units", "1000", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].units = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "Lspeed", "0", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].lspeed = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "Speed", "100", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].speed = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "Accel", "1000", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].accel = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "Decel", "1000", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].decel = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "Sramp", "60", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].sramp = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "MotorDir", "0", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].MotorDir = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "EndoerDir", "0", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].EncoderDir = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "FsLimit", "200000000", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].fsLimit = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "RsLimit", "-200000000", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].rsLimit = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "FwdIn", "-1", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].fwdIn = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "RevIn", "-1", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].revIn = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "AlmIn", "-1", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].almIn = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "DatunIn", "-1", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].datumIn = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "HomeMode", "14", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].HomeMode = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "HomeSpeed", "100", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].HomeMoveSp = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "HomeLowSp", "100", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].HomeLowSp = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "HomeOffpos", "0", retval, 20, nFileName);
                ZmcCardPara.m_AxisPara[iAxis].HomeOffpos = Convert.ToSingle(retval.ToString());
            }

            //振镜参数设置保存
            GetPrivateProfileString("ScanAxisPara", "ScanID", "0", retval, 20, nFileName);
            ZmcCardPara.m_ScanId = Convert.ToInt32(retval.ToString());
            for (int iScan = 0; iScan < 2; iScan++)
            {
                lpAppName = "Scan" + iScan.ToString();
                GetPrivateProfileString(lpAppName, "Units", "1000", retval, 20, nFileName);
                ZmcCardPara.m_ScanAxisPara[iScan].units = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "Speed", "1000", retval, 20, nFileName);
                ZmcCardPara.m_ScanAxisPara[iScan].speed = Convert.ToSingle(retval.ToString());

                GetPrivateProfileString(lpAppName, "XyChange", "0", retval, 20, nFileName);
                ZmcCardPara.m_ScanAxisPara[iScan].m_ScanXyChange = Convert.ToInt32(retval.ToString());

                GetPrivateProfileString(lpAppName, "CorrectFile", "0", retval, 256, nFileName);
                ZmcCardPara.m_ScanAxisPara[iScan].SscanCorrectFile = retval.ToString();
            }

                //填充工艺配置
                GetPrivateProfileString("MarkFill", "Enbale", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_bEnable = (Convert.ToInt32(retval.ToString()) == 1)?true:false;

            GetPrivateProfileString("MarkFill", "OutlineFirst", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_bOutlineFirst = (Convert.ToInt32(retval.ToString()) == 1)?true:false;

            GetPrivateProfileString("MarkFill", "Edge", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_bEdge = (Convert.ToInt32(retval.ToString()) == 1)?true:false;

            GetPrivateProfileString("MarkFill", "Whole", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_bWhole = (Convert.ToInt32(retval.ToString()) == 1) ? true : false;

            GetPrivateProfileString("MarkFill", "Average", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_bAverage = (Convert.ToInt32(retval.ToString()) == 1)?true:false;

            GetPrivateProfileString("MarkFill", "Type", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_nType  = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("MarkFill", "Angle", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_nAngle  = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("MarkFill", "Num", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_nNum  = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("MarkFill", "LineSpace", "0.1", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_dLineSpace  = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkFill", "Margin", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_dMargin  = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkFill", "SOffset", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_dSOffset  = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkFill", "EOffset", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_dEOffset  = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkFill", "LineIndent", "0", retval, 20, nFileName);
            ZmcCardPara.m_FillPara.m_dLineIndent  = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkSpiral", "Radio", "1", retval, 20, nFileName);
            ZmcCardPara.m_SpiralRadio = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkSpiral", "Dist", "1", retval, 20, nFileName);
            ZmcCardPara.m_SpiralDist = Convert.ToDouble(retval.ToString());

            GetPrivateProfileString("MarkSpiral", "Accuracy", "0.1", retval, 20, nFileName);
            ZmcCardPara.m_SpiralAccuracy = Convert.ToDouble(retval.ToString());

            //联动参数
            GetPrivateProfileString("LinkAge", "MotorAxisX", "0", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.nMotorAxisX = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorAxisY", "1", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.nMotorAxisY = Convert.ToInt32(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorAccel", "800", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fMotorAcc = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorDecel", "800", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fMotorDec = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorMaxSp", "80", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fMotorMaxSp = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorZsmooth", "0.2", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fMotorZsmooth = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorXlimit", "300", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fMotorXLimit = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "MotorYlimit", "300", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fMotorYLimit = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "XDelayTime", "1000", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fXDelayTime = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "YDelayTime", "1000", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fYDelayTime = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "ScanXlimit", "50", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fScanXLimit = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "ScanYlimit", "50", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fScanYLimit = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "ScanXyAngle", "1000", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.fXyAngle = Convert.ToSingle(retval.ToString());

            GetPrivateProfileString("LinkAge", "Enable", "0", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.bEnable = (Convert.ToInt32(retval.ToString()) == 1) ? true : false;

            GetPrivateProfileString("LinkAge", "DivisionEnable", "0", retval, 20, nFileName);
            ZmcCardPara.m_LinkAgePara.bDivision_Enable = (Convert.ToInt32(retval.ToString()) == 1) ? true : false;


        }

        //写加工配置文件
        public static void Write_MarkCfg(string FilePath)
        {
        
            //SYSTEM配置
            WritePrivateProfileString("System", "MarkCardIpAdrr ", ZmcCardPara.G_MarkCardIpAdrr, FilePath);
            WritePrivateProfileString("System", "TeachFilePath ", ZmcCardPara.TeachFilePath, FilePath);
            WritePrivateProfileString("System", "TeachName ", ZmcCardPara.TeachName, FilePath);

            //MarkPara配置
            string Strval = ZmcCardPara.m_dEmpSpeed.ToString("F3");
            WritePrivateProfileString("MarkPara", "EmpSpeed ", Strval, FilePath);

            Strval = ZmcCardPara.m_dMarkSpeed.ToString("F3");
            WritePrivateProfileString("MarkPara", "MarkSpeed ", Strval, FilePath);

            Strval = ZmcCardPara.m_nPower.ToString();
            WritePrivateProfileString("MarkPara", "MarkPower ", Strval, FilePath);

            Strval = ZmcCardPara.m_nStartDelay.ToString("F3");
            WritePrivateProfileString("MarkPara", "OpenDelay ", Strval, FilePath);

            Strval = ZmcCardPara.m_nLastDelay.ToString("F3");
            WritePrivateProfileString("MarkPara", "CloseDelay ", Strval, FilePath);

            Strval = ZmcCardPara.m_nCorDelay.ToString("F3");
            WritePrivateProfileString("MarkPara", "CornerDelay ", Strval, FilePath);

            Strval = ZmcCardPara.m_nJumpDelay.ToString("F3");
            WritePrivateProfileString("MarkPara", "JumpDelay ", Strval, FilePath);

            Strval = ZmcCardPara.m_nPower.ToString();
            WritePrivateProfileString("MarkPara", "LaserPower ", Strval, FilePath);

            Strval = ZmcCardPara.m_fPwmDuty.ToString("F3");
            WritePrivateProfileString("MarkPara", "m_fPwmDuty ", Strval, FilePath);

            Strval = ZmcCardPara.m_nPwmFreq.ToString("F3");
            WritePrivateProfileString("MarkPara", "m_nPwmFreq ", Strval, FilePath);

            //激光器参数
            Strval = ZmcCardPara.m_nLaserType.ToString();
            WritePrivateProfileString("LaserPara", "Type ", Strval, FilePath);

            Strval = ZmcCardPara.m_nEnableIO.ToString();
            WritePrivateProfileString("LaserPara", "EnableIO ", Strval, FilePath);

            Strval = ZmcCardPara.m_nLaserIO.ToString();
            WritePrivateProfileString("LaserPara", "LaserIO ", Strval, FilePath);

            Strval = ZmcCardPara.m_nRedIO.ToString();
            WritePrivateProfileString("LaserPara", "RedIO ", Strval, FilePath);

            Strval = ZmcCardPara.m_nAout.ToString();
            WritePrivateProfileString("LaserPara", "Aout ", Strval, FilePath);

            Strval = ZmcCardPara.m_nAoutVal.ToString();
            WritePrivateProfileString("LaserPara", "AoutRange ", Strval, FilePath);

            Strval = ZmcCardPara.m_nPwmIo.ToString();
            WritePrivateProfileString("LaserPara", "PwmIo ", Strval, FilePath);

            //轴参数设置保存
            String lpAppName = "";
            for (int iAxis = 0; iAxis < 4; iAxis++)
            {
                lpAppName = "Axis" + iAxis.ToString();
 
                WritePrivateProfileString(lpAppName, "Atype ", ZmcCardPara.m_AxisPara[iAxis].atype.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "Units ", ZmcCardPara.m_AxisPara[iAxis].units.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "Lspeed ", ZmcCardPara.m_AxisPara[iAxis].lspeed.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "Speed ", ZmcCardPara.m_AxisPara[iAxis].speed.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "Accel ", ZmcCardPara.m_AxisPara[iAxis].accel.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "Decel ", ZmcCardPara.m_AxisPara[iAxis].decel.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "Sramp ", ZmcCardPara.m_AxisPara[iAxis].sramp.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "MotorDir ", ZmcCardPara.m_AxisPara[iAxis].MotorDir.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "EndoerDir ", ZmcCardPara.m_AxisPara[iAxis].EncoderDir.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "FsLimit ", ZmcCardPara.m_AxisPara[iAxis].fsLimit.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "RsLimit ", ZmcCardPara.m_AxisPara[iAxis].rsLimit.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "FwdIn ", ZmcCardPara.m_AxisPara[iAxis].fwdIn.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "RevIn ", ZmcCardPara.m_AxisPara[iAxis].revIn.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "AlmIn ", ZmcCardPara.m_AxisPara[iAxis].almIn.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "DatunIn ", ZmcCardPara.m_AxisPara[iAxis].datumIn.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "HomeMode ", ZmcCardPara.m_AxisPara[iAxis].HomeMode.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "HomeSpeed ", ZmcCardPara.m_AxisPara[iAxis].HomeMoveSp.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "HomeLowSp ", ZmcCardPara.m_AxisPara[iAxis].HomeLowSp.ToString("F3"), FilePath);
                WritePrivateProfileString(lpAppName, "HomeOffpos ", ZmcCardPara.m_AxisPara[iAxis].HomeOffpos.ToString("F3"), FilePath);
            }

            //振镜参数设置保存
            WritePrivateProfileString("ScanAxisPara", "ScanID ", ZmcCardPara.m_ScanId.ToString(), FilePath);
            for (int iScan = 0; iScan < 2; iScan++)
            {
                lpAppName = "Scan" + iScan.ToString();
                WritePrivateProfileString(lpAppName, "Units ", ZmcCardPara.m_ScanAxisPara[iScan].units.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "Speed ", ZmcCardPara.m_ScanAxisPara[iScan].speed.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "XyChange ", ZmcCardPara.m_ScanAxisPara[iScan].m_ScanXyChange.ToString(), FilePath);
                WritePrivateProfileString(lpAppName, "CorrectFile ", ZmcCardPara.m_ScanAxisPara[iScan].SscanCorrectFile, FilePath);
            }

            //填充工艺配置
            Strval = ZmcCardPara.m_FillPara.m_bEnable?"1":"0";
            WritePrivateProfileString("MarkFill", "Enbale ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_bOutlineFirst ? "1" : "0";
            WritePrivateProfileString("MarkFill", "OutlineFirst ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_bEdge ? "1" : "0";
            WritePrivateProfileString("MarkFill", "Edge ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_bWhole ? "1" : "0";
            WritePrivateProfileString("MarkFill", "Whole ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_bAverage ? "1" : "0";
            WritePrivateProfileString("MarkFill", "Average ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_nType.ToString();
            WritePrivateProfileString("MarkFill", "Type ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_nAngle.ToString("");
            WritePrivateProfileString("MarkFill", "Angle ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_nNum.ToString();
            WritePrivateProfileString("MarkFill", "Num ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_dLineSpace.ToString("F3");
            WritePrivateProfileString("MarkFill", "LineSpace ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_dMargin.ToString("F3");
            WritePrivateProfileString("MarkFill", "Margin ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_dSOffset.ToString("F3");
            WritePrivateProfileString("MarkFill", "SOffset ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_dEOffset.ToString("F3");
            WritePrivateProfileString("MarkFill", "EOffset ", Strval, FilePath);

            Strval = ZmcCardPara.m_FillPara.m_dLineIndent.ToString("F3");
            WritePrivateProfileString("MarkFill", "LineIndent ", Strval, FilePath);

            Strval = ZmcCardPara.m_SpiralRadio.ToString("F3");
            WritePrivateProfileString("MarkSpiral", "Radio ", Strval, FilePath);

            Strval = ZmcCardPara.m_SpiralDist.ToString("F3");
            WritePrivateProfileString("MarkSpiral", "Dist ", Strval, FilePath);

            Strval = ZmcCardPara.m_SpiralAccuracy.ToString("F3");
            WritePrivateProfileString("MarkSpiral", "Accuracy ", Strval, FilePath);

            //联动设置参数
            Strval = ZmcCardPara.m_LinkAgePara.nMotorAxisX.ToString();
            WritePrivateProfileString("LinkAge", "MotorAxisX ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.nMotorAxisY.ToString();
            WritePrivateProfileString("LinkAge", "MotorAxisY ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fMotorAcc.ToString("F3");
            WritePrivateProfileString("LinkAge", "MotorAccel ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fMotorDec.ToString("F3");
            WritePrivateProfileString("LinkAge", "MotorDecel ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fMotorMaxSp.ToString("F3");
            WritePrivateProfileString("LinkAge", "MotorMaxSp ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fMotorZsmooth.ToString("F3");
            WritePrivateProfileString("LinkAge", "MotorZsmooth ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fMotorXLimit.ToString("F3");
            WritePrivateProfileString("LinkAge", "MotorXlimit ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fMotorYLimit.ToString("F3");
            WritePrivateProfileString("LinkAge", "MotorYlimit ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fXDelayTime.ToString("F3");
            WritePrivateProfileString("LinkAge", "XDelayTime ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fYDelayTime.ToString("F3");
            WritePrivateProfileString("LinkAge", "YDelayTime ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fScanXLimit.ToString("F3");
            WritePrivateProfileString("LinkAge", "ScanXlimit ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fScanYLimit.ToString("F3");
            WritePrivateProfileString("LinkAge", "ScanYlimit ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.fXyAngle.ToString("F3");
            WritePrivateProfileString("LinkAge", "ScanXyAngle ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.bEnable ? "1" : "0";
            WritePrivateProfileString("LinkAge", "Enable ", Strval, FilePath);
            Strval = ZmcCardPara.m_LinkAgePara.bDivision_Enable ? "1" : "0";
            WritePrivateProfileString("LinkAge", "DivisionEnable ", Strval, FilePath);

        }

        //字体下拉
        private void Word_Font_DropDown(object sender, EventArgs e)
        {
            InstalledFontCollection fonts = new InstalledFontCollection();

            Word_Font.Items.Clear();
            foreach (FontFamily family in fonts.Families)
            {
                Word_Font.Items.Add(family.Name);
            }
            Word_Font.SelectedItem = "宋体";
        }

        //定时器刷新状态
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                return;
            }
            int rtn;

            //标刻时间
            float[] MarkTime = {0};
            rtn = zmcaux.ZAux_Direct_GetVrf(ZmcCardPara.G_CardHandle, 0,1,  MarkTime);
            if (MarkTime[0] != 0)
            {
                MarkTime[0] = MarkTime[0] / 1000;
                m_MarkTime = MarkTime[0];

                int ProState = 0;
                rtn = zmcaux.ZAux_Direct_GetTaskStatus(ZmcCardPara.G_CardHandle, 1, ref ProState);
                if (rtn == 0 && ProState == 0 && m_StartStatus == 1)
                {
                    Add_AlmInfo("标刻完成-耗时" + m_MarkTime.ToString() + "ms", 0);
                    m_StartStatus = 0;
                }
            }
          

            //轴参数刷新
            for (int iAxis = 0; iAxis < 8; iAxis++)
            {
                rtn = zmcaux.ZAux_Direct_GetDpos(ZmcCardPara.G_CardHandle, iAxis, ref ZmcCardPara.m_AxisPara[iAxis].dpos);
                rtn = zmcaux.ZAux_Direct_GetIfIdle(ZmcCardPara.G_CardHandle, iAxis, ref ZmcCardPara.m_AxisPara[iAxis].idle);
                rtn = zmcaux.ZAux_Direct_GetAxisStatus(ZmcCardPara.G_CardHandle, iAxis, ref  ZmcCardPara.m_AxisPara[iAxis].status);
            }


            //轴坐标显示
            int iAxisX,iAxisY;
            iAxisX = 0;
            iAxisY = 1;

            Lab_AxisStatus.Text = "平台X:" + ZmcCardPara.m_AxisPara[iAxisX].dpos;
            if(ZmcCardPara.m_AxisPara[iAxisX].idle == 0)
		    {
			    Lab_AxisStatus.Text += " 运行中\t";
		    }
		    else
		    {
                if(ZmcCardPara.m_AxisPara[iAxisX].status  == 0)
                {
			         Lab_AxisStatus.Text += " 停止\t";
                }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x10) == 0x10)
			    {
                     Lab_AxisStatus.Text += " 正限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x20) == 0x20)
			    {
                    Lab_AxisStatus.Text += " 负限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x200) == 0x200)
			    {
                    Lab_AxisStatus.Text += " 正软限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x400) == 0x400)
			    {
                    Lab_AxisStatus.Text += " 负软限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x400000) == 0x400000)
			    {
                    Lab_AxisStatus.Text += " 驱动器报警\t";
			    }
		    }

            Lab_AxisStatus.Text += " \t平台Y:" + ZmcCardPara.m_AxisPara[iAxisY].dpos;
            if(ZmcCardPara.m_AxisPara[iAxisY].idle == 0)
		    {
			    Lab_AxisStatus.Text += " 运行中\t";
		    }
		    else
		    {
                if(ZmcCardPara.m_AxisPara[iAxisY].status  == 0)
                {
			         Lab_AxisStatus.Text += " 停止\t";
                }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x10) == 0x10)
			    {
                     Lab_AxisStatus.Text += " 正限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x20) == 0x20)
			    {
                    Lab_AxisStatus.Text += " 负限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x200) == 0x200)
			    {
                    Lab_AxisStatus.Text += " 正软限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x400) == 0x400)
			    {
                    Lab_AxisStatus.Text += " 负软限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x400000) == 0x400000)
			    {
                    Lab_AxisStatus.Text += " 驱动器报警\t";
			    }
		    }

            //振镜轴坐标显示
            iAxisX = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX;
            Lab_ScanStatus.Text = "振镜X:" + ZmcCardPara.m_AxisPara[iAxisX].dpos;
            if(ZmcCardPara.m_AxisPara[iAxisX].idle == 0)
		    {
                Lab_ScanStatus.Text += " 运行中\t";
		    }
		    else
		    {
                if(ZmcCardPara.m_AxisPara[iAxisX].status  == 0)
                {
                    Lab_ScanStatus.Text += " 停止\t";
                }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x200) == 0x200)
			    {
                    Lab_ScanStatus.Text += " 正软限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisX].status & 0x400) == 0x400)
			    {
                    Lab_ScanStatus.Text += " 负软限位\t";
			    }
		    }

            iAxisY = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY;
            Lab_ScanStatus.Text += " \t振镜Y:" + ZmcCardPara.m_AxisPara[iAxisY].dpos;
            if(ZmcCardPara.m_AxisPara[iAxisY].idle == 0)
		    {
                Lab_ScanStatus.Text += " 运行中\t";
		    }
		    else
		    {
                if(ZmcCardPara.m_AxisPara[iAxisY].status  == 0)
                {
                    Lab_ScanStatus.Text += " 停止\t";
                }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x200) == 0x200)
			    {
                    Lab_ScanStatus.Text += " 正软限位\t";
			    }
			    else if((ZmcCardPara.m_AxisPara[iAxisY].status & 0x400) == 0x400)
			    {
                    Lab_ScanStatus.Text += " 负软限位\t";
			    }
		    }


        }

        //填充选中
        private void FillCheck_CheckedChanged(object sender, EventArgs e)
        {
            Btn_Change_Click(sender,e);
            Make3File();
        }  

        //螺旋线异化选中
        private void SpiralCheck_CheckedChanged(object sender, EventArgs e)
        {
            Btn_Change_Click(sender, e);
            Make3File();
        }

        //选择CAD文件
        private void Btn_OpenCadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "\\";
            openFileDialog1.Filter = "DXF File(*.dxf)|*.dxf|PLT File(*.PLT)|*.PLT|AI File(*.AI)|*.AI|DST File(*.DST)|*.DST";
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.FilterIndex = 1;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)            //打开配置文件
            {
                Cad_FileName.Text  = openFileDialog1.FileName;

                //获取图形范围位置
                IntPtr intPtr;
                intPtr = ZmcLaser.ZMotionCad3_ImportVectGraph(Cad_FileName.Text, 1024, 1, 0.05);

                float Image_Left = 0;
                float Image_bottom = 0;
                float Image_Width = 0;
                float Image_Height = 0;
                int iret = ZmcLaser.ZMotionCad3_GetRange(intPtr, ref Image_Left, ref Image_bottom, ref Image_Width, ref Image_Height, 0.05);
                if (Image_Width < 0.0001 && Image_Height < 0.0001)
                {
                    Image_Left = (float)0.0;
                    Image_bottom = (float)0.0;
                    Image_Width = (float)100.0;
                    Image_Height = (float)100.0;
                }

                Cad_PosX.Text = Image_Left.ToString();
                Cad_PosY.Text = Image_bottom.ToString();
                Cad_Width.Text = Image_Width.ToString();
                Cad_High.Text = Image_Height.ToString();
            }
        }


        //*****************************************************************************************运行相关
        //红光预览
        private void Check_Red_CheckedChanged(object sender, EventArgs e)
        {

        }

        //红光预览轨迹
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            float[] fdist = new float[2];
            int ibuff = 0;          //判断剩余缓冲
            int rtn = zmcaux.ZAux_Direct_GetRemain_LineBuffer(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, ref ibuff);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetRemain_LineBuffer")) return;

            rtn = zmcaux.ZAux_Direct_SetForceSpeed(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, ZmcCardPara.m_dEmpSpeed);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_SetForceSpeed")) return;

            int []m_ScanAxisList = { ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX , ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY };
            if (ibuff > 10)
            {
                fdist[0] = ZmcCardPara.m_GraphRange[0];
                fdist[1] = ZmcCardPara.m_GraphRange[1];
                rtn = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle,2, m_ScanAxisList, fdist);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_MoveScanAbs")) return;

                fdist[0] = ZmcCardPara.m_GraphRange[0] + ZmcCardPara.m_GraphRange[2];
                fdist[1] = ZmcCardPara.m_GraphRange[1];
                rtn = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, m_ScanAxisList, fdist);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_MoveScanAbs")) return;

                fdist[0] = ZmcCardPara.m_GraphRange[0] + ZmcCardPara.m_GraphRange[2];
                fdist[1] = ZmcCardPara.m_GraphRange[1] + ZmcCardPara.m_GraphRange[3];
                rtn = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, m_ScanAxisList, fdist);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_MoveScanAbs")) return;

                fdist[0] = ZmcCardPara.m_GraphRange[0];
                fdist[1] = ZmcCardPara.m_GraphRange[1] + ZmcCardPara.m_GraphRange[3];
                rtn = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2,m_ScanAxisList, fdist);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_MoveScanAbs")) return;

                fdist[0] = ZmcCardPara.m_GraphRange[0] ;
                fdist[1] = ZmcCardPara.m_GraphRange[1] ;
                rtn = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, m_ScanAxisList, fdist);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_MoveScanAbs")) return;
            }
        }

        //标刻
        private void button1_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }
            //停止红光预览
            timer2.Stop();
            timer2.Enabled = false;
            int rtn = zmcaux.ZAux_Direct_Rapidstop(ZmcCardPara.G_CardHandle, 2);  //停止取消运动
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Rapidstop")) return;

            //运行生成的3次文件
            rtn = zmcaux.ZAux_Down3FileRom(ZmcCardPara.G_CardHandle, ".//ZscanLaser.z3p", "Text123.z3p");
            if (ZmcCardPara.CheckError(rtn, "ZAux_Down3FileRom")) return;

            if (LoopRun.Checked)            //连续运动
            {
                ThreadDrawId = new Thread(new ThreadStart(MyThreadFunction));//创建线程
                ThreadDrawId.Start();                                                           //启动线程
                m_StartStatus = 2; 
            }
            else
            {
                rtn = zmcaux.ZAux_Direct_StopTask(ZmcCardPara.G_CardHandle, 1);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_StopTask")) return;
                rtn = zmcaux.ZAux_Run3FileRom(ZmcCardPara.G_CardHandle, "Text123.z3p", 1, 0);                   //任务1运行3次文件
                if (ZmcCardPara.CheckError(rtn, "ZAux_Down3FileRom")) return;
                m_StartStatus = 1;
            }


        }

        //连续标刻线程
        public void MyThreadFunction()
        {
            ThreadFlag = true;
            while (ThreadFlag)
            {
                int ProState = 0;
                int rtn = zmcaux.ZAux_Direct_GetTaskStatus(ZmcCardPara.G_CardHandle,1, ref ProState); 
                if (rtn == 0 && ProState == 0)
                {
                    Add_AlmInfo("标刻完成-耗时" + m_MarkTime.ToString() + "ms",0);
                    Thread.Sleep(100);
                    rtn = zmcaux.ZAux_Run3FileRom(ZmcCardPara.G_CardHandle, "Text123.z3p", 1, 0);                   //任务1运行3次文件
                }
            }

        }

        //停止标刻
        private void button2_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            ThreadFlag = false;
            m_StartStatus = 0;

            int rtn = zmcaux.ZAux_Direct_StopTask(ZmcCardPara.G_CardHandle, 1);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_StopTask")) return;

            rtn = zmcaux.ZAux_Direct_Rapidstop(ZmcCardPara.G_CardHandle, 2);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Rapidstop")) return;

            rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 0);			//关光

        }

        //整机复位
        private void button3_Click(object sender, EventArgs e)
        {
            if (ZmcCardPara.G_CardHandle == (IntPtr)0)
            {
                MessageBox.Show("控制器未连接");
                return;
            }

            button2_Click(sender, e);

            //X回零
            int iAxis = ZmcCardPara.m_LinkAgePara.nMotorAxisX;
            int rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].HomeMoveSp);
            rtn = zmcaux.ZAux_Direct_SetCreep(ZmcCardPara.G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].HomeLowSp);
            rtn = zmcaux.ZAux_Direct_SetParam(ZmcCardPara.G_CardHandle, "DATUM_OFFSET", iAxis, ZmcCardPara.m_AxisPara[iAxis].HomeOffpos);
            rtn = zmcaux.ZAux_Direct_Single_Datum(ZmcCardPara.G_CardHandle, iAxis, 100 + ZmcCardPara.m_AxisPara[iAxis].HomeMode);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_Datum")) return;

            //Y回零
            iAxis = ZmcCardPara.m_LinkAgePara.nMotorAxisY;
            rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].HomeMoveSp);
            rtn = zmcaux.ZAux_Direct_SetCreep(ZmcCardPara.G_CardHandle, iAxis, ZmcCardPara.m_AxisPara[iAxis].HomeLowSp);
            rtn = zmcaux.ZAux_Direct_SetParam(ZmcCardPara.G_CardHandle, "DATUM_OFFSET", iAxis, ZmcCardPara.m_AxisPara[iAxis].HomeOffpos);
            rtn = zmcaux.ZAux_Direct_Single_Datum(ZmcCardPara.G_CardHandle, iAxis, 100 + ZmcCardPara.m_AxisPara[iAxis].HomeMode);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_Datum")) return;

            //振镜回零
            rtn = zmcaux.ZAux_Direct_Single_MoveAbs(ZmcCardPara.G_CardHandle, ZmcCardPara.m_AxisList[0], 0);
            rtn = zmcaux.ZAux_Direct_Single_MoveAbs(ZmcCardPara.G_CardHandle, ZmcCardPara.m_AxisList[1], 0);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_MoveAbs")) return;

        }

        //应用
        private void BTN_SAVE_Click(object sender, EventArgs e)
        {
            ScanDrawList();             //刷新列表显示
            Make3File();                //生成3次文件
        }

        //产品清0
        private void BTN_ZERO_Click(object sender, EventArgs e)
        {
            //m_ProductionNum =0;
            //Text_Count.Text = m_ProductionNum.ToString();
            //Add_AlmInfo("产量清零");


            //调试验证标定精度
            //float[] imginfo = { 0, 0, 0, 0, 0 };
            //ZVisionHelperClass.ZV_IMGINFO(g_handle, grabimg, imginfo);

            //float[] worldpos = { 0, 0 };
            //float[] worldpos1 = { 0, 0 };
            //int ret = ZVisionHelperClass.ZV_CALTRANSW(g_handle, calibparam, 0, imginfo[1] / 2, worldpos);
            //ret = ZVisionHelperClass.ZV_CALTRANSW(g_handle, calibparam, imginfo[0], imginfo[1] / 2, worldpos1);

            //int[] iAxis = { 4, 5 };
            //ret = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, iAxis, worldpos);
            //ret = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, iAxis[0], ZmcCardPara.m_nLaserIO, 1);        //开光
            //ret = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, iAxis, worldpos1);
            //ret = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, iAxis[0], ZmcCardPara.m_nLaserIO, 0);        //开光

            //ret = ZVisionHelperClass.ZV_CALTRANSW(g_handle, calibparam, imginfo[0] / 2, 0, worldpos);
            //ret = ZVisionHelperClass.ZV_CALTRANSW(g_handle, calibparam, imginfo[0] / 2, imginfo[1], worldpos1);
            //ret = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, iAxis, worldpos);
            //ret = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, iAxis[0], ZmcCardPara.m_nLaserIO, 1);        //开光
            //ret = zmcaux.ZAux_Direct_MoveScanAbs(ZmcCardPara.G_CardHandle, 2, iAxis, worldpos1);
            //ret = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, iAxis[0], ZmcCardPara.m_nLaserIO, 0);        //开光
        }

        //GoupBox外观修改
        private void groupBox_Work_Paint(object sender, PaintEventArgs e)
        {
            GroupBox gBox = (GroupBox)sender;

            //e.Graphics.Clear(gBox.BackColor);
            //e.Graphics.DrawString(gBox.Text, gBox.Font, Brushes.Red, 10, 1);
            var vSize = e.Graphics.MeasureString(gBox.Text, gBox.Font);
            e.Graphics.DrawLine(Pens.Black , 1, vSize.Height / 2, 8, vSize.Height / 2);
            e.Graphics.DrawLine(Pens.Black, vSize.Width + 8, vSize.Height / 2, gBox.Width - 2, vSize.Height / 2);
            e.Graphics.DrawLine(Pens.Black, 1, vSize.Height / 2, 1, gBox.Height - 2);
            e.Graphics.DrawLine(Pens.Black, 1, gBox.Height - 2, gBox.Width - 2, gBox.Height - 2);
            e.Graphics.DrawLine(Pens.Black, gBox.Width - 2, vSize.Height / 2, gBox.Width - 2, gBox.Height - 2);
        }
        private void groupBox2_Paint(object sender, PaintEventArgs e)
        {
            GroupBox gBox = (GroupBox)sender;

            //e.Graphics.Clear(gBox.BackColor);
            //e.Graphics.DrawString(gBox.Text, gBox.Font, Brushes.Red, 10, 1);
            var vSize = e.Graphics.MeasureString(gBox.Text, gBox.Font);
            e.Graphics.DrawLine(Pens.Black, 1, vSize.Height / 2, 8, vSize.Height / 2);
            e.Graphics.DrawLine(Pens.Black, vSize.Width + 8, vSize.Height / 2, gBox.Width - 2, vSize.Height / 2);
            e.Graphics.DrawLine(Pens.Black, 1, vSize.Height / 2, 1, gBox.Height - 2);
            e.Graphics.DrawLine(Pens.Black, 1, gBox.Height - 2, gBox.Width - 2, gBox.Height - 2);
            e.Graphics.DrawLine(Pens.Black, gBox.Width - 2, vSize.Height / 2, gBox.Width - 2, gBox.Height - 2);
        }



        //添加报警日志
        public void Add_AlmInfo(string StrInfo,int Level)
        {            
            string msg = "[" + DateTime.Now.ToString() + "] " + StrInfo + "\r\n";

            if(Level == 1)
            {
                TEXT_ALM.SelectionColor = Color.Red;
            }
            else if (Level == 2)
            {
                TEXT_ALM.SelectionColor = Color.Yellow;
            }
            else 
            {
                TEXT_ALM.SelectionColor = Color.Green;
            }

            TEXT_ALM.AppendText(msg);
            TEXT_ALM.ScrollToCaret();
        }
    }
}
