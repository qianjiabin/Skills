﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

/********************************** 激光相关接口 ************************************************
**--------------文件信息--------------------------------------------------------------------------------
**文件名: ZmcLaser
**创建人: wy
**时间: 2022/09/16
**描述: 激光振镜控制器图形相关

**------------修订历史记录----------------------------------------------------------------------------
		

**		   
**------------------------------------------------------------------------------------------------------
********************************************************************************************************/

namespace Zmotion_Laser
{
    public class ZmcLaser
    {
        //填充参数
        public struct Struct_ZLaser_Fill
        {
            [MarshalAs(UnmanagedType.I1)]
            public bool m_bEnable;         //填充使能
            [MarshalAs(UnmanagedType.I1)]
            public bool m_bOutline;        //使能轮廓
            [MarshalAs(UnmanagedType.I1)]
            public bool m_bOutlineFirst;   //轮廓优先
            [MarshalAs(UnmanagedType.I1)]
            public bool m_bWhole;          //是否整体计算
            [MarshalAs(UnmanagedType.I1)]
            public bool m_bEdge;           //是否绕边走一次
            [MarshalAs(UnmanagedType.I1)]
            public bool m_bAverage;        //是否平均分布填充线
            [MarshalAs(UnmanagedType.I4)]
            public int m_nType;            //填充类型
            [MarshalAs(UnmanagedType.I4)]
            public int m_nAngle;           //填充线角度
            [MarshalAs(UnmanagedType.I4)]
            public int m_nNum;             //填充线数目
            [MarshalAs(UnmanagedType.R8)]
            public double m_dLineSpace;    //线间距
            [MarshalAs(UnmanagedType.R8)]
            public double m_dMargin;       //边距
            [MarshalAs(UnmanagedType.R8)]
            public double m_dSOffset;      //开始偏移
            [MarshalAs(UnmanagedType.R8)]
            public double m_dEOffset;      //结束偏移
            [MarshalAs(UnmanagedType.R8)]
            public double m_dLineIndent;   //直线缩进
            //int m_nRingNum;         //边界环数
            //double m_dRingSpace;    //环间距
        };



        public const int ZCAD_ITEMTYPE_VECT = 2000;             //此处开始是曲线类型 
        public const int ZCAD_ITEMTYPE_VECTLine = 2001;
        public const int ZCAD_ITEMTYPE_VECTPoint = 2002;
        public const int ZCAD_ITEMTYPE_VECTEllipse = 2003;
        public const int ZCAD_ITEMTYPE_VECTBezLine = 2004;
        public const int ZCAD_ITEMTYPE_VECTArc = 2005;
        public const int ZCAD_ITEMTYPE_VECTSPLine = 2006;
        public const int ZCAD_ITEMTYPE_VECTText = 2007;


        public struct Struct_ZCad_Array
        {
            [MarshalAs(UnmanagedType.I4)]
            public int m_nGroupNum;    //图层
            [MarshalAs(UnmanagedType.I4)]
            public int m_nItemtype;     //类型

            [MarshalAs(UnmanagedType.I4)]
            public int m_nInVectFrist;  //在曲线中是否为第一个
            [MarshalAs(UnmanagedType.I4)]
            public int m_nEmptyMove;    //是否为空移（点类型使用，表示为空移点）
            [MarshalAs(UnmanagedType.I4)]
            public int m_nIfCloseLine;  //是否闭合线
            [MarshalAs(UnmanagedType.I4)]
            public int m_nChoose;       //是否选中
            [MarshalAs(UnmanagedType.I4)]
            public int m_nGroup;        //群组号

            [MarshalAs(UnmanagedType.I4)]
            public int m_Param1;        // 预留特殊参数
            [MarshalAs(UnmanagedType.I4)]
            public int m_Param2;        // 预留

            public double x1;
            public double y1;
            public double z1;           //（圆弧时表示起始角度）

            public double x2;
            public double y2;
            public double z2;           //（圆弧时表示旋转角度）

            public double m_dGetStartX;
            public double m_dGetStartY; //提取数组获得的图形起点位置（m_nInVectFrist=1时有效）

        };

        //填充参数
        public struct Struct_IntVect_AutoDeal
        {
            [MarshalAs(UnmanagedType.I1)]
            public bool bMerge;        //合并相连线
            [MarshalAs(UnmanagedType.R8)]
            public double bMergeAccuracy;        ///合并项链线的相连精度

        };

        public const int ERROR_ZLASER_OFFSET =   11000;  // CAD产生的错

        public const int ERR_LASER_OK = 0;
        public const int ERR_LASER_PAR =                (ERROR_ZLASER_OFFSET);             //参数为空
        public const int ERR_LASER_PAR_INVALID =        (ERROR_ZLASER_OFFSET+1); //参数无效
        public const int ERR_LASER_PAR_STRLONG  =       (ERROR_ZLASER_OFFSET+2); //文本长度太长
        public const int ERR_LASER_NO_OPEN   =          (ERROR_ZLASER_OFFSET+3); //未开启加工
        public const int ERR_LASER_NO_WORKMANSHIP=      (ERROR_ZLASER_OFFSET+4); //不存在的工艺
        public const int ERR_LASER_NO_TEXT_FONT  =      (ERROR_ZLASER_OFFSET+5); //系统库没有的字体
        public const int ERR_LASER_NOT_FILL=            (ERROR_ZLASER_OFFSET+6); //不能填充
        public const int ERR_LASER_BMP_FILE=            (ERROR_ZLASER_OFFSET+7); //位图文件错误
        public const int ERR_LASER_POWER_OUTPUT=        (ERROR_ZLASER_OFFSET+8); //设置激光功率输出口错误
        public const int ERR_LASER_OUTPUT_OVERLAP=      (ERROR_ZLASER_OFFSET+9); //输出口号重叠
        public const int ERR_LASER_FILE_INVALID=        (ERROR_ZLASER_OFFSET+10); //文件无效(路径错误/文件无效) 


        //***********************************************************打标库接口***********************************************//
        /// <summary>
        /// 设置激光的输出口
        /// </summary>
        /// <param name="nAp">激光开关输出口</param>
        /// <param name="nMo"> 激光使能输出口</param>
        /// <param name="nRed">红光输出口</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetOutput", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetOutput(int nAp, int nMo, int nRed, double dMoDealy);

        /// <summary>
        /// 激光的额外输出口控制处理
        /// </summary>
        /// <param name="nStop">激光急停信号输出口（小于0表示没有急停信号需要处理，大于0表示输出口号）</param>
        /// <param name="nPowerLatch">激光功率修改锁存输出口（小于0表示没有功率修改锁存需要处理，大于0表示输出口号）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetOtherOutDeal", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetOtherOutDeal(int nStop, int nPowerLatch);

        /// <summary>
        /// 振镜轴的设置
        /// </summary>
        /// <param name="nAout"> 振镜X轴的轴号</param>
        /// <param name="nLimits">激光功率的修改范围0 - nLimits</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_AoutInit", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_AoutInit(int nAout, int nLimits);

        /// <summary>
        /// 振镜轴的设置
        /// </summary>
        /// <param name="nScanX">振镜X轴的轴号</param>
        /// <param name="nScanY">振镜Y轴的轴号</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetScanAxis", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetScanAxis (int nScanX, int nScanY);

        /// <summary>
        /// 矢量图形的打标参数设置
        /// </summary>
        /// <param name="nPower">打标的功率</param>
        /// <param name="dFreq">打标的频率</param>
        /// <param name="dMarkSp">打标速度</param>
        /// <param name="dJumpSp">跳转速度</param>
        /// <param name="dOpenDelay">开光延时</param>
        /// <param name="dCloseDelay">关光延时</param>
        /// <param name="dJumpDelay">跳转延时</param>
        /// <param name="dCorAngle">拐角开始角度</param>
        /// <param name="dCorDelay">拐角延时</param>
        /// <param name="dEndDelay">结束延时</param>
        /// <param name="nTechnology">打标工艺编号（1-256）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetVectPar", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetVectPar(int nPower, double dFreq, double dMarkSp, double dJumpSp, double dOpenDelay, 
                                                            double dCloseDelay, double dJumpDelay, double dCorAngle, double dCorDelay, double dEndDelay, int nTechnology);

        /// <summary>
        /// 位图的打标参数设置
        /// </summary>
        /// <param name="nPower">打标的功率</param>
        /// <param name="dFreq">打标的频率</param>
        /// <param name="dMarkSp">打标速度</param>
        /// <param name="dJumpSp">跳转速度</param>
        /// <param name="dOpenDelay">开光延时</param>
        /// <param name="dCloseDelay">关光延时</param>
        /// <param name="dJumpDelay">跳转延时</param>
        /// <param name="dEndDelay">结束延时</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetBmpPar", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetBmpPar(int nPower, double dFreq, double dMarkSp, double dJumpSp, 
                                                           double dOpenDelay, double dCloseDelay, double dJumpDelay, double dEndDelay);

        /// <summary>
        /// 文本状态设置
        /// </summary>
        /// <param name="pStrFont">字体字符串</param>
        /// <param name="bThickness">  字体加粗(true-粗体)</param>
        /// <param name="bItalics">字体倾斜(true-倾斜)</param>
        /// <param name="bUnderline">下划线</param>
        /// <param name="bDelete">删除线</param>
        /// <param name="dHeight">文本高度</param>
        /// <param name="dWidthR">文本宽度比例(0,100]</param>
        /// <param name="dAngle">旋转角度(0-360°)</param>
        /// <param name="dTilt">倾斜角度(0-360°)</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetTextStyle", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetTextStyle(string pStrFont, bool bThickness, bool bItalics, 
                                                            bool bUnderline, bool bDelete, double dHeight, double dWidthR, double dAngle, double dTilt);


        /// <summary>
        /// 位图状态设置
        /// </summary>
        /// <param name="bReversal">位图反转处理</param>
        /// <param name="bGridPoint">位图网点处理</param>
        /// <param name="dBrightness">位图亮度[-1, 1]</param>
        /// <param name="dContrastRatio">位图对比度[-1, 1]</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetBmpStyle", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetBmpStyle(bool bReversal, bool bGridPoint, double dBrightness, double dContrastRatio);


        /// <summary>
        ///  位图加工设置
        /// </summary>
        /// <param name="dDotTime">打点模式，设置小于等于0是表示不进行打点模式，大于0时表示打点的时间，单位us</param>
        /// <param name="dTwoWayDis">双向扫描，设置等于0时表示不进行双向扫描，非0时表示双向扫描的补偿距离，单位mm</param>
        /// <param name="bYScan">Y方向扫描，为true时进行Y方向扫描，false时进行默认的X方向扫描加工</param>
        /// <param name="bPtSpaceDis">点间距错位，是一种减少位图点的处理方式，减去相邻的点使加工更加的简洁，但会一定程度上影响效果</param>
        /// <param name="nBmpScanAdd">位图扫描线增量，加工扫描时位图的像素行增量，例如设置为3，那么第1行像素扫描完成后将直接扫描第4行像素</param>
        /// <param name="nNoScanLowGray">不标刻低灰度值的点，低于该灰度值的点将不进行加工</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetBmpWork", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetBmpWork(double dDotTime, double dTwoWayDis,bool bYScan, bool bPtSpaceDis, int nBmpScanAdd, int nNoScanLowGray);


        /// <summary>
        ///  位图调整点功率
        /// </summary>
        /// <param name="bAdjustPower">调整点功率，非调整点功率时有效的灰度就使用位图参数设置的加工功率、无效的就不进行加工。调整点功率时会按照设置的范围进行功率的改变加工</param>
        /// <param name="nMinPower"> 最小功率，设定的加工灰度范围的最小功率</param>
        /// <param name="nMaxPower">最大功率，设定的加工灰度范围的最大功率</param>
        /// <param name="nMinGray">最小加工灰度，小于该灰度的像素点将不进行加工</param>
        /// <param name="nMaxGray">最大加工灰度，大于该灰度的像素点将不进行加工</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetBmpPower", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetBmpPower(bool bAdjustPower, int nMinPower, int nMaxPower, int nMinGray, int nMaxGray);

        /// <summary>
        /// 设置填充参数
        /// </summary>
        /// <param name="bEnable">填充使能</param>
        /// <param name="bOutline">使能轮廓</param>
        /// <param name="bOutlineFirst">轮廓优先</param>
        /// <param name="bEdge">绕边框走一圈</param>
        /// <param name="bAverage">平均分布填充线</param>
        /// <param name="nType">填充类型</param>
        /// <param name="nAngle">旋转角度</param>
        /// <param name="nNum">填充线数目</param>
        /// <param name="dLineSpace">填充线间距</param>
        /// <param name="dMargin">边距</param>
        /// <param name="dSOffset">开始偏移</param>
        /// <param name="dEOffset">结束偏移</param>
        /// <param name="dLineIndent">直线缩进</param>
        /// <param name="nFillNum">填充编号</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetFillParam", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetFillParam(bool bEnable, bool bOutline, bool bOutlineFirst, bool bWhole,bool bEdge, bool bAverage, int nType, int nAngle, int nNum, double dLineSpace, 
                                                                double dMargin, double dSOffset, double dEOffset, double dLineIndent, int nFillNum);
        /// <summary>
        /// 设置填充参数
        /// </summary>
        /// <param name="FillData">填充数据结构</param>
        /// <param name="nFillNum">填充编号</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetFillObject", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetFillObject(Struct_ZLaser_Fill FillData, int nFillNum);

        /// <summary>
        ///  设置运动字符串方式
        /// </summary>
        /// <param name="nMoveType">运动字符串方式（0-运动指令， 1-运动函数， 其他-运动指令）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetMoveInstruct", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetMoveInstruct(int nMoveType);

        /// <summary>
        /// 设置运动函数的名称
        /// </summary>
        /// <param name="pStrMoveFun">运动函数的名称</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetMoveFunName", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetMoveFunName(string pStrMoveFun);


        /// <summary>
        ///  设置开关光字符串方式
        /// </summary>
        /// <param name="nMoveType">开关光字符串方式（0-运动指令， 1-自定义字符串， 其他-运动指令）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetLightInstruct", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetLightInstruct(int nMoveType);

        /// <summary>
        /// 设置开关光字符串的内容
        /// </summary>
        /// <param name="pStrOpen">开光字符串</param>
        /// <param name="pStrClose">关光字符串</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetLightString", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetLightString(string pStrOpen, string pStrClose);


        /// <summary>
        /// 设置功率修改的有效性
        /// </summary>
        /// <param name="bValid">工艺的功率设置是否有效</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetPowerEnable", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetPowerEnable(bool bValid);

        /// <summary>
        /// 设置功率修改方式
        /// </summary>
        /// <param name="nPowerMode"> 功率模式类型（0-模拟量、1-PWM、2-输出口、3-PWM+控制输出口、4-模拟量+控制输出口）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetPowerMode", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetPowerMode(int nPowerMode);


        /// <summary>
        /// 设置功率的有效范围
        /// </summary>
        /// <param name="nMinPower">最小有效功率范围</param>
        /// <param name="nMaxPower">最大有效功率范围</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetValidPowerLimit", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetValidPowerLimit(int nMinPower, int nMaxPower);

        /// <summary>
        /// 设置PWM输出口编号
        /// </summary>
        /// <param name="nPwmNum">PWM的编号</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetPwmNum", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetPwmNum(int nPwmNum);

        /// <summary>
        /// 设置控制功率的输出口编号
        /// </summary>
        /// <param name="pOutputArr"> 控制功率的输出口数组(数组长度请设置为8(必须))</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetPowerOutArr", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetPowerOutArr(int [] pOutputArr);


        /// <summary>
        /// 设置开关光的有效性
        /// </summary>
        /// <param name="bValid">工艺的开关光设置是否有效</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetTrunOnEnable", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetTrunOnEnable(bool bValid);

        /// <summary>
        /// 设置输出口的范围
        /// </summary>
        /// <param name="nLimit">输出口的范围0-nLimit</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetOutputLimits", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetOutputLimits(int nLimit);

        /// <summary>
        /// 设置导入图形自动优化参数
        /// </summary>
        /// <param name="AutoParam"></param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetIntVectAuto", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetIntVectAuto(Struct_IntVect_AutoDeal AutoParam);


        /// <summary>
        /// 开启三次文件生成
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_OpenFile3", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_OpenFile3(IntPtr handle);

        /// <summary>
        /// 生成加工的三次文件
        /// </summary>
        /// <param name="strFilePath">生成文件的路径</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_CreateFile3", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_CreateFile3(string  strFilePath);

        /// <summary>
        ///  生成加工的字符串
        /// </summary>
        /// <returns>加工字符串</returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetProcessString", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr ZmotionLaser_GetProcessString();

        /// <summary>
        /// 获取加工结束字符串
        /// </summary>
        /// <param name="nRow">生成的加工结束字符串的行数</param>
        /// <returns>加工结束字符串</returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetProEndString", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr ZmotionLaser_GetProEndString(ref int nRow);

        /************************************************************
        Description:    // 获取当前已有的图形轨迹数组
        Input:          //
        Output:         //
                    nArrNum         数组的长度
        Return:         //图形轨迹数组
        *************************************************************/
       //Struct_ZCad_VectArray * __stdcall ZmotionLaser_GetCurVectArray(long &nArrNum);
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetCurVectArray", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr ZmotionLaser_GetCurVectArray(ref long nArrNum);

        /************************************************************
        Description:    // 获取当前已有的图形轨迹数组的长度
        Input:          //
        Output:         //
        Return:         //图形轨迹数组的长度
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetCurVectArrayLen", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_GetCurVectArrayLen();
        

        /************************************************************
        Description:    // 用当前已有的图形设置轨迹数组
        Input:          //
        Output:         //
                    pArray          用于设置轨迹的数组
                    nLenght         数组的最大长度
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetArrayForGraph", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetArrayForGraph(ref Struct_ZCad_Array pArray, int nLenght);

        
        ///************************************************************
        //Description:    // 获取当前填充图形轨迹数组的长度
        //Input:          //
        //Output:         //
        //Return:         //填充后的图形轨迹数组的长度
        //*************************************************************/
        //[DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetCurFillArrayLen", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        //public static extern UInt32 ZmotionLaser_GetCurFillArrayLen();

        ///************************************************************
        //Description:    // 用当前填充的图形设置轨迹数组
        //Input:          //
        //Output:         //
        //            pArray          用于设置轨迹的数组
        //            nLenght         数组的最大长度
        //Return:         //错误码
        //*************************************************************/
        //[DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetArrayForFillGraph", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        //public static extern UInt32 ZmotionLaser_SetArrayForFillGraph(ref Struct_ZCad_Array pArray, int nLenght);

        /// <summary>
        /// 获取当前图形的范围(坐标方向是向上为正)
        /// </summary>
        /// <param name="Left">最右边的位置</param>
        /// <param name="Bottom">最下边的位置</param>
        /// <param name="Wdith">宽度</param>
        /// <param name="Height">高度</param>
        /// <param name="refDistance">精度</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetCurGraphRange", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_GetCurGraphRange(ref float Left, ref float Bottom, ref float Wdith, ref float Height,  double refDistance);


        ///// <summary>
        ///// 获取当前变换处理后图形的范围(坐标方向是向上为正)
        ///// </summary>
        ///// <param name="Left">最右边的位置</param>
        ///// <param name="Bottom">最下边的位置</param>
        ///// <param name="Wdith">宽度</param>
        ///// <param name="Height">高度</param>
        ///// <param name="refDistance">精度</param>
        ///// <returns></returns>
        //[DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetCurChangeGraphRange", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        //public static extern UInt32 ZmotionLaser_GetCurChangeGraphRange(ref float Left, ref float Bottom, ref float Wdith, ref float Height, double refDistance);


        ///// <summary>
        ///// 获取当前变换后（包括填充、异化在内的各种变换）轨迹数组的长度
        ///// </summary>
        ///// <returns>填充后的图形轨迹数组的长度</returns>
        //[DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_GetCurChangeArrayLen", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        //public static extern UInt32 ZmotionLaser_GetCurChangeArrayLen();


        ///// <summary>
        ///// 用当前变换后（包括填充、异化在内的各种变换）的图形设置轨迹数组
        ///// </summary>
        ///// <param name="pArray">用于设置轨迹的数组</param>
        ///// <param name="nLenght">数组的最大长度</param>
        ///// <returns></returns>
        //[DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetArrayForChangeGraph", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        //public static extern UInt32 ZmotionLaser_SetArrayForChangeGraph(ref Struct_ZCad_Array pArray, int nLenght);

        /// <summary>
        ///  清除该dll创建的字符串数据
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_ClearNewString", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_ClearNewString();



        /// <summary>
        /// 清除该dll创建的图形备份数据
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_ClearNewGraph", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_ClearNewGraph();

        /// <summary>
        /// 关闭三次文件生成
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_CloseFile3", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_CloseFile3();

        /// <summary>
        /// 点图形的加工
        /// </summary>
        /// <param name="nTechnology">点加工的工艺参数 </param>
        /// <param name="dX">点的坐标X</param>
        /// <param name="dY">点的坐标Y</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_Point", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_Point(int nTechnology, double dX, double dY);

        /// <summary>
        /// 线段图形的加工
        /// </summary>
        /// <param name="nTechnology">线段加工的工艺参数 </param>
        /// <param name="dSx">线段起点的坐标X</param>
        /// <param name="dSy">线段起点的坐标Y</param>
        /// <param name="dEx">线段终点的坐标X</param>
        /// <param name="dEy">线段终点的坐标Y</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_Line", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_Line(int nTechnology, double dSx, double dSy, double dEx, double dEy);

        /// <summary>
        /// 多线段图形的加工
        /// </summary>
        /// <param name="nTechnology">线段加工的工艺参数</param>
        /// <param name="pdx">线段点的坐标X</param>
        /// <param name="pdy">线段点的坐标Y</param>
        /// <param name="pState">线段的状态（0-加工、1-空移、其他-加工）</param>
        /// <param name="nLineNum"> 线段数目</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_Polyline", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_Polyline(int nTechnology, double []pdx, double []pdy, int []pState, int nLineNum);


        /// <summary>
        /// 圆图形的加工
        /// </summary>
        /// <param name="nTechnology"> 圆加工的工艺参数</param>
        /// <param name="dCenterX"> 圆的中心点坐标X</param>
        /// <param name="dCenterY">圆的中心点坐标Y</param>
        /// <param name="dRadius">圆的半径</param>
        /// <param name="dAccuracy">圆的精度，必须在0.01-0.5之间，大于0.5为0.5，小于0.01为0.01</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_Circle", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_Circle(int nTechnology, double dCenterX, double dCenterY, double dRadius, double dAccuracy);


        /// <summary>
        /// 圆弧的加工
        /// </summary>
        /// <param name="nTechnology">圆弧加工的工艺参数</param>
        /// <param name="dCenterX">圆弧的中心点坐标X</param>
        /// <param name="dCenterY">圆弧的中心点坐标Y</param>
        /// <param name="dRadius">圆弧的半径</param>
        /// <param name="dSAngle">圆弧的开始角度(0-360)</param>
        /// <param name="dArcAngle">圆弧的角度(从开始角度开始到结尾的角度)(-360 ~ 360)</param>
        /// <param name="dAccuracy">圆弧的精度，必须在0.01-0.5之间，大于0.5为0.5，小于0.01为0.01</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_Arc", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_Arc(int nTechnology, double dCenterX, double dCenterY, 
                                                        double dRadius, double dSAngle, double dArcAngle, double dAccuracy);

        /// <summary>
        /// 文本的加工
        /// </summary>
        /// <param name="nTechnology">文本加工的工艺参数</param>
        /// <param name="pStrText"> 文本的内容</param>
        /// <param name="dX">文本的左下角坐标X</param>
        /// <param name="dY">文本的左下角坐标Y</param>
        /// <param name="dAccuracy">文本的精度，在0.01-0.5之间，大于0.5为0.5，小于0.01为0.01</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_Text", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_Text(int nTechnology, string pStrText, double dX, double dY, double dAccuracy);

        /// <summary>
        /// 条码的加工
        /// </summary>
        /// <param name="nTechnology">条码加工的工艺参数</param>
        /// <param name="pStrText">条码的内容</param>
        /// <param name="pStrType">条码的种类</param>
        /// <param name="dX">条码的左下角坐标X</param>
        /// <param name="dY">条码的左下角坐标Y</param>
        /// <param name="dSizeX">条码的宽（X方向的尺寸）</param>
        /// <param name="dSizeY">条码的高（Y方向的尺寸）</param>
        /// <param name="dAngle">条码的旋转角度(0-360°)</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_BarCode", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_BarCode(int nTechnology, string pStrText, string pStrType, 
                                                         double dX, double dY, double dSizeX, double dSizeY, double dAngle);

        /// <summary>
        /// 位图的加工
        /// </summary>
        /// <param name="strFilePath">位图文件的路径</param>
        /// <param name="dX">位图的左下角坐标X</param>
        /// <param name="dY">位图的左下角坐标Y</param>
        /// <param name="dWidth">位图的宽</param>
        /// <param name="dHeight">位图的高</param>
        /// <param name="dAngle">位图的旋转角度(0-360°)</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_FileBmp", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_FileBmp(string  strFilePath, double dX, double dY, double dWidth, double dHeight, double dAngle);


        ///*************************************************************
        //Description:    // 位图的加工
        //Input:          //
        //            pBmpDib         CAD的位图类型结构
        //            dAngle          位图的旋转角度
        //Output:         //
        //Return:         //错误码
        //*************************************************************/
        //uint32 __stdcall ZmotionLaser_DibBmp(Struct_ZCad_Dib *pBmpDib, double dAngle);

        /// <summary>
        ///  矢量图形的加工
        /// </summary>
        /// <param name="strFilePath"> 矢量文件的路径 </param>
        /// <param name="dX">位图的左下角坐标X</param>
        /// <param name="dY">位图的左下角坐标Y</param>
        /// <param name="dWidth">位图的宽</param>
        /// <param name="dHeight">位图的高</param>
        /// <param name="dAngle">位图的旋转角度(0-360°)</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_FileVector", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_FileVector(string  strFilePath, double dX, double dY, double dWidth, double dHeight, double dAngle);



        ///*************************************************************
        //Description:    // 矢量图形的加工
        //Input:          //
        //            pVectGroup      矢量图形的图层列表
        //Output:         //
        //Return:         //错误码
        //*************************************************************/
        //uint32 __stdcall ZmotionLaser_LayerVector(Struct_ZCad_VectGroup * pVectGroup);

        /// <summary>
        /// 填充开始（使用该函数后后续可填充的图形都将进行填充）
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_FillStart", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_FillStart();

        /// <summary>
        /// 填充结束（使用该函数后将结束图形的填充处理）
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_FillEnd", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_FillEnd();

        /// <summary>
        ///  添加用户自己编写的加工字符串
        /// </summary>
        /// <param name="pString">添加加工字符串</param>
        /// <param name="nType">字符串的添加类型（0-直接添加，1-添加到开始，2-添加到结束, 其他-直接添加）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_AddString", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_AddString(string pString, int nType);


        /// <summary>
        /// 进行线段螺旋异化的开启
        /// </summary>
        /// <param name="dRadio">螺旋线半径</param>
        /// <param name="dDis">螺旋线间距</param>
        /// <param name="dAccuracy">螺旋线精度</param>
        /// <param name="bClockwise">是否顺时针螺旋（true-顺时针，false-逆时针）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SpiralStart", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SpiralStart(double dRadio, double dDis, double dAccuracy, bool bClockwise);


        /// <summary>
        /// 结束线段螺旋异化
        /// </summary>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SpiralEnd", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SpiralEnd();


        /// <summary>
        /// 开启运动时间显示（在开光前将运动的时间写入到TABLE中）
        /// </summary>
        /// <param name="nTab"> nTab            写入到的TABLE的位置</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_OpenMoveTimeShow", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_OpenMoveTimeShow(int nTab);

        /// <summary>
        /// 关闭运动时间显示（在开光前将运动的时间写入到TABLE中）
        /// </summary>
        /// <param name="nTab"></param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_CloseMoveTimeShow", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_CloseMoveTimeShow();

        //*********************************************************联动相关
        /// <summary>
        /// 设置平台参数
        /// </summary>
        /// <param name="nAxisX">平台X轴的轴号</param>
        /// <param name="nAxisY">平台Y轴的轴号</param>
        /// <param name="dSpeed">平台的最大速度</param>
        /// <param name="dAccel">平台的加速度</param>
        /// <param name="dDecel">平台的减速度</param>
        /// <param name="dXLinkDelay">平台X轴联动延时</param>
        /// <param name="dYLinkDelay">平台Y轴联动延时</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetPlatParam", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetPlatParam(int nAxisX, int nAxisY, double dSpeed, double dAccel, double dDecel, double dXLinkDelay, double dYLinkDelay);

        /// <summary>
        /// 设置联动参数
        /// </summary>
        /// <param name="nTechnology">联动的加工工艺号</param>
        /// <param name="dUnits">脉冲当量（需要保证平台与振镜的脉冲都是该值）</param>
        /// <param name="dRsX">振镜X轴的负向软限位</param>
        /// <param name="dFsX">振镜X轴的正向软限位</param>
        /// <param name="dRsY">振镜Y轴的负向软限位</param>
        /// <param name="dFsY">振镜Y轴的正向软限位</param>
        /// <param name="dRsPX">平台X轴的负向软限位</param>
        /// <param name="dFsPX">平台X轴的正向软限位</param>
        /// <param name="dRsPY">平台Y轴的负向软限位</param>
        /// <param name="dFsPY">平台Y轴的正向软限位</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_SetLinkagePar", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_SetLinkagePar(int nTechnology, double dUnits, double dRsX,
    double dFsX, double dRsY, double dFsY, double dRsPX, double dFsPX, double dRsPY, double dFsPY);



        /// <summary>
        /// 生成分割拼接联动加工三次文件
        /// </summary>
        /// <param name="strFilePath">生成文件的路径</param>
        /// <param name="bSort"> 是否排序（false-不排序，true-排序）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_CreateDLinkFile3", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_CreateDLinkFile3(string strFilePath, bool bSort);

        // uint32 __stdcall (const char* strFilePath, bool bSort);
        /// <summary>
        /// 生成当前图形联动加工的三次文件
        /// </summary>
        /// <param name="strFilePath">生成文件的路径</param>
        /// <param name="bSort">是否排序（false-不排序，true-排序）</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZmotionLaser_CreateLinkFile3", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern UInt32 ZmotionLaser_CreateLinkFile3(string strFilePath, bool bSort);


        /**************************************************************************************************************
        ***************************************************************************************************************
        *********************************               振镜校正部分             **************************************
        ***************************************************************************************************************
        ***************************************************************************************************************/
        public const int  SYS_STATE_CANNOT_CONNECT  =         50; //链接不上控制器
        public const int  SCAN_CORRECT_TOOFEW_POINTS =        51; //校正点太少
        public const int  SCAN_CORRECT_ERROR_POINTS  =        52; //校正点数不正确
        public const int  SCAN_CORRECT_ERROR_CONTROLLER =     53; //校正失败
        public const int  SCAN_CORRECT_ERROR_FILE =           54; //校正文件错误
        public const int  SCAN_CORRECT_ERROR_NULL =           55; //没有校正数据
        public const int  SCAN_CORRECT_ERROR_PARA =           56; //参数错误


        /*************************************************************
        Description:    // 9点校正
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // pdXMeasurePt 测量的点的X坐标（长度为9）
                        // pdYMeasurePt 测量的点的Y坐标（长度为9）
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nRowColPtNum 行和列方向的点的数量（必须为奇数，建议值为11、21等）
                        // dUnits 振镜轴的脉冲当量
                        // dTheoryLeft dTheoryBottom dTheoryRight dTheoryTop 打标的理论范围
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_Correct9", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_Correct9(IntPtr handle, int nScanNum, double[] pdXMeasurePt, double[] pdYMeasurePt, int nScanExChange, int nRowColPtNum,
            double dUnits, double dTheoryLeft, double dTheoryBottom, double dTheoryRight, double dTheoryTop, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 25点校正
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // pdXMeasurePt 测量的点的X坐标（长度为25）
                        // pdYMeasurePt 测量的点的Y坐标（长度为25）
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nRowColPtNum 行和列方向的点的数量（必须为奇数，建议值为11、21等）
                        // dUnits 振镜轴的脉冲当量
                        // dTheoryLeft dTheoryBottom dTheoryRight dTheoryTop 打标的理论范围
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_Correct25", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_Correct25(IntPtr handle, int nScanNum, double[] pdXMeasurePt, double[] pdYMeasurePt, int nScanExChange, int nRowColPtNum,
            double dUnits, double dTheoryLeft, double dTheoryBottom, double dTheoryRight, double dTheoryTop, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 系数校正
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // dMaxBoxX X方向最大校正区域
                        // dMaxBoxY Y方向最大校正区域
                        // dCorrectBoxX X方向实际校正区域
                        // dCorrectBoxY Y方向实际校正区域
                        // dOffsetX X方向偏移量
                        // dOffsetY Y方向偏移量
                        // pdFactorX X方向校正系数（长度为4，分别为：缩放系数、桶型/枕型畸变系数、平行四边形畸变系数、梯形畸变系数，畸变系数范围-0.3~0.3）
                        // pdFactorY Y方向校正系数（长度为4，分别为：缩放系数、桶型/枕型畸变系数、平行四边形畸变系数、梯形畸变系数，畸变系数范围-0.3~0.3）
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nRowColPtNum 行和列方向的点的数量（必须为奇数，建议值为11、21等）
                        // nXDirect X轴方向（输入1或-1）
                        // nYDirect Y轴方向（输入1或-1）
                        // dUnits 振镜轴的脉冲当量
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_CorrectFactor", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_CorrectFactor(IntPtr handle, int nScanNum, double dMaxBoxX, double dMaxBoxY, double dCorrectBoxX, double dCorrectBoxY, double dOffsetX, double dOffsetY,
            double []pdFactorX, double []pdFactorY, int nScanExChange, int nRowColPtNum, int nXDirect, int nYDirect, double dUnits, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 文件校正
        Input:          // handle 控制器句柄
                        // pFilePath 校正文件绝对路径
                        // nScanNum 振镜编号
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nXDirect X轴方向（输入1或-1）
                        // nYDirect Y轴方向（输入1或-1）
                        // dUnits 振镜轴的脉冲当量
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_CorrectFile", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_CorrectFile(IntPtr handle, string pFilePath, int nScanNum, int nScanExChange, int nXDirect, int nYDirect, double dUnits, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 文件校正（读取参数）
        Input:          // handle 控制器句柄
                        // pFilePath 校正文件绝对路径
                        // nTableStart 点数据存储的起始位置
        Output:         //
                        // pnScanNum 振镜编号
                        // pnScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // pnXDirect X轴方向（输入1或-1）
                        // pnYDirect Y轴方向（输入1或-1）
                        // pdUnits 振镜轴的脉冲当量
                        // pdScaleRatio 缩放倍率                
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_CorrectFileRead", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_CorrectFileRead(IntPtr handle, string pFilePath, ref int nScanNum, ref int nScanExChange, ref int nXDirect, ref int nYDirect, ref double dUnits, ref double dScaleRatio, int nTableStart);


        /*************************************************************
Description:    // 文件校正（新方式，文件中带参数）
Input:          // handle 控制器句柄
                // pFilePath 校正文件绝对路径
                // nTableStart 点数据存储的起始位置
Output:         //            
Return:         //错误码
*************************************************************/
        //int32 __stdcall ZScan_CorrectFile2(ZMC_HANDLE handle, char* pFilePath, int nTableStart);
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_CorrectFile2", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_CorrectFile2(IntPtr handle, string pFilePath,int nTableStart);


        /*************************************************************
        Description:    // 读取新校正文件的参数（新方式）
        Input:          // pFilePath 校正文件绝对路径
        Output:         // nScanNum       振镜编号
                        // nScanExChange  XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nXDirect       X轴方向（输入1或-1）
                        // nYDirect       Y轴方向（输入1或-1）
                        // dUnits         振镜轴的脉冲当量
                        // dScaleRatio    缩放倍率
        Return:         //错误码
        *************************************************************/
        //int32 __stdcall ZScan_ReadFile2Para(char* pFilePath, int &nScanNum, int &nScanExChange, int &nXDirect, int &nYDirect, double &dUnits, double &dScaleRatio);
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_ReadFile2Para", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_ReadFile2Para(string pFilePath, ref int nScanNum, ref int nScanExChange, ref int nXDirect, ref int nYDirect, ref double dUnits, ref double dScaleRatio);


        /*************************************************************
        Description:    // 误差补偿校正（使用校正文件进行校正）
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nXDirect X轴方向（输入1或-1）
                        // nYDirect Y轴方向（输入1或-1）
                        // pCorrectFilePathName 文件校正的文件绝对路径+文件名
                        // dErrData 误差补偿的值（长度为10，数据依次为左下角坐标X，左下角坐标Y，补偿左下角X，左下角Y，右下角X，右下角Y，左上角X，左上角Y，右上角X，右上角Y）
                        // dUnits 振镜轴的脉冲当量
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_ErrCompensationData", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_ErrCompensationData(IntPtr handle,int nScanNum, int nScanExChange, int nXDirect, int nYDirect, string pCorrectFilePathName,
            double[] dErrData, double dUnits, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 误差补偿校正（使用误差补偿文件进行校正）
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nXDirect X轴方向（输入1或-1）
                        // nYDirect Y轴方向（输入1或-1）
                        // pErrFilePathName 误差补偿的文件绝对路径+文件名
                        // dErrData 误差补偿的值（长度为8，补偿左下角X，左下角Y，右下角X，右下角Y，左上角X，左上角Y，右上角X，右上角Y）
                        // dUnits 振镜轴的脉冲当量
                        // dScaleRatio 缩放倍率
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_ErrCompensationFile", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_ErrCompensationFile(IntPtr handle, int nScanNum, int nScanExChange, int nXDirect, int nYDirect, string pErrFilePathName, 
            double []dErrData, double dUnits, double dScaleRatio);

        /*************************************************************
        Description:    // 迭代误差补偿（必须已经进行过校正）
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // nScanExChange XY振镜安装时是否交换了位置(0-未交换，1-交换)
                        // nXDirect X轴方向（输入1或-1）
                        // nYDirect Y轴方向（输入1或-1）
                        // dErrData 误差补偿的值（长度为10，数据依次为左下角坐标X，左下角坐标Y，补偿左下角X，左下角Y，右下角X，右下角Y，左上角X，左上角Y，右上角X，右上角Y）
                        // dUnits 振镜轴的脉冲当量
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_AddErrCompensation", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_AddErrCompensation(IntPtr handle, int nScanNum, int nScanExChange, int nXDirect, int nYDirect, double []dErrData, 
            double dUnits, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 文件校正数据下载到flash（必须已经进行过校正）
        Input:          // handle 控制器句柄
                        // nFlashNum 下载到的flash块号
                        // nFlashStart 下载到的flash起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_DownFile", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_DownFile(IntPtr handle, int nFlashNum, int nFlashStart);

        /*************************************************************
        Description:    // 取消振镜校正
        Input:          // handle 控制器句柄
                        // nScanNum 振镜编号
                        // nXDirect X轴方向（输入1或-1）
                        // nYDirect Y轴方向（输入1或-1）
                        // dUnits 振镜轴的脉冲当量
                        // dScaleRatio 缩放倍率
                        // nTableStart 点数据存储的起始位置
        Output:         //
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_CancelCorrect", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_CancelCorrect(IntPtr handle, int nScanNum, int nXDirect, int nYDirect, double dUnits, double dScaleRatio, int nTableStart);

        /*************************************************************
        Description:    // 文件保存
        Input:          // handle 控制器句柄
        Output:         // pPathName 保存的路径
        Return:         //错误码
        *************************************************************/
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZScan_SaveFile", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZScan_SaveFile(IntPtr handle, string pPathName);

        /// <summary>
        /// 样条转换成小线段
        /// </summary>
        /// <param name="handle">控制器句柄</param>
        /// <param name="pXCp">控制点x坐标数组，参考dxf文件中10编号的值</param>
        /// <param name="pYCp">控制点y坐标数组，参考dxf文件中20编号的值</param>
        /// <param name="pXKp">平滑点x坐标数组，参考dxf文件中11编号的值</param>
        /// <param name="pYKp">平滑点y坐标数组，参考dxf文件中21编号的值</param>
        /// <param name="pKnoteLengh">节长度，每节一个，参考dxf文件中40编号的值</param>
        /// <param name="nCountK">节点数，参考dxf文件中72编号的值</param>
        /// <param name="nCountC">控制点数，参考dxf文件中73编号的值</param>
        /// <param name="IfClose"> 是否闭合，参考dxf文件中70编号的值，1表示闭合，否则输入0</param>
        /// <param name="CurveSPlineType">曲线的类型，参考dxf文件中$SPLINETYPE标识下70的值</param>
        /// <param name="SPLineInsertNum">每一个样条的线段数，参考dxf文件中$SPLINESEGS标识下70的值</param>
        /// <param name="refDistance">参考精度</param>
        /// Output
        /// <param name="pNewXpos">转换后的x坐标数组</param>
        /// <param name="pNewYpos">转换后的y坐标数组</param>
        /// <param name="nGetNum">转换后的点的数量，输入-1时不输出坐标，仅输出转换后的点的数量</param>
        /// <returns>错误码</returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZMotionOptimize_TransSplineSeges", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZMotionOptimize_TransSplineSeges(IntPtr handle, double[] pXCp, double[] pYCp, double[] pXKp, double[] pYKp, double[] pKnoteLengh, int nCountK, int nCountC,
            int IfClose, int CurveSPlineType, int SPLineInsertNum, double refDistance, double[] pNewXpos, double[] pNewYpos, ref int nGetNum);

        /*************************************************************
        Description:    // 贝塞尔转换成小线段
        Input:          //handle     控制器句柄
                        //pXpos      x坐标数组
                        //pYpos      y坐标数组
				        //nPosNum    输入的点的数量
				        //refDistance参考精度
        Output:         //pNewXpos   转换后的x坐标数组
                        //pNewYpos   转换后的y坐标数组
				        //nGetNum    转换后的点的数量，输入-1时不输出坐标，仅输出转换后的点的数量
        Return:         //错误码
        *************************************************************/
        /// <summary>
        /// 贝塞尔转换成小线段
        /// </summary>
        /// <param name="handle">控制器句柄</param>
        /// <param name="pXpos">x坐标数组</param>
        /// <param name="pYpos">y坐标数组</param>
        /// <param name="nPosNum">输入的点的数量</param>
        /// <param name="refDistance">参考精度</param>
        /// Output
        /// <param name="pNewXpos">转换后的x坐标数组</param>
        /// <param name="pNewYpos">转换后的y坐标数组</param>
        /// <param name="nGetNum">转换后的点的数量，输入-1时不输出坐标，仅输出转换后的点的数量</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZMotionOptimize_TransBezierSeges", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZMotionOptimize_TransBezierSeges(IntPtr handle, double[] pXpos, double[] pYpos, int nPosNum, double refDistance, double[] pNewXpos, double[] pNewYpos, ref int nGetNum);

        /// <summary>
        ///  圆/圆弧转换成小线段
        /// </summary>
        /// <param name="handle">控制器句柄</param>
        /// <param name="dXposStart">外接矩形的起点x</param>
        /// <param name="dYposStart">外接矩形的起点y</param>
        /// <param name="dXposEnd">外接矩形的终点x</param>
        /// <param name="dYposEnd">外接矩形的终点y</param>
        /// <param name="dZ1">起始弧度</param>
        /// <param name="dZ2">转过的弧度（顺时针为正，逆时针为负）</param>
        /// <param name="refDistance">参考精度</param>
        /// output
        /// <param name="pNewXpos">转换后的x坐标数组</param>
        /// <param name="pNewYpos">转换后的y坐标数组</param>
        /// <param name="nGetNum">转换后的点的数量，输入-1时不输出坐标，仅输出转换后的点的数量</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZMotionOptimize_TransArcSeges", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZMotionOptimize_TransArcSeges(IntPtr handle, double dXposStart, double dYposStart, double dXposEnd, double dYposEnd, double dZ1, double dZ2,
            double refDistance, double[] pNewXpos, double[] pNewYpos, ref int nGetNum);

        /// <summary>
        /// 椭圆/椭圆弧转换成小线段
        /// </summary>
        /// <param name="handle">控制器句柄</param>
        /// <param name="dXposStart">外接矩形的起点x</param>
        /// <param name="dYposStart">外接矩形的起点y</param>
        /// <param name="dXposEnd">外接矩形的终点x</param>
        /// <param name="dYposEnd">外接矩形的终点y</param>
        /// <param name="dRotate">椭圆旋转的角度</param>
        /// <param name="dSide41">开始参数, 参考dxf文件中41编号的值</param>
        /// <param name="dSide42">结束参数, 参考dxf文件中42编号的值</param>
        /// <param name="dSide230">拉伸方向的Z值，dxf文件中230编号的值</param>
        /// <param name="refDistance">参考精度</param>
        /// Output
        /// <param name="pNewXpos">转换后的x坐标数组</param>
        /// <param name="pNewYpos">转换后的y坐标数组</param>
        /// <param name="nGetNum">转换后的点的数量，输入-1时不输出坐标，仅输出转换后的点的数量</param>
        /// <returns></returns>
        [DllImport("ZmotionScanLaser.dll", EntryPoint = "ZMotionOptimize_TransEllipseSeges", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZMotionOptimize_TransEllipseSeges(IntPtr handle, double dXposStart, double dYposStart, double dXposEnd, double dYposEnd, double dRotate,
            double dSide41, double dSide42, double dSide230, double refDistance, double[] pNewXpos, double[] pNewYpos, ref int nGetNum);

        //    /*************************************************************
        //    Description:    //导入图形文件(支持dxf、plt、ai、dst)
        //    Input:          //
        //                lpszFileFullPathname 路径和文件名
        //                duUnit  PLT的比例
        //                Option   预留， 缺省都转换为seg
        //                refDistance    转换时参考精度
        //    Output:         //
        //    Return:         //错误码
        //*************************************************************/
        [DllImport("ZmotionCad3.dll", EntryPoint = "ZMotionCad3_ImportVectGraph", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern IntPtr  ZMotionCad3_ImportVectGraph(string lpszFileFullPathname, double duUnit, int Option, double refDistance);

        //    /*************************************************************
        //    Description:    // 范围   坐标方向是向上为正
        //    Input:          //
        //    Output:         //
        //    Return:         //错误码
        //    *************************************************************/
        [DllImport("ZmotionCad3.dll", EntryPoint = "ZMotionCad3_GetRange", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern Int32 ZMotionCad3_GetRange(IntPtr intPtr, ref float pLeft, ref float pBottom, ref float pWdith, ref float pHeight, double refDistance);


    }
}
