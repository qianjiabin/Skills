﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Zmc_laser
{
    public partial class FormTechnology : Form
    {
        public FormTechnology()
        {
            InitializeComponent();
        }

        //工艺参数界面加载
        private void FormTechnology_Load(object sender, EventArgs e)
        {
            CtrText_From_Val();
        }

        //变量到控件显示值
        private void CtrText_From_Val()
        {
            //填充参数
            Check_Fill_Edge.Checked = ZmcCardPara.m_FillPara.m_bEdge;
            Check_Fill_Outline.Checked = ZmcCardPara.m_FillPara.m_bOutline;
            Check_Fill_OutLineFirst.Checked = ZmcCardPara.m_FillPara.m_bOutlineFirst;
            Check_Fill_Whole.Checked = ZmcCardPara.m_FillPara.m_bWhole;
            Cbox_Fill_Type.SelectedIndex = ZmcCardPara.m_FillPara.m_nType;
            Check_Fill_Average.Checked = ZmcCardPara.m_FillPara.m_bAverage;
            Text_Fill_Num.Text = ZmcCardPara.m_FillPara.m_nNum.ToString();
            Text_Fill_Angle.Text = ZmcCardPara.m_FillPara.m_nAngle.ToString();
            Text_Fill_Linespace.Text = ZmcCardPara.m_FillPara.m_dLineSpace.ToString();
            Text_Fill_Margin.Text = ZmcCardPara.m_FillPara.m_dMargin.ToString();
            Text_Fill_Soffset.Text = ZmcCardPara.m_FillPara.m_dSOffset.ToString();
            Text_Fill_Eoffset.Text = ZmcCardPara.m_FillPara.m_dEOffset.ToString();
            Text_Fill_LineIndent.Text = ZmcCardPara.m_FillPara.m_dLineIndent.ToString();

            //螺旋线参数
            Text_Spiral_Radio.Text = ZmcCardPara.m_SpiralRadio.ToString();
            Text_Spiral_Dist.Text = ZmcCardPara.m_SpiralDist.ToString();
            Text_Spiral_Accuracy.Text = ZmcCardPara.m_SpiralAccuracy.ToString();

        }

        //控件显示值刷新到变量
        private void CtrText_To_Val()
        {
            ZmcCardPara.m_FillPara.m_bEdge = Check_Fill_Edge.Checked;
            ZmcCardPara.m_FillPara.m_bOutline = Check_Fill_Outline.Checked;
            ZmcCardPara.m_FillPara.m_bOutlineFirst = Check_Fill_OutLineFirst.Checked;
            ZmcCardPara.m_FillPara.m_bWhole = Check_Fill_Whole.Checked;
            ZmcCardPara.m_FillPara.m_nType = Cbox_Fill_Type.SelectedIndex;
            ZmcCardPara.m_FillPara.m_bAverage = Check_Fill_Average.Checked;
            ZmcCardPara.m_FillPara.m_nNum = Convert.ToInt32(Text_Fill_Num.Text);
            ZmcCardPara.m_FillPara.m_nAngle = Convert.ToInt32(Text_Fill_Angle.Text);
            ZmcCardPara.m_FillPara.m_dLineSpace = Convert.ToDouble(Text_Fill_Linespace.Text);
            ZmcCardPara.m_FillPara.m_dMargin = Convert.ToDouble(Text_Fill_Margin.Text);
            ZmcCardPara.m_FillPara.m_dSOffset = Convert.ToDouble(Text_Fill_Soffset.Text);
            ZmcCardPara.m_FillPara.m_dEOffset = Convert.ToDouble(Text_Fill_Eoffset.Text);
            ZmcCardPara.m_FillPara.m_dLineIndent = Convert.ToDouble(Text_Fill_LineIndent.Text);

            //螺旋线参数
            ZmcCardPara.m_SpiralRadio = Convert.ToDouble(Text_Spiral_Radio.Text);
            ZmcCardPara.m_SpiralDist = Convert.ToDouble(Text_Spiral_Dist.Text);
            ZmcCardPara.m_SpiralAccuracy = Convert.ToDouble(Text_Spiral_Accuracy.Text);
        }

        //应用设置到变量
        private void Btn_Set_Click(object sender, EventArgs e)
        {
            CtrText_To_Val();

            FormMain form1 = (FormMain)this.Owner;
            form1.Make3File();
        }
    }
}
