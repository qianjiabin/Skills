﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using cszmcaux;

namespace Zmc_laser
{
    public partial class FormStatus : Form
    {
        public FormStatus()
        {
            InitializeComponent();
        }

        public int m_IoTabPage = 0;

        public int m_MaxIN = 24;                        //当前监控界面输入口数量
        public int m_MaxOut = 20;                       //当前监控界面输出口数量
        public int[] m_InList = new int[48];            //输入口IO列表
        public int[] m_OutList = new int[48];           //输出口IO列表

        public uint[] m_InStatusList = new uint[48];            //
        public uint[] m_OutSattusList = new uint[48];           //

        private void FormStatus_Load(object sender, EventArgs e)
        {
            Scan_LocalIo();
            timer1.Enabled = true;
        }

        private void FormStatus_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Enabled = false;
        }

        //TAB页面被切换
        private void Tab_Status_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPage == tabPage_LocalIO)              //本地IO
            {
                m_IoTabPage = 0;
                Scan_LocalIo();
            }
            else if (e.TabPage == tabPage_LaserIo)         //LASERIO
            {
                m_IoTabPage = 1;
                Scan_LaserIo();
            }
            else if (e.TabPage == tabPage_FiberIo)       //FIBERIO
            {
                m_IoTabPage = 2;
                Scan_ExioIo();
            }

        }

        bool CheckError(int ErrorCode, string CmdString)
        {
            if (0 != ErrorCode)
            {
                MessageBox.Show(CmdString + "ErrorCode:" + ErrorCode);
                return true;
            }
            return false;
        }

        //定时器刷新IO
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (m_IoTabPage == 0)
            {
                Scan_LocalIo();
            }
            else if (m_IoTabPage == 1)
            {

                Scan_LaserIo();
            }
            else if(m_IoTabPage == 2)
            {
                Scan_ExioIo();
            }

        }

        //刷新本地IO显示
        private void Scan_LocalIo()
        {
            m_MaxIN = 24;
            m_MaxOut = 20;
            m_InList = new int[24] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };
            m_OutList = new int[20] { 0, 1, 2, 3, 4, 5, 6, 7, 34, 35, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };

            int rtn = 0;
            for (int iNum = 0; iNum < m_MaxIN; iNum++)           //读取输入口状态
            {
                rtn = zmcaux.ZAux_Direct_GetIn(ZmcCardPara.G_CardHandle, m_InList[iNum], ref  m_InStatusList[iNum]);
                if (CheckError(rtn, "ZAux_Direct_GetIn")) return;
            }

            for (int iNum = 0; iNum < m_MaxOut; iNum++)           //读取输入口状态
            {
                rtn = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, m_OutList[iNum], ref m_OutSattusList[iNum]);
                if (CheckError(rtn, "ZAux_Direct_GetOp")) return;
            }

            for (int iNum = 0; iNum < m_MaxIN; iNum++)           //输入控件显示刷新
            {
                if(m_InStatusList[iNum] == 1)
                {
                    panel1.Controls["LocalIn" + iNum.ToString()].Text = "On";
                    panel1.Controls["LocalIn" + iNum.ToString()].BackColor = Color.Green;
                }
                else
                {

                    panel1.Controls["LocalIn" + iNum.ToString()].Text = "Off";
                    panel1.Controls["LocalIn" + iNum.ToString()].BackColor = Color.Red;
                }

            }

            for (int iNum = 0; iNum < m_MaxOut; iNum++)           //输出控件显示刷新
            {
                if (m_OutSattusList[iNum] == 1)
                {
                    panel2.Controls["Btn_LocalOut" + iNum.ToString()].Text = "On";
                    panel2.Controls["Btn_LocalOut" + iNum.ToString()].BackColor = Color.Green;
                }
                else
                {
                    panel2.Controls["Btn_LocalOut" + iNum.ToString()].Text = "Off";
                    panel2.Controls["Btn_LocalOut" + iNum.ToString()].BackColor = Color.Red;
                }
            }

        }

        //刷新LASER 页面显示
        private void Scan_LaserIo()
        {

            m_MaxIN = 6;
            m_MaxOut = 8;
            m_InList = new int[6] { 44, 45, 46, 47, 48, 49 };
            m_OutList = new int[8] { 28, 29, 30, 31, 32, 33, 8, 9 };

            int rtn = 0;
            for (int iNum = 0; iNum < m_MaxIN; iNum++)           //读取输入口状态
            {
                rtn = zmcaux.ZAux_Direct_GetIn(ZmcCardPara.G_CardHandle, m_InList[iNum], ref  m_InStatusList[iNum]);
                if (CheckError(rtn, "ZAux_Direct_GetIn")) return;
            }

            for (int iNum = 0; iNum < m_MaxOut; iNum++)           //读取输入口状态
            {
                rtn = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, m_OutList[iNum], ref m_OutSattusList[iNum]);
                if (CheckError(rtn, "ZAux_Direct_GetOp")) return;
            }

            for (int iNum = 0; iNum < m_MaxIN; iNum++)           //输入控件显示刷新
            {
                if (m_InStatusList[iNum] == 1)
                {
                    panel3.Controls["LaserIn" + iNum.ToString()].Text = "On";
                    panel3.Controls["LaserIn" + iNum.ToString()].BackColor = Color.Green;
                }
                else
                {

                    panel3.Controls["LaserIn" + iNum.ToString()].Text = "Off";
                    panel3.Controls["LaserIn" + iNum.ToString()].BackColor = Color.Red;
                }

            }

            for (int iNum = 0; iNum < m_MaxOut; iNum++)           //输出控件显示刷新
            {
                if (m_OutSattusList[iNum] == 1)
                {
                    panel4.Controls["Btn_LaserOut" + iNum.ToString()].Text = "On";
                    panel4.Controls["Btn_LaserOut" + iNum.ToString()].BackColor = Color.Green;
                }
                else
                {
                    panel4.Controls["Btn_LaserOut" + iNum.ToString()].Text = "Off";
                    panel4.Controls["Btn_LaserOut" + iNum.ToString()].BackColor = Color.Red;
                }
            }
        }

        //刷新扩展页面显示
        private void Scan_ExioIo()
        {

            m_MaxIN = 3;
            m_MaxOut = 14;
            m_InList = new int[3] { 66, 67, 68 };
            m_OutList = new int[14] { 36, 37, 38, 39, 40, 41, 42, 43, 46, 47, 8, 9, 48, 49 };

            int rtn = 0;
            for (int iNum = 0; iNum < m_MaxIN; iNum++)           //读取输入口状态
            {
                rtn = zmcaux.ZAux_Direct_GetIn(ZmcCardPara.G_CardHandle, m_InList[iNum], ref  m_InStatusList[iNum]);
                if (CheckError(rtn, "ZAux_Direct_GetIn")) return;
            }

            for (int iNum = 0; iNum < m_MaxOut; iNum++)           //读取输入口状态
            {
                rtn = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, m_OutList[iNum], ref m_OutSattusList[iNum]);
                if (CheckError(rtn, "ZAux_Direct_GetOp")) return;
            }

            for (int iNum = 0; iNum < m_MaxIN; iNum++)           //输入控件显示刷新
            {
                if (m_InStatusList[iNum] == 1)
                {
                    panel5.Controls["ExioIn" + iNum.ToString()].Text = "On";
                    panel5.Controls["ExioIn" + iNum.ToString()].BackColor = Color.Green;
                }
                else
                {

                    panel5.Controls["ExioIn" + iNum.ToString()].Text = "Off";
                    panel5.Controls["ExioIn" + iNum.ToString()].BackColor = Color.Red;
                }

            }

            for (int iNum = 0; iNum < m_MaxOut; iNum++)           //输出控件显示刷新
            {
                if (m_OutSattusList[iNum] == 1)
                {
                    panel6.Controls["Btn_ExioOut" + iNum.ToString()].Text = "On";
                    panel6.Controls["Btn_ExioOut" + iNum.ToString()].BackColor = Color.Green;
                }
                else
                {
                    panel6.Controls["Btn_ExioOut" + iNum.ToString()].Text = "Off";
                    panel6.Controls["Btn_ExioOut" + iNum.ToString()].BackColor = Color.Red;
                }
            }
        }

        //按钮按下响应事件
        private void Btn_OutClick(object sender, EventArgs e)
        {
            int rtn = 0;
            Button bt = sender as Button;
            
            if (m_IoTabPage == 0)           //本地IO
            {
                m_MaxOut = 20;
                m_OutList = new int[20] { 0, 1, 2, 3, 4, 5, 6, 7, 34, 35, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
               for (int iNum = 0; iNum < m_MaxOut; iNum++)           
                {
                    if (bt.Name == ("Btn_LocalOut" + iNum.ToString()))
                    {
                        uint istatus = (m_OutSattusList[iNum] == 1) ? (uint)0 : (uint)1;
                        rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, m_OutList[iNum], istatus);
                        if (CheckError(rtn, "ZAux_Direct_GetOp")) return;
                        return;
                    }
                }

            }
            else if (m_IoTabPage == 1)      //LaserIO
            {
                m_MaxOut = 8;
                m_OutList = new int[8] { 28, 29, 30, 31, 32, 33, 8, 9 };
                for (int iNum = 0; iNum < m_MaxOut; iNum++)          
                {
                    if (bt.Name == ("Btn_LaserOut" + iNum.ToString()))
                    {
                        uint istatus = (m_OutSattusList[iNum] == 1) ? (uint)0 : (uint)1;
                        rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, m_OutList[iNum], istatus);
                        if (CheckError(rtn, "ZAux_Direct_GetOp")) return;
                        return;
                    }
                }
            }
            else if (m_IoTabPage == 2)      //ExioIO
            {
                m_MaxOut = 14;
                m_OutList = new int[14] { 36, 37, 38, 39, 40, 41, 42, 43, 46, 47, 8, 9, 48, 49 };
                for (int iNum = 0; iNum < m_MaxOut; iNum++)           
                {
                    if (bt.Name == ("Btn_ExioOut" + iNum.ToString()))
                    {
                        uint istatus = (m_OutSattusList[iNum] == 1) ? (uint)0 : (uint)1;
                        rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, m_OutList[iNum], istatus);
                        if (CheckError(rtn, "ZAux_Direct_GetOp")) return;
                        return;
                    }
                }
            }
        }



    }
}
