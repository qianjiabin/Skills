﻿namespace Zmc_laser
{
    partial class FormTechnology
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.Text_Fill_LineIndent = new System.Windows.Forms.TextBox();
            this.Text_Fill_Eoffset = new System.Windows.Forms.TextBox();
            this.Text_Fill_Soffset = new System.Windows.Forms.TextBox();
            this.Text_Fill_Margin = new System.Windows.Forms.TextBox();
            this.Text_Fill_Linespace = new System.Windows.Forms.TextBox();
            this.Text_Fill_Angle = new System.Windows.Forms.TextBox();
            this.Text_Fill_Num = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.Check_Fill_Average = new System.Windows.Forms.CheckBox();
            this.Cbox_Fill_Type = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.Check_Fill_OutLineFirst = new System.Windows.Forms.CheckBox();
            this.Check_Fill_Outline = new System.Windows.Forms.CheckBox();
            this.Check_Fill_Edge = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Text_Spiral_Accuracy = new System.Windows.Forms.TextBox();
            this.Text_Spiral_Dist = new System.Windows.Forms.TextBox();
            this.Text_Spiral_Radio = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.Btn_Set = new System.Windows.Forms.Button();
            this.Check_Fill_Whole = new System.Windows.Forms.CheckBox();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Check_Fill_Whole);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.Text_Fill_LineIndent);
            this.groupBox4.Controls.Add(this.Text_Fill_Eoffset);
            this.groupBox4.Controls.Add(this.Text_Fill_Soffset);
            this.groupBox4.Controls.Add(this.Text_Fill_Margin);
            this.groupBox4.Controls.Add(this.Text_Fill_Linespace);
            this.groupBox4.Controls.Add(this.Text_Fill_Angle);
            this.groupBox4.Controls.Add(this.Text_Fill_Num);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.Check_Fill_Average);
            this.groupBox4.Controls.Add(this.Cbox_Fill_Type);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.Check_Fill_OutLineFirst);
            this.groupBox4.Controls.Add(this.Check_Fill_Outline);
            this.groupBox4.Controls.Add(this.Check_Fill_Edge);
            this.groupBox4.Location = new System.Drawing.Point(12, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(222, 421);
            this.groupBox4.TabIndex = 31;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "填充工艺";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(182, 355);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 12);
            this.label28.TabIndex = 34;
            this.label28.Text = "mm";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(182, 326);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 12);
            this.label27.TabIndex = 33;
            this.label27.Text = "mm";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(182, 295);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 12);
            this.label26.TabIndex = 32;
            this.label26.Text = "mm";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(182, 264);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 12);
            this.label24.TabIndex = 22;
            this.label24.Text = "mm";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(182, 234);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 12);
            this.label25.TabIndex = 31;
            this.label25.Text = "mm";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(182, 202);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 12);
            this.label23.TabIndex = 21;
            this.label23.Text = "°";
            // 
            // Text_Fill_LineIndent
            // 
            this.Text_Fill_LineIndent.Location = new System.Drawing.Point(89, 352);
            this.Text_Fill_LineIndent.Name = "Text_Fill_LineIndent";
            this.Text_Fill_LineIndent.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_LineIndent.TabIndex = 20;
            this.Text_Fill_LineIndent.Text = "0";
            // 
            // Text_Fill_Eoffset
            // 
            this.Text_Fill_Eoffset.Location = new System.Drawing.Point(89, 321);
            this.Text_Fill_Eoffset.Name = "Text_Fill_Eoffset";
            this.Text_Fill_Eoffset.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_Eoffset.TabIndex = 19;
            this.Text_Fill_Eoffset.Text = "0";
            // 
            // Text_Fill_Soffset
            // 
            this.Text_Fill_Soffset.Location = new System.Drawing.Point(89, 290);
            this.Text_Fill_Soffset.Name = "Text_Fill_Soffset";
            this.Text_Fill_Soffset.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_Soffset.TabIndex = 18;
            this.Text_Fill_Soffset.Text = "0";
            // 
            // Text_Fill_Margin
            // 
            this.Text_Fill_Margin.Location = new System.Drawing.Point(89, 259);
            this.Text_Fill_Margin.Name = "Text_Fill_Margin";
            this.Text_Fill_Margin.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_Margin.TabIndex = 17;
            this.Text_Fill_Margin.Text = "0";
            // 
            // Text_Fill_Linespace
            // 
            this.Text_Fill_Linespace.Location = new System.Drawing.Point(89, 228);
            this.Text_Fill_Linespace.Name = "Text_Fill_Linespace";
            this.Text_Fill_Linespace.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_Linespace.TabIndex = 16;
            this.Text_Fill_Linespace.Text = "0.1";
            // 
            // Text_Fill_Angle
            // 
            this.Text_Fill_Angle.Location = new System.Drawing.Point(89, 197);
            this.Text_Fill_Angle.Name = "Text_Fill_Angle";
            this.Text_Fill_Angle.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_Angle.TabIndex = 15;
            this.Text_Fill_Angle.Text = "0";
            // 
            // Text_Fill_Num
            // 
            this.Text_Fill_Num.Location = new System.Drawing.Point(89, 166);
            this.Text_Fill_Num.Name = "Text_Fill_Num";
            this.Text_Fill_Num.Size = new System.Drawing.Size(90, 21);
            this.Text_Fill_Num.TabIndex = 14;
            this.Text_Fill_Num.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 357);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(59, 12);
            this.label22.TabIndex = 13;
            this.label22.Text = "直线缩进:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 295);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 12);
            this.label21.TabIndex = 12;
            this.label21.Text = "开始偏移:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 326);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 12);
            this.label20.TabIndex = 11;
            this.label20.Text = "结束偏移:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 264);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 12);
            this.label19.TabIndex = 10;
            this.label19.Text = "填充边距:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 233);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 12);
            this.label18.TabIndex = 9;
            this.label18.Text = "填充线间距:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 202);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 12);
            this.label17.TabIndex = 8;
            this.label17.Text = "填充线角度:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 12);
            this.label16.TabIndex = 7;
            this.label16.Text = "填充线数目:";
            // 
            // Check_Fill_Average
            // 
            this.Check_Fill_Average.AutoSize = true;
            this.Check_Fill_Average.Checked = true;
            this.Check_Fill_Average.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Check_Fill_Average.Location = new System.Drawing.Point(14, 133);
            this.Check_Fill_Average.Name = "Check_Fill_Average";
            this.Check_Fill_Average.Size = new System.Drawing.Size(108, 16);
            this.Check_Fill_Average.TabIndex = 6;
            this.Check_Fill_Average.Text = "平均分布填充线";
            this.Check_Fill_Average.UseVisualStyleBackColor = true;
            // 
            // Cbox_Fill_Type
            // 
            this.Cbox_Fill_Type.FormattingEnabled = true;
            this.Cbox_Fill_Type.Items.AddRange(new object[] {
            "单向填充",
            "双向填充",
            "弓形填充",
            "优化弓形填充"});
            this.Cbox_Fill_Type.Location = new System.Drawing.Point(89, 94);
            this.Cbox_Fill_Type.Name = "Cbox_Fill_Type";
            this.Cbox_Fill_Type.Size = new System.Drawing.Size(90, 20);
            this.Cbox_Fill_Type.TabIndex = 5;
            this.Cbox_Fill_Type.Text = "单向填充";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 4;
            this.label15.Text = "填充类型：";
            // 
            // Check_Fill_OutLineFirst
            // 
            this.Check_Fill_OutLineFirst.AutoSize = true;
            this.Check_Fill_OutLineFirst.Location = new System.Drawing.Point(14, 57);
            this.Check_Fill_OutLineFirst.Name = "Check_Fill_OutLineFirst";
            this.Check_Fill_OutLineFirst.Size = new System.Drawing.Size(72, 16);
            this.Check_Fill_OutLineFirst.TabIndex = 3;
            this.Check_Fill_OutLineFirst.Text = "轮廓优先";
            this.Check_Fill_OutLineFirst.UseVisualStyleBackColor = true;
            // 
            // Check_Fill_Outline
            // 
            this.Check_Fill_Outline.AutoSize = true;
            this.Check_Fill_Outline.Location = new System.Drawing.Point(107, 26);
            this.Check_Fill_Outline.Name = "Check_Fill_Outline";
            this.Check_Fill_Outline.Size = new System.Drawing.Size(72, 16);
            this.Check_Fill_Outline.TabIndex = 2;
            this.Check_Fill_Outline.Text = "使能轮廓";
            this.Check_Fill_Outline.UseVisualStyleBackColor = true;
            // 
            // Check_Fill_Edge
            // 
            this.Check_Fill_Edge.AutoSize = true;
            this.Check_Fill_Edge.Location = new System.Drawing.Point(14, 26);
            this.Check_Fill_Edge.Name = "Check_Fill_Edge";
            this.Check_Fill_Edge.Size = new System.Drawing.Size(72, 16);
            this.Check_Fill_Edge.TabIndex = 1;
            this.Check_Fill_Edge.Text = "使能绕边";
            this.Check_Fill_Edge.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Text_Spiral_Accuracy);
            this.groupBox6.Controls.Add(this.Text_Spiral_Dist);
            this.groupBox6.Controls.Add(this.Text_Spiral_Radio);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Location = new System.Drawing.Point(240, 12);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(211, 149);
            this.groupBox6.TabIndex = 57;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "螺旋线异化";
            // 
            // Text_Spiral_Accuracy
            // 
            this.Text_Spiral_Accuracy.Location = new System.Drawing.Point(91, 83);
            this.Text_Spiral_Accuracy.Name = "Text_Spiral_Accuracy";
            this.Text_Spiral_Accuracy.Size = new System.Drawing.Size(90, 21);
            this.Text_Spiral_Accuracy.TabIndex = 72;
            this.Text_Spiral_Accuracy.Text = "0.05";
            // 
            // Text_Spiral_Dist
            // 
            this.Text_Spiral_Dist.Location = new System.Drawing.Point(91, 52);
            this.Text_Spiral_Dist.Name = "Text_Spiral_Dist";
            this.Text_Spiral_Dist.Size = new System.Drawing.Size(90, 21);
            this.Text_Spiral_Dist.TabIndex = 71;
            this.Text_Spiral_Dist.Text = "1";
            // 
            // Text_Spiral_Radio
            // 
            this.Text_Spiral_Radio.Location = new System.Drawing.Point(91, 21);
            this.Text_Spiral_Radio.Name = "Text_Spiral_Radio";
            this.Text_Spiral_Radio.Size = new System.Drawing.Size(90, 21);
            this.Text_Spiral_Radio.TabIndex = 70;
            this.Text_Spiral_Radio.Text = "1";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(14, 26);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 12);
            this.label31.TabIndex = 67;
            this.label31.Text = "螺旋线半径：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(14, 88);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 12);
            this.label29.TabIndex = 69;
            this.label29.Text = "螺旋线精度：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(14, 57);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(77, 12);
            this.label30.TabIndex = 68;
            this.label30.Text = "螺旋线间距：";
            // 
            // Btn_Set
            // 
            this.Btn_Set.Location = new System.Drawing.Point(683, 582);
            this.Btn_Set.Name = "Btn_Set";
            this.Btn_Set.Size = new System.Drawing.Size(75, 23);
            this.Btn_Set.TabIndex = 58;
            this.Btn_Set.Text = "应  用";
            this.Btn_Set.UseVisualStyleBackColor = true;
            this.Btn_Set.Click += new System.EventHandler(this.Btn_Set_Click);
            // 
            // Check_Fill_Whole
            // 
            this.Check_Fill_Whole.AutoSize = true;
            this.Check_Fill_Whole.Location = new System.Drawing.Point(107, 57);
            this.Check_Fill_Whole.Name = "Check_Fill_Whole";
            this.Check_Fill_Whole.Size = new System.Drawing.Size(72, 16);
            this.Check_Fill_Whole.TabIndex = 35;
            this.Check_Fill_Whole.Text = "整体填充";
            this.Check_Fill_Whole.UseVisualStyleBackColor = true;
            // 
            // FormTechnology
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 627);
            this.Controls.Add(this.Btn_Set);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormTechnology";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "工艺参数";
            this.Load += new System.EventHandler(this.FormTechnology_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox Text_Fill_LineIndent;
        private System.Windows.Forms.TextBox Text_Fill_Eoffset;
        private System.Windows.Forms.TextBox Text_Fill_Soffset;
        private System.Windows.Forms.TextBox Text_Fill_Margin;
        private System.Windows.Forms.TextBox Text_Fill_Linespace;
        private System.Windows.Forms.TextBox Text_Fill_Angle;
        private System.Windows.Forms.TextBox Text_Fill_Num;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox Check_Fill_Average;
        private System.Windows.Forms.ComboBox Cbox_Fill_Type;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox Check_Fill_OutLineFirst;
        private System.Windows.Forms.CheckBox Check_Fill_Outline;
        private System.Windows.Forms.CheckBox Check_Fill_Edge;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox Text_Spiral_Accuracy;
        private System.Windows.Forms.TextBox Text_Spiral_Dist;
        private System.Windows.Forms.TextBox Text_Spiral_Radio;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button Btn_Set;
        private System.Windows.Forms.CheckBox Check_Fill_Whole;
    }
}