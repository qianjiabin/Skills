﻿namespace Zmc_laser
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.TEXT_WORKSPEED = new System.Windows.Forms.TextBox();
            this.TEXT_EMPSPEED = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.TEXT_ENDDELAY = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.TEXT_STARTDELAY = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TEXT_CORNERDELAY = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BTN_LASER = new System.Windows.Forms.Button();
            this.BTN_RED = new System.Windows.Forms.Button();
            this.TEXT_FREQ_PWM = new System.Windows.Forms.TextBox();
            this.TEXT_IO_PWM = new System.Windows.Forms.TextBox();
            this.TEXT_VAL_POWER = new System.Windows.Forms.TextBox();
            this.TEXT_AIO_POWER = new System.Windows.Forms.TextBox();
            this.TEXT_IO__RED = new System.Windows.Forms.TextBox();
            this.TEXT_IO_LASER = new System.Windows.Forms.TextBox();
            this.TEXT_IO_ENABLE = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CCBOX_LASER = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Close = new System.Windows.Forms.Button();
            this.btn_Connet = new System.Windows.Forms.Button();
            this.IPADDRESS = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TEXT_WORKSPEED);
            this.groupBox3.Controls.Add(this.TEXT_EMPSPEED);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.TEXT_ENDDELAY);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.TEXT_STARTDELAY);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.TEXT_CORNERDELAY);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(6, 403);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(179, 214);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "运动参数";
            // 
            // TEXT_WORKSPEED
            // 
            this.TEXT_WORKSPEED.Location = new System.Drawing.Point(84, 174);
            this.TEXT_WORKSPEED.Name = "TEXT_WORKSPEED";
            this.TEXT_WORKSPEED.Size = new System.Drawing.Size(58, 21);
            this.TEXT_WORKSPEED.TabIndex = 28;
            this.TEXT_WORKSPEED.Text = "1000";
            // 
            // TEXT_EMPSPEED
            // 
            this.TEXT_EMPSPEED.Location = new System.Drawing.Point(84, 136);
            this.TEXT_EMPSPEED.Name = "TEXT_EMPSPEED";
            this.TEXT_EMPSPEED.Size = new System.Drawing.Size(58, 21);
            this.TEXT_EMPSPEED.TabIndex = 27;
            this.TEXT_EMPSPEED.Text = "3000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 25;
            this.label10.Text = "空移速度";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 178);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 26;
            this.label14.Text = "加工速度";
            // 
            // TEXT_ENDDELAY
            // 
            this.TEXT_ENDDELAY.Location = new System.Drawing.Point(84, 97);
            this.TEXT_ENDDELAY.Name = "TEXT_ENDDELAY";
            this.TEXT_ENDDELAY.Size = new System.Drawing.Size(58, 21);
            this.TEXT_ENDDELAY.TabIndex = 24;
            this.TEXT_ENDDELAY.Text = "1000";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 18;
            this.label13.Text = "拐角延时(us)";
            // 
            // TEXT_STARTDELAY
            // 
            this.TEXT_STARTDELAY.Location = new System.Drawing.Point(84, 59);
            this.TEXT_STARTDELAY.Name = "TEXT_STARTDELAY";
            this.TEXT_STARTDELAY.Size = new System.Drawing.Size(58, 21);
            this.TEXT_STARTDELAY.TabIndex = 23;
            this.TEXT_STARTDELAY.Text = "1000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 63);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 19;
            this.label12.Text = "开光延时(us)";
            // 
            // TEXT_CORNERDELAY
            // 
            this.TEXT_CORNERDELAY.Location = new System.Drawing.Point(84, 21);
            this.TEXT_CORNERDELAY.Name = "TEXT_CORNERDELAY";
            this.TEXT_CORNERDELAY.Size = new System.Drawing.Size(58, 21);
            this.TEXT_CORNERDELAY.TabIndex = 22;
            this.TEXT_CORNERDELAY.Text = "500";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 12);
            this.label11.TabIndex = 20;
            this.label11.Text = "关光延时(us)";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BTN_LASER);
            this.groupBox2.Controls.Add(this.BTN_RED);
            this.groupBox2.Controls.Add(this.TEXT_FREQ_PWM);
            this.groupBox2.Controls.Add(this.TEXT_IO_PWM);
            this.groupBox2.Controls.Add(this.TEXT_VAL_POWER);
            this.groupBox2.Controls.Add(this.TEXT_AIO_POWER);
            this.groupBox2.Controls.Add(this.TEXT_IO__RED);
            this.groupBox2.Controls.Add(this.TEXT_IO_LASER);
            this.groupBox2.Controls.Add(this.TEXT_IO_ENABLE);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.CCBOX_LASER);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(6, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(179, 337);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "激光器参数";
            // 
            // BTN_LASER
            // 
            this.BTN_LASER.Location = new System.Drawing.Point(97, 297);
            this.BTN_LASER.Name = "BTN_LASER";
            this.BTN_LASER.Size = new System.Drawing.Size(75, 23);
            this.BTN_LASER.TabIndex = 17;
            this.BTN_LASER.Text = "激光(关)";
            this.BTN_LASER.UseVisualStyleBackColor = true;
            this.BTN_LASER.Click += new System.EventHandler(this.BTN_LASER_Click);
            // 
            // BTN_RED
            // 
            this.BTN_RED.Location = new System.Drawing.Point(10, 297);
            this.BTN_RED.Name = "BTN_RED";
            this.BTN_RED.Size = new System.Drawing.Size(75, 23);
            this.BTN_RED.TabIndex = 16;
            this.BTN_RED.Text = "红光(关)";
            this.BTN_RED.UseVisualStyleBackColor = true;
            this.BTN_RED.Click += new System.EventHandler(this.BTN_RED_Click);
            // 
            // TEXT_FREQ_PWM
            // 
            this.TEXT_FREQ_PWM.Location = new System.Drawing.Point(83, 264);
            this.TEXT_FREQ_PWM.Name = "TEXT_FREQ_PWM";
            this.TEXT_FREQ_PWM.Size = new System.Drawing.Size(78, 21);
            this.TEXT_FREQ_PWM.TabIndex = 15;
            this.TEXT_FREQ_PWM.Text = "40000";
            // 
            // TEXT_IO_PWM
            // 
            this.TEXT_IO_PWM.Location = new System.Drawing.Point(83, 230);
            this.TEXT_IO_PWM.Name = "TEXT_IO_PWM";
            this.TEXT_IO_PWM.Size = new System.Drawing.Size(78, 21);
            this.TEXT_IO_PWM.TabIndex = 14;
            this.TEXT_IO_PWM.Text = "9";
            // 
            // TEXT_VAL_POWER
            // 
            this.TEXT_VAL_POWER.Location = new System.Drawing.Point(83, 196);
            this.TEXT_VAL_POWER.Name = "TEXT_VAL_POWER";
            this.TEXT_VAL_POWER.Size = new System.Drawing.Size(78, 21);
            this.TEXT_VAL_POWER.TabIndex = 13;
            this.TEXT_VAL_POWER.Text = "128";
            // 
            // TEXT_AIO_POWER
            // 
            this.TEXT_AIO_POWER.Location = new System.Drawing.Point(83, 162);
            this.TEXT_AIO_POWER.Name = "TEXT_AIO_POWER";
            this.TEXT_AIO_POWER.Size = new System.Drawing.Size(78, 21);
            this.TEXT_AIO_POWER.TabIndex = 12;
            this.TEXT_AIO_POWER.Text = "3";
            // 
            // TEXT_IO__RED
            // 
            this.TEXT_IO__RED.Location = new System.Drawing.Point(83, 128);
            this.TEXT_IO__RED.Name = "TEXT_IO__RED";
            this.TEXT_IO__RED.Size = new System.Drawing.Size(78, 21);
            this.TEXT_IO__RED.TabIndex = 11;
            this.TEXT_IO__RED.Text = "48";
            // 
            // TEXT_IO_LASER
            // 
            this.TEXT_IO_LASER.Location = new System.Drawing.Point(83, 94);
            this.TEXT_IO_LASER.Name = "TEXT_IO_LASER";
            this.TEXT_IO_LASER.Size = new System.Drawing.Size(78, 21);
            this.TEXT_IO_LASER.TabIndex = 10;
            this.TEXT_IO_LASER.Text = "8";
            // 
            // TEXT_IO_ENABLE
            // 
            this.TEXT_IO_ENABLE.Location = new System.Drawing.Point(83, 60);
            this.TEXT_IO_ENABLE.Name = "TEXT_IO_ENABLE";
            this.TEXT_IO_ENABLE.Size = new System.Drawing.Size(78, 21);
            this.TEXT_IO_ENABLE.TabIndex = 9;
            this.TEXT_IO_ENABLE.Text = "47";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "频率值";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 234);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "频率IO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "功率值";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "功率AIO";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "红光IO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "出光IO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "使能IO";
            // 
            // CCBOX_LASER
            // 
            this.CCBOX_LASER.FormattingEnabled = true;
            this.CCBOX_LASER.Items.AddRange(new object[] {
            "408-Fiber",
            "408-YLR",
            "408-YAG",
            "504-Fiber"});
            this.CCBOX_LASER.Location = new System.Drawing.Point(83, 26);
            this.CCBOX_LASER.Name = "CCBOX_LASER";
            this.CCBOX_LASER.Size = new System.Drawing.Size(78, 20);
            this.CCBOX_LASER.TabIndex = 1;
            this.CCBOX_LASER.Text = "408-Fiber";
            this.CCBOX_LASER.DropDownClosed += new System.EventHandler(this.CCBOX_LASER_DropDownClosed);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "激光器类型";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Close);
            this.groupBox1.Controls.Add(this.btn_Connet);
            this.groupBox1.Controls.Add(this.IPADDRESS);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(5, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 55);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "控制器链接";
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(304, 20);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(63, 20);
            this.btn_Close.TabIndex = 18;
            this.btn_Close.Text = "断开连接";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_Connet
            // 
            this.btn_Connet.Location = new System.Drawing.Point(201, 20);
            this.btn_Connet.Name = "btn_Connet";
            this.btn_Connet.Size = new System.Drawing.Size(63, 20);
            this.btn_Connet.TabIndex = 17;
            this.btn_Connet.Text = "连接";
            this.btn_Connet.UseVisualStyleBackColor = true;
            this.btn_Connet.Click += new System.EventHandler(this.btn_Connet_Click);
            // 
            // IPADDRESS
            // 
            this.IPADDRESS.FormattingEnabled = true;
            this.IPADDRESS.Location = new System.Drawing.Point(44, 20);
            this.IPADDRESS.Name = "IPADDRESS";
            this.IPADDRESS.Size = new System.Drawing.Size(114, 20);
            this.IPADDRESS.TabIndex = 16;
            this.IPADDRESS.Text = "192.168.0.11";
            this.IPADDRESS.DropDown += new System.EventHandler(this.IPADDRESS_DropDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "IP:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 660);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox TEXT_WORKSPEED;
        private System.Windows.Forms.TextBox TEXT_EMPSPEED;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TEXT_ENDDELAY;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TEXT_STARTDELAY;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TEXT_CORNERDELAY;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BTN_LASER;
        private System.Windows.Forms.Button BTN_RED;
        private System.Windows.Forms.TextBox TEXT_FREQ_PWM;
        private System.Windows.Forms.TextBox TEXT_IO_PWM;
        private System.Windows.Forms.TextBox TEXT_VAL_POWER;
        private System.Windows.Forms.TextBox TEXT_AIO_POWER;
        private System.Windows.Forms.TextBox TEXT_IO__RED;
        private System.Windows.Forms.TextBox TEXT_IO_LASER;
        private System.Windows.Forms.TextBox TEXT_IO_ENABLE;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox CCBOX_LASER;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Button btn_Connet;
        private System.Windows.Forms.ComboBox IPADDRESS;
        private System.Windows.Forms.Label label2;
    }
}

