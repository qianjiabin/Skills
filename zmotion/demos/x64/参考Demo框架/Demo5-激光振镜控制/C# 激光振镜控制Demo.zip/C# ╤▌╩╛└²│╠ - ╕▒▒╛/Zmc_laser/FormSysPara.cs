﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using cszmcaux;
using System.Threading;
using Zmotion_Laser;
using Zmc_laser;

namespace Zmc_laser
{
    public partial class FormSysPara : Form
    {
        public FormSysPara()
        {
            InitializeComponent();
        }

        private void FormSysPara_Load(object sender, EventArgs e)
        {
            Para_To_Ctr();

            CCBOX_LASER_DropDownClosed(sender, e);
            cBoxAxisList_SelectedIndexChanged(sender, e);
        }


        //变量显示到控件
        private void Para_To_Ctr()
        {
            //激光参数
            Ccbox_LaserType.SelectedIndex = ZmcCardPara.m_nLaserType;

            //振镜参数
            CBoxScanID.SelectedIndex = ZmcCardPara.m_ScanId;
            Check_XyChange.Checked = (ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].m_ScanXyChange == 0) ? false : true;
            ZmcCardPara.Sel_ScanAxis();                             //选择振镜轴
            Text_ScanUnits.Text = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].units.ToString();
            Text_ScanSpeed.Text = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed.ToString();
            Text_CorrnetFileName.Text = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile;


            //联动参数
            Text_Linkage_AxisX.Text = ZmcCardPara.m_LinkAgePara.nMotorAxisX.ToString();
            Text_Linkage_AxisY.Text = ZmcCardPara.m_LinkAgePara.nMotorAxisY.ToString();
            Text_Linkage_Acc.Text = ZmcCardPara.m_LinkAgePara.fMotorAcc.ToString();
            Text_Linkage_Dec.Text = ZmcCardPara.m_LinkAgePara.fMotorDec.ToString();
            Text_Linkage_MaxSp.Text = ZmcCardPara.m_LinkAgePara.fMotorMaxSp.ToString();
            Text_Linkage_Zsmooth.Text = ZmcCardPara.m_LinkAgePara.fMotorZsmooth.ToString();
            Text_Linkage_MLlimtX.Text = ZmcCardPara.m_LinkAgePara.fMotorXLimit.ToString();
            Text_Linkage_MLlimtY.Text = ZmcCardPara.m_LinkAgePara.fMotorYLimit.ToString();
            Text_Linkage_XDelay.Text = ZmcCardPara.m_LinkAgePara.fXDelayTime.ToString();
            Text_Linkage_YDelay.Text = ZmcCardPara.m_LinkAgePara.fYDelayTime.ToString();
            Text_Linkage_LimitX.Text = ZmcCardPara.m_LinkAgePara.fScanXLimit.ToString();
            Text_Linkage_LimitY.Text = ZmcCardPara.m_LinkAgePara.fScanYLimit.ToString();
            Text_Linkage_Angle.Text = ZmcCardPara.m_LinkAgePara.fXyAngle.ToString();
            Text_Linkage_Enable.Checked = ZmcCardPara.m_LinkAgePara.bEnable;
            Text_Linkage_Division.Checked = ZmcCardPara.m_LinkAgePara.bDivision_Enable;
        }

        //更新参数到变量
        private void FormSysPara_FormClosed(object sender, FormClosedEventArgs e)
        {
            //联动参数
            ZmcCardPara.m_LinkAgePara.nMotorAxisX = Convert.ToInt32(Text_Linkage_AxisX.Text);
            ZmcCardPara.m_LinkAgePara.nMotorAxisY = Convert.ToInt32(Text_Linkage_AxisY.Text);
            ZmcCardPara.m_LinkAgePara.fMotorAcc = Convert.ToSingle(Text_Linkage_Acc.Text);
            ZmcCardPara.m_LinkAgePara.fMotorDec = Convert.ToSingle(Text_Linkage_Dec.Text);
            ZmcCardPara.m_LinkAgePara.fMotorMaxSp = Convert.ToSingle(Text_Linkage_MaxSp.Text);
            ZmcCardPara.m_LinkAgePara.fMotorZsmooth = Convert.ToSingle(Text_Linkage_Zsmooth.Text);
            ZmcCardPara.m_LinkAgePara.fMotorXLimit = Convert.ToSingle(Text_Linkage_MLlimtX.Text);
            ZmcCardPara.m_LinkAgePara.fMotorYLimit = Convert.ToSingle(Text_Linkage_MLlimtY.Text);
            ZmcCardPara.m_LinkAgePara.fXDelayTime = Convert.ToSingle(Text_Linkage_XDelay.Text);
            ZmcCardPara.m_LinkAgePara.fYDelayTime = Convert.ToSingle(Text_Linkage_YDelay.Text);
            ZmcCardPara.m_LinkAgePara.fScanXLimit = Convert.ToSingle(Text_Linkage_LimitX.Text);
            ZmcCardPara.m_LinkAgePara.fScanYLimit = Convert.ToSingle(Text_Linkage_LimitY.Text);
            ZmcCardPara.m_LinkAgePara.fXyAngle = Convert.ToSingle(Text_Linkage_Angle.Text);
            ZmcCardPara.m_LinkAgePara.bEnable = Text_Linkage_Enable.Checked;
            ZmcCardPara.m_LinkAgePara.bDivision_Enable = Text_Linkage_Division.Checked;

            ZmcCardPara.m_nEnableIO = Convert.ToInt32(Text_Io_Enable.Text);
            ZmcCardPara.m_nLaserIO = Convert.ToInt32(Text_Io_Laser.Text);
            ZmcCardPara.m_nRedIO = Convert.ToInt32(Text_Io__Red.Text);
            ZmcCardPara.m_nAout = Convert.ToInt32(Text_Aio_Port.Text);
            ZmcCardPara.m_nPwmIo = Convert.ToInt32(Text_Io_Pwm.Text);
            ZmcCardPara.m_nAoutVal = Convert.ToInt32(Text_Aout_Range.Text);
        }


        //窗口被切换
        private void tabSysPara_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPage == tabPage_LaserSet)              //
            {

            }
            else if (e.TabPage == tabPage_AxisPara)         //
            {
                ScanAxisParaList();

            }
            else if (e.TabPage == tabPage_ScanPara)       //
            {


            }
        }


        //***************************************************************激光器设置相关***************************************

        //红光
        private void BTN_RED_Click(object sender, EventArgs e)
        {
            UInt32 iOpStatus = 0;
            int iret = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, ref iOpStatus);

            iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, (uint)(iOpStatus == 1 ? 0 : 1));
            if (iOpStatus == 0)
            {
                iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 1);
                Btn_Red.Text = "红光(开)";
            }
            else
            {
                iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 0);
                Btn_Red.Text = "红光(关)";
            }
        }

        //激光
        private void BTN_LASER_Click(object sender, EventArgs e)
        {
            ZmcCardPara.m_nEnableIO = Convert.ToInt32(Text_Io_Enable.Text);
            ZmcCardPara.m_nLaserIO = Convert.ToInt32(Text_Io_Laser.Text);
            ZmcCardPara.m_nRedIO = Convert.ToInt32(Text_Io__Red.Text);
            ZmcCardPara.m_nAout = Convert.ToInt32(Text_Aio_Port.Text);
            ZmcCardPara.m_nPwmIo = Convert.ToInt32(Text_Io_Pwm.Text);
            ZmcCardPara.m_nAoutVal = Convert.ToInt32(Text_Aout_Range.Text);

            UInt32 iOpStatus = 0;
            int iret = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nEnableIO, ref iOpStatus);
            if (iOpStatus == 0)
            {
                iret = zmcaux.ZAux_Direct_SetDA(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nAout, ZmcCardPara.m_nAoutVal);				//设置能量
                iret = zmcaux.ZAux_Direct_SetPwmDuty(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nPwmIo, (float)0.5);		//设置PWM
                iret = zmcaux.ZAux_Direct_SetPwmFreq(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nPwmIo, ZmcCardPara.m_nPwmFreq);		//设置PWM

                iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nEnableIO, 1);				//开光
                Thread.Sleep(10);
                iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 1);
                Btn_Laser.Text = "激光(开)";
            }
            else
            {
                iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 0);				//关光
                Thread.Sleep(10);
                iret = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nEnableIO, 0);
                Btn_Laser.Text = "激光(关)";
            }
        }

        //下拉切换激光器类型
        private void CCBOX_LASER_DropDownClosed(object sender, EventArgs e)
        {
            ZmcCardPara.m_nLaserType = Ccbox_LaserType.SelectedIndex;
            if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.FIBER_408)									//408 FIBER转换板参数设置
            {
                int iresult = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, 0);

                ZmcCardPara.m_nEnableIO = 47;
                ZmcCardPara.m_nLaserIO = 8;
                ZmcCardPara.m_nRedIO = 48;
                ZmcCardPara.m_nAout = 3;
                ZmcCardPara.m_nPwmIo = 9;
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.YLR_408)
            {
                int iresult = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, -1);
                ZmcCardPara.m_nEnableIO = 31;
                ZmcCardPara.m_nLaserIO = 8;
                ZmcCardPara.m_nRedIO = 32;
                ZmcCardPara.m_nAout = 2;
                ZmcCardPara.m_nPwmIo = 9;
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.YAG_408)									//408 YAG转换板参数设置
            {
                int iresult = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, 1);

                ZmcCardPara.m_nEnableIO = 47;
                ZmcCardPara.m_nLaserIO = 8;
                ZmcCardPara.m_nRedIO = 48;
                ZmcCardPara.m_nAout = 3;
                ZmcCardPara.m_nPwmIo = 9;
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.FIBER_504)									//504
            {
                int iresult = zmcaux.ZAux_SetExioType(ZmcCardPara.G_CardHandle, -1);
                ZmcCardPara.m_nEnableIO = 5;
                ZmcCardPara.m_nLaserIO = 6;
                ZmcCardPara.m_nRedIO = 28;
                ZmcCardPara.m_nAout = 2;
                ZmcCardPara.m_nPwmIo = 7;
            }
            else if (ZmcCardPara.m_nLaserType == (int)ZmcCardPara.ZMC_LASER_TYPE.FIBER_408V2)									//504
            {
                int iresult = zmcaux.ZAux_SetLaserSet(ZmcCardPara.G_CardHandle,1,1);
                ZmcCardPara.m_nEnableIO = 47;
                ZmcCardPara.m_nLaserIO = 44;
                ZmcCardPara.m_nRedIO = 48;
                ZmcCardPara.m_nAout = 3;
                ZmcCardPara.m_nPwmIo = 11;
            }

            Text_Io_Enable.Text = ZmcCardPara.m_nEnableIO.ToString();
            Text_Io_Laser.Text = ZmcCardPara.m_nLaserIO.ToString();
            Text_Io__Red.Text = ZmcCardPara.m_nRedIO.ToString();
            Text_Aio_Port.Text = ZmcCardPara.m_nAout.ToString();
            Text_Io_Pwm.Text = ZmcCardPara.m_nPwmIo.ToString();
        }



        //***************************************************************轴参数设置相******************************************
        //刷新显示列表
        public void ScanAxisParaList()
        {
            //AxisParaList.RowHeadersDefaultCellStyle.Padding = new Padding(AxisParaList.RowHeadersWidth);
            if (AxisParaList.RowCount  ==  1)
            {
                for (int i = 0; i < 18; i++)
                {
                    AxisParaList.Rows.Add();
                }

                AxisParaList.Rows[0].HeaderCell.Value = "轴类型";
                AxisParaList.Rows[1].HeaderCell.Value = "脉冲当量";
                AxisParaList.Rows[2].HeaderCell.Value = "起始速度(units/s)";
                AxisParaList.Rows[3].HeaderCell.Value = "运行速度(units/s)";
                AxisParaList.Rows[4].HeaderCell.Value = "加速度(units/s/s)";
                AxisParaList.Rows[5].HeaderCell.Value = "减速度(units/s/s)";
                AxisParaList.Rows[6].HeaderCell.Value = "S曲线(ms)";
                AxisParaList.Rows[7].HeaderCell.Value = "命令方向";
                AxisParaList.Rows[8].HeaderCell.Value = "反馈方向";
                AxisParaList.Rows[9].HeaderCell.Value = "正软限位(units)";
                AxisParaList.Rows[10].HeaderCell.Value = "负软限位(units)";
                AxisParaList.Rows[11].HeaderCell.Value = "正硬限位IO";
                AxisParaList.Rows[12].HeaderCell.Value = "负硬限位IO";
                AxisParaList.Rows[13].HeaderCell.Value = "伺服报警IO";
                AxisParaList.Rows[14].HeaderCell.Value = "原点IO";
                AxisParaList.Rows[15].HeaderCell.Value = "回零模式";
                AxisParaList.Rows[16].HeaderCell.Value = "回零速度(units/s)";
                AxisParaList.Rows[17].HeaderCell.Value = "回零反找速度(units/s)";
                AxisParaList.Rows[18].HeaderCell.Value = "原点偏移(units)";
            }

            for (int iAxis = 0; iAxis < 4; iAxis++)
            {
                AxisParaList.Rows[0].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].atype.ToString("");
                AxisParaList.Rows[1].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].units.ToString("F3");
                AxisParaList.Rows[2].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].lspeed.ToString("F3");
                AxisParaList.Rows[3].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].speed.ToString("F3");
                AxisParaList.Rows[4].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].accel.ToString("F3");
                AxisParaList.Rows[5].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].decel.ToString("F3");
                AxisParaList.Rows[6].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].sramp.ToString("F3");
                AxisParaList.Rows[7].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].MotorDir.ToString("");
                AxisParaList.Rows[8].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].EncoderDir.ToString("");
                AxisParaList.Rows[9].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].fsLimit.ToString("F3");
                AxisParaList.Rows[10].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].rsLimit.ToString("F3");
                AxisParaList.Rows[11].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].fwdIn.ToString("");
                AxisParaList.Rows[12].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].revIn.ToString("");
                AxisParaList.Rows[13].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].almIn.ToString("");
                AxisParaList.Rows[14].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].datumIn.ToString("");
                AxisParaList.Rows[15].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].HomeMode.ToString("");
                AxisParaList.Rows[16].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].HomeMoveSp.ToString("F3");
                AxisParaList.Rows[17].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].HomeLowSp.ToString("F3");
                AxisParaList.Rows[18].Cells[iAxis].Value = ZmcCardPara.m_AxisPara[iAxis].HomeOffpos.ToString("F3");
            }
        }

        //编辑行数据被修改
        private void AxisParaList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
           int iCol =  AxisParaList.CurrentCell.ColumnIndex;            //获取当前行
           int iRow = AxisParaList.CurrentCell.RowIndex;                //或者当前列

           if (iRow <= 18 && iCol <= 3)
           {
               switch (iRow)
               {
                   case 0:
                       ZmcCardPara.m_AxisPara[iCol].atype = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 1:
                       ZmcCardPara.m_AxisPara[iCol].units = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 2:
                       ZmcCardPara.m_AxisPara[iCol].lspeed = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 3:
                       ZmcCardPara.m_AxisPara[iCol].speed = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 4:
                       ZmcCardPara.m_AxisPara[iCol].accel = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 5:
                       ZmcCardPara.m_AxisPara[iCol].decel = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 6:
                       ZmcCardPara.m_AxisPara[iCol].sramp = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 7:
                       ZmcCardPara.m_AxisPara[iCol].MotorDir = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 8:
                       ZmcCardPara.m_AxisPara[iCol].EncoderDir = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 9:
                       ZmcCardPara.m_AxisPara[iCol].fsLimit = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 10:
                       ZmcCardPara.m_AxisPara[iCol].rsLimit = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 11:
                       ZmcCardPara.m_AxisPara[iCol].fwdIn = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 12:
                       ZmcCardPara.m_AxisPara[iCol].revIn = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 13:
                       ZmcCardPara.m_AxisPara[iCol].almIn = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 14:
                       ZmcCardPara.m_AxisPara[iCol].datumIn = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 15:
                       ZmcCardPara.m_AxisPara[iCol].HomeMode = Convert.ToInt32(AxisParaList.CurrentCell.Value);
                       break;
                   case 16:
                       ZmcCardPara.m_AxisPara[iCol].HomeMoveSp = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 17:
                       ZmcCardPara.m_AxisPara[iCol].HomeLowSp = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   case 18:
                       ZmcCardPara.m_AxisPara[iCol].HomeOffpos = Convert.ToSingle(AxisParaList.CurrentCell.Value);
                       break;
                   default:
                       break;

                }
           }

        }

        //轴使能
        private void Btn_AxisEnable_Click(object sender, EventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
            int rtn = 0;
            if (ZmcCardPara.m_AxisPara[m_CurAxis].atype > 10)		//总线轴
            {
                int iEnable = 0;
                rtn = zmcaux.ZAux_Direct_GetAxisEnable(ZmcCardPara.G_CardHandle, m_CurAxis, ref iEnable);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetAxisEnable")) return;

                iEnable = (iEnable == 0) ? 1 : 0;
                rtn = zmcaux.ZAux_Direct_SetAxisEnable(ZmcCardPara.G_CardHandle, m_CurAxis, iEnable);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_SetAxisEnable")) return;

                if (iEnable == 0)
                {
                    Btn_AxisEnable.Text = "使能(关)";
                }
                else
                {
                    Btn_AxisEnable.Text = "使能(开)";
                }

            }
            else									//脉冲轴
            {
                UInt32 uEnable = 0;
                rtn = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, 20 + m_CurAxis, ref uEnable);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetOP")) return;


                uEnable = (UInt32)((uEnable == 0) ? 1 : 0);
                rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, 20 + m_CurAxis, uEnable);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_SetOp")) return;

                if (uEnable == 0)
                {
                    Btn_AxisEnable.Text = "使能(关)";
                }
                else
                {
                    Btn_AxisEnable.Text = "使能(开)";
                }
            }
        }

        //轴回零
        private void Btn_AxisHome_Click(object sender, EventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
			int AxisIdle = 0;
			int rtn = zmcaux.ZAux_Direct_GetIfIdle(ZmcCardPara.G_CardHandle,m_CurAxis,ref AxisIdle);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetIfIdle")) return;		

			if(AxisIdle == -1)		
			{
                rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, m_CurAxis, ZmcCardPara.m_AxisPara[m_CurAxis].HomeMoveSp);
                rtn = zmcaux.ZAux_Direct_SetCreep(ZmcCardPara.G_CardHandle, m_CurAxis, ZmcCardPara.m_AxisPara[m_CurAxis].HomeLowSp);
                rtn = zmcaux.ZAux_Direct_SetParam(ZmcCardPara.G_CardHandle, "DATUM_OFFSET", m_CurAxis, ZmcCardPara.m_AxisPara[m_CurAxis].HomeOffpos);
                rtn = zmcaux.ZAux_Direct_Single_Datum(ZmcCardPara.G_CardHandle, m_CurAxis, 100 + ZmcCardPara.m_AxisPara[m_CurAxis].HomeMode);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_Datum")) return;
			}
        }

        //轴停止
        private void Btn_AxisStop_Click(object sender, EventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
			int rtn = zmcaux.ZAux_Direct_Single_Cancel(ZmcCardPara.G_CardHandle,m_CurAxis,2);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_Cancel")) return;
        }

        //负向运动按下
        private void Btn_AxisRev_MouseDown(object sender, MouseEventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
			int rtn =0;
			if(Check_MoveMode.Checked)
			{
				int AxisIdle = 0;
				rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle,m_CurAxis,ZmcCardPara.m_AxisPara[m_CurAxis].speed);
				rtn = zmcaux.ZAux_Direct_GetIfIdle(ZmcCardPara.G_CardHandle,m_CurAxis,ref AxisIdle);
				if(ZmcCardPara.CheckError(rtn,"ZAux_Direct_GetIfIdle")) return;		
				if(AxisIdle == -1)		
				{
					rtn = zmcaux.ZAux_Direct_Single_Move(ZmcCardPara.G_CardHandle,m_CurAxis,-1*Convert.ToSingle(Text_Dist.Text));
				}
			}
			else
			{
				rtn = zmcaux.ZAux_Direct_Single_Vmove(ZmcCardPara.G_CardHandle,m_CurAxis,-1);
			}
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Singl_move")) return;
        }

        //负向运动松开
        private void Btn_AxisRev_MouseUp(object sender, MouseEventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
            int rtn = zmcaux.ZAux_Direct_Single_Cancel(ZmcCardPara.G_CardHandle, m_CurAxis, 2);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_Cancel")) return;
        }

        //正向运动松开
        private void Btn_AxisFwd_MouseUp(object sender, MouseEventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
            int rtn = zmcaux.ZAux_Direct_Single_Cancel(ZmcCardPara.G_CardHandle, m_CurAxis, 2);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_Cancel")) return;
        }

        //正向运动按下
        private void Btn_AxisFwd_MouseDown(object sender, MouseEventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
            int rtn = 0;
            if (Check_MoveMode.Checked)
            {
                int AxisIdle = 0;
                rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, m_CurAxis, ZmcCardPara.m_AxisPara[m_CurAxis].speed);
                rtn = zmcaux.ZAux_Direct_GetIfIdle(ZmcCardPara.G_CardHandle, m_CurAxis, ref AxisIdle);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetIfIdle")) return;
                if (AxisIdle == -1)
                {
                    rtn = zmcaux.ZAux_Direct_Single_Move(ZmcCardPara.G_CardHandle, m_CurAxis, Convert.ToSingle(Text_Dist.Text));
                }
            }
            else
            {
                rtn = zmcaux.ZAux_Direct_Single_Vmove(ZmcCardPara.G_CardHandle, m_CurAxis, 1);
            }
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Singl_move")) return;
        }

        //轴号被切换
        private void cBoxAxisList_SelectedIndexChanged(object sender, EventArgs e)
        {
            int m_CurAxis = Convert.ToInt32(cBoxAxisList.Text);
            int rtn = 0;
            if (ZmcCardPara.m_AxisPara[m_CurAxis].atype > 10)		//总线轴
            {
                int iEnable = 0;
                rtn = zmcaux.ZAux_Direct_GetAxisEnable(ZmcCardPara.G_CardHandle, m_CurAxis, ref iEnable);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetAxisEnable")) return;

                if (iEnable == 0)
                {
                    Btn_AxisEnable.Text = "使能(关)";
                }
                else
                {
                    Btn_AxisEnable.Text = "使能(开)";
                }

            }
            else									//脉冲轴
            {
                UInt32 uEnable = 0;
                rtn = zmcaux.ZAux_Direct_GetOp(ZmcCardPara.G_CardHandle, 20 + m_CurAxis, ref uEnable);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetOP")) return;

                if (uEnable == 0)
                {
                    Btn_AxisEnable.Text = "使能(关)";
                }
                else
                {
                    Btn_AxisEnable.Text = "使能(开)";
                }
            }
        }

        //刷新轴参数
        private void Btn_Scan_Click(object sender, EventArgs e)
        {
            ZmcCardPara.Read_AxisPara();
            ScanAxisParaList();
        }

        //应用配置轴参数
        private void Btn_Set_Click(object sender, EventArgs e)
        {
            ZmcCardPara.Set_AxisPara();
        }


        //***************************************************************振镜轴参数设置相*************************************

        //应用配置振镜参数
        private void Btn_ScanSet_Click(object sender, EventArgs e)
        {
            ZmcCardPara.m_ScanId = CBoxScanID.SelectedIndex;
            ZmcCardPara.Sel_ScanAxis();                             //选择振镜轴

            ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].units = Convert.ToSingle(Text_ScanUnits.Text);
            ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed = Convert.ToSingle(Text_ScanSpeed.Text);


            int rtn = zmcaux.ZAux_Direct_SetAtype(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, 21);
            rtn = zmcaux.ZAux_Direct_SetUnits(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, Convert.ToSingle(Text_ScanUnits.Text));
            rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX, Convert.ToSingle(Text_ScanSpeed.Text));

            rtn = zmcaux.ZAux_Direct_SetAtype(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY, 21);
            rtn = zmcaux.ZAux_Direct_SetUnits(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY, Convert.ToSingle(Text_ScanUnits.Text));
            rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY, Convert.ToSingle(Text_ScanSpeed.Text));

        }

        //振镜轴反转按下
        private void Btn_ScanRev_MouseDown(object sender, MouseEventArgs e)
        {
            int[] m_CurAxis = new int[1];
            float[] m_fDist = new float[1];
            if(CBoxScanAxis.SelectedIndex == 0)
            {
                m_CurAxis[0] = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX;
            }
            else
            {
                m_CurAxis[0] = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY;
            }
           
            int rtn = 0;
            if (Check_ModeSCan.Checked)
            {
                int AxisIdle = 0;
                rtn = zmcaux.ZAux_Direct_SetForceSpeed(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed);
                rtn = zmcaux.ZAux_Direct_GetIfIdle(ZmcCardPara.G_CardHandle, m_CurAxis[0], ref AxisIdle);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetIfIdle")) return;
                if (AxisIdle == -1)
                {

                    if (RadioRed.Checked)
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nRedIO, 1);		//红光
                    }
                    else
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nLaserIO, 1);		//开光
                    }

                    m_fDist[0] = -1 * Convert.ToSingle(Text_ScanStep.Text);
                    rtn = zmcaux.ZAux_Direct_MoveScan(ZmcCardPara.G_CardHandle, 1, m_CurAxis, m_fDist);

                    if (RadioRed.Checked)
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nRedIO, 0);		//红光
                    }
                    else
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nLaserIO, 0);		//开光
                    }
                }
            }
            else
            {

                rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed);

                if (RadioRed.Checked)
                {
                    rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 1);		//红光
                }
                else
                {
                    rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 1);		//开光
                }

                rtn = zmcaux.ZAux_Direct_Single_Vmove(ZmcCardPara.G_CardHandle, m_CurAxis[0], -1);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Singl_move")) return;
            }          
        }

        //振镜轴反转松开
        private void Btn_ScanRev_MouseUp(object sender, MouseEventArgs e)
        {

            int m_CurScanAxis = 4;
            if (CBoxScanAxis.SelectedIndex == 0)
            {
                m_CurScanAxis = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX;
            }
            else
            {
                m_CurScanAxis = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY;
            }


            int rtn = zmcaux.ZAux_Direct_Single_Cancel(ZmcCardPara.G_CardHandle, m_CurScanAxis, 2);
            if (RadioRed.Checked)
            {
                //rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 0);		//红光
            }
            else
            {
                rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 0);		//开光
            }
        }

        //振镜轴正转按下
        private void Btn_ScanFwd_MouseDown(object sender, MouseEventArgs e)
        {
            int[] m_CurAxis = new int[1];
            float[] m_fDist = new float[1];
            if (CBoxScanAxis.SelectedIndex == 0)
            {
                m_CurAxis[0] = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX;
            }
            else
            {
                m_CurAxis[0] = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY;
            }
            int rtn = 0;
            if (Check_ModeSCan.Checked)
            {
                int AxisIdle = 0;
                rtn = zmcaux.ZAux_Direct_SetForceSpeed(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed);
                rtn = zmcaux.ZAux_Direct_GetIfIdle(ZmcCardPara.G_CardHandle, m_CurAxis[0], ref AxisIdle);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_GetIfIdle")) return;
                if (AxisIdle == -1)
                {

                    if (RadioRed.Checked)
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nRedIO, 1);		//红光
                    }
                    else
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nLaserIO, 1);		//开光
                    }

                    m_fDist[0] = Convert.ToSingle(Text_ScanStep.Text);
                    rtn = zmcaux.ZAux_Direct_MoveScan(ZmcCardPara.G_CardHandle, 1, m_CurAxis, m_fDist);

                    if (RadioRed.Checked)
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nRedIO, 0);		//红光
                    }
                    else
                    {
                        rtn = zmcaux.ZAux_Direct_MoveOp(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_nLaserIO, 0);		//开光
                    }
                }
            }
            else
            {

                rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, m_CurAxis[0], ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed);

                if (RadioRed.Checked)
                {
                    rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 1);		//红光
                }
                else
                {
                    rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 1);		//开光
                }

                rtn = zmcaux.ZAux_Direct_Single_Vmove(ZmcCardPara.G_CardHandle, m_CurAxis[0], 1);
                if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Singl_move")) return;
            }

        }

        //振镜轴正转松开
        private void Btn_ScanFwd_MouseUp(object sender, MouseEventArgs e)
        {
            int m_CurScanAxis = 4;
            if (CBoxScanAxis.SelectedIndex == 0)
            {
                m_CurScanAxis = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX;
            }
            else
            {
                m_CurScanAxis = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY;
            }
            int rtn = zmcaux.ZAux_Direct_Single_Cancel(ZmcCardPara.G_CardHandle, m_CurScanAxis, 2);
            if (RadioRed.Checked)
            {
                //rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 0);		//红光
            }
            else
            {
                rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 0);		//开光
            }
        }


        //振镜轴回零
        private void Btn_ScanHome_Click(object sender, EventArgs e)
        {
            int m_CurScanAxis = 4;
            if (CBoxScanAxis.SelectedIndex == 0)
            {
                m_CurScanAxis = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisX;
            }
            else
            {
                m_CurScanAxis = ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].AxisY;
            }
            int rtn = zmcaux.ZAux_Direct_SetSpeed(ZmcCardPara.G_CardHandle, m_CurScanAxis, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].speed);
            rtn = zmcaux.ZAux_Direct_Single_MoveAbs(ZmcCardPara.G_CardHandle, m_CurScanAxis, 0);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Single_MoveAbs")) return;
        }

        //振镜轴停止
        private void Btn_ScanStop_Click(object sender, EventArgs e)
        {
            int rtn = zmcaux.ZAux_Direct_Rapidstop(ZmcCardPara.G_CardHandle, 2);
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Rapidstop")) return;

            rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nRedIO, 0);				//关红光
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Rapidstop")) return;
            rtn = zmcaux.ZAux_Direct_SetOp(ZmcCardPara.G_CardHandle, ZmcCardPara.m_nLaserIO, 0);				//关光
            if (ZmcCardPara.CheckError(rtn, "ZAux_Direct_Rapidstop")) return;
        }

        //切换振镜组
        private void CBoxScanID_SelectedIndexChanged(object sender, EventArgs e)
        {
            ZmcCardPara.m_ScanId = CBoxScanID.SelectedIndex;
            ZmcCardPara.Sel_ScanAxis();                             //选择振镜轴
        }

        //振镜轴交换
        private void Check_XyChange_CheckedChanged(object sender, EventArgs e)
        {

            ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].m_ScanXyChange = Check_XyChange.Checked ? 0 : 1;
            ZmcCardPara.Sel_ScanAxis();                             //选择振镜轴
        }

        //选择校正文件
        private void Btn_CorrectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "\\";
            openFileDialog1.Filter = "ZGA File(*.zga)|*.zga";
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.FilterIndex = 1;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)            //打开配置文件
            {
                Text_CorrnetFileName.Text = openFileDialog1.FileName;
                ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile = Text_CorrnetFileName.Text;
            }
        }

        //振镜轴校正
        private void Btn_ScanCorrect_Click(object sender, EventArgs e)
        {
            int nScanNum = 0;
            int ScanExChange = 0;
            int nXDirect = 0;
            int nYDirect = 0;
            double dUnits = 1000.0;
            double dScaleRatio = 0;
            //int rtn = ZmcLaser.ZScan_CorrectFileRead(ZmcCardPara.G_CardHandle, Text_CorrnetFileName.Text, ref nScanNum, ref ScanExChange, ref nXDirect, ref nYDirect, ref dUnits, ref dScaleRatio, 4000);
            //if (ZmcCardPara.CheckError(rtn, "ZScan_CorrectFile Error")) return;

            int rtn = ZmcLaser.ZScan_CorrectFile2(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile, 4000);
            if (ZmcCardPara.CheckError(rtn, "ZScan_CorrectFile2 Error")) return;

            //int32 __stdcall ZScan_ReadFile2Para(char* pFilePath, int& nScanNum, int& nScanExChange, int& nXDirect, int& nYDirect, double& dUnits, double& dScaleRatio);
            rtn = ZmcLaser.ZScan_ReadFile2Para(ZmcCardPara.m_ScanAxisPara[ZmcCardPara.m_ScanId].SscanCorrectFile, ref nScanNum, ref ScanExChange, ref nXDirect, ref nYDirect, ref dUnits, ref dScaleRatio);
            if (ZmcCardPara.CheckError(rtn, "ZScan_ReadFile2Para Error")) return;

            MessageBox.Show("校正完成!");
        }

        private void Btn_ScanFwd_Click(object sender, EventArgs e)
        {

        }

        //应用保存联动参数
        private void button1_Click(object sender, EventArgs e)
        {
            //联动参数
            ZmcCardPara.m_LinkAgePara.nMotorAxisX = Convert.ToInt32(Text_Linkage_AxisX.Text);
            ZmcCardPara.m_LinkAgePara.nMotorAxisY = Convert.ToInt32(Text_Linkage_AxisY.Text);
            ZmcCardPara.m_LinkAgePara.fMotorAcc = Convert.ToSingle(Text_Linkage_Acc.Text);
            ZmcCardPara.m_LinkAgePara.fMotorDec = Convert.ToSingle(Text_Linkage_Dec.Text);
            ZmcCardPara.m_LinkAgePara.fMotorMaxSp = Convert.ToSingle(Text_Linkage_MaxSp.Text);
            ZmcCardPara.m_LinkAgePara.fMotorZsmooth = Convert.ToSingle(Text_Linkage_Zsmooth.Text);
            ZmcCardPara.m_LinkAgePara.fMotorXLimit = Convert.ToSingle(Text_Linkage_MLlimtX.Text);
            ZmcCardPara.m_LinkAgePara.fMotorYLimit = Convert.ToSingle(Text_Linkage_MLlimtY.Text);
            ZmcCardPara.m_LinkAgePara.fXDelayTime = Convert.ToSingle(Text_Linkage_XDelay.Text);
            ZmcCardPara.m_LinkAgePara.fYDelayTime = Convert.ToSingle(Text_Linkage_YDelay.Text);
            ZmcCardPara.m_LinkAgePara.fScanXLimit = Convert.ToSingle(Text_Linkage_LimitX.Text);
            ZmcCardPara.m_LinkAgePara.fScanYLimit = Convert.ToSingle(Text_Linkage_LimitY.Text);
            ZmcCardPara.m_LinkAgePara.fXyAngle = Convert.ToSingle(Text_Linkage_Angle.Text);
            ZmcCardPara.m_LinkAgePara.bEnable = Text_Linkage_Enable.Checked;
            ZmcCardPara.m_LinkAgePara.bDivision_Enable = Text_Linkage_Division.Checked;


            //设置旋转角度
            int rtn = zmcaux.ZAux_SetZScanRotate(ZmcCardPara.G_CardHandle, ZmcCardPara.m_ScanId, ZmcCardPara.m_LinkAgePara.fXyAngle, 0, 0);
            if (ZmcCardPara.CheckError(rtn, "ZAux_SetZScanRotate ")) return;
        }

        //计算角度
        private void button2_Click(object sender, EventArgs e)
        {

        }

        //标刻角度测试
        private void button3_Click(object sender, EventArgs e)
        {

        }

        //停止标刻
        private void button4_Click(object sender, EventArgs e)
        {

        }

    }
}
